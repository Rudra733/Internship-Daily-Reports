# SproutSong — File Upload Security Sample

> **DPDP Act 2023 compliant file upload implementation for the SproutSong portal**
> Reference: `SproutSong_File_Upload_Security_Guide.docx`

---

## What This Is

A complete, production-grade sample codebase implementing every security control
from the SproutSong File Upload Security Guide. Intended as a **reference
implementation** for the engineering team — not a copy-paste template, but a
working example of every control in context.

---

## Project Structure

```
sproutsong-file-upload/
├── src/
│   ├── app.js                        # Express entry point, security middleware stack
│   ├── config/
│   │   ├── cors.js                   # CORS: allowlist of SproutSong origins only
│   │   ├── db.js                     # MongoDB connection (TLS in production)
│   │   ├── s3.js                     # S3 client + bucket config
│   │   └── uploadContexts.js         # ★ Allowed types/sizes per upload context
│   ├── middleware/
│   │   ├── auth.js                   # JWT verification + role guards + IDOR check
│   │   ├── errorHandler.js           # Generic error responses (no stack traces)
│   │   ├── rateLimiter.js            # Upload / form / download rate limiters
│   │   └── upload.js                 # ★ Multer: memoryStorage, extension check, size limit
│   ├── models/
│   │   └── CounsellingRequest.js     # ★ Schema: field encryption, TTL index, toSafeObject()
│   ├── routes/
│   │   ├── counselling.routes.js     # ★ Full security chain: scan→MIME→upload→save
│   │   ├── fileAccess.routes.js      # ★ IDOR-protected signed URL generation
│   │   └── workshop.routes.js        # Form route (no uploads): dedup, consent, TTL
│   ├── services/
│   │   ├── mimeValidator.js          # ★ Gate 2: MIME from magic bytes (file-type library)
│   │   ├── scanService.js            # ClamAV virus scanning (before S3 upload)
│   │   └── storageService.js         # ★ S3: upload, signedURL, delete, cascadeDelete
│   └── utils/
│       └── logger.js                 # Winston logger with automatic PII field masking
├── tests/
│   └── fileUpload.test.js            # Unit tests for all security controls
├── docs/
│   └── terraform-s3-bucket.tf        # Production S3 bucket (encryption, versioning, CORS)
├── .env.example                      # All required environment variables
└── package.json
```

---

## Security Controls Implemented

| Control | File | Status |
|---------|------|--------|
| Extension allowlist | `middleware/upload.js` | ✅ Gate 1 |
| MIME type from buffer | `services/mimeValidator.js` | ✅ Gate 2 |
| File size limits per context | `config/uploadContexts.js` | ✅ |
| Virus scanning (ClamAV) | `services/scanService.js` | ✅ |
| Private S3 bucket upload | `services/storageService.js` | ✅ |
| UUID file naming (original discarded) | `services/storageService.js` | ✅ |
| S3 key stored in DB (not URL) | `models/CounsellingRequest.js` | ✅ |
| Signed URL (15 min expiry) | `services/storageService.js` | ✅ |
| IDOR protection on file access | `routes/fileAccess.routes.js` | ✅ |
| Field-level encryption (PII) | `models/CounsellingRequest.js` | ✅ |
| PII masking in logs | `utils/logger.js` | ✅ |
| Rate limiting (upload/download/form) | `middleware/rateLimiter.js` | ✅ |
| JWT authentication on all file routes | `middleware/auth.js` | ✅ |
| Role-based access control | `middleware/auth.js` | ✅ |
| Cascade delete (S3 + MongoDB) | `services/storageService.js` | ✅ |
| Financial data nulled on closure | `models/CounsellingRequest.js` | ✅ |
| TTL index for draft records (30 days) | `models/CounsellingRequest.js` | ✅ |
| isMinor derived server-side from dob | `routes/counselling.routes.js` | ✅ |
| Server-set fields rejected from client | `routes/counselling.routes.js` | ✅ |
| CORS restricted to SproutSong origins | `config/cors.js` | ✅ |
| NoSQL injection protection | `app.js` (mongoSanitize) | ✅ |
| Security headers (helmet) | `app.js` | ✅ |
| AES-256 encryption at rest (S3) | `services/storageService.js` | ✅ |
| Generic error responses | `middleware/errorHandler.js` | ✅ |
| S3 bucket: block public access | `docs/terraform-s3-bucket.tf` | ✅ |

---

## The Two-Gate File Validation System

Every uploaded file must pass **both gates** before it reaches S3:

```
Client uploads file
      │
      ▼
┌─────────────────────────────────────────────────┐
│ Gate 1 — multer fileFilter (middleware/upload.js)│
│  Check: file extension is in allowlist           │
│  e.g. .pdf, .jpg, .png — reject .exe, .php, .svg│
└─────────────────────────────────────────────────┘
      │ Pass
      ▼
┌─────────────────────────────────────────────────┐
│ Gate 2 — mimeValidator (services/mimeValidator) │
│  Check: actual MIME from magic bytes (file-type) │
│  NOT the Content-Type header (client-supplied)   │
│  NOT the file extension (can be spoofed)         │
│  Blocks: SVG, HTML, EXE, PHP, ZIP, etc.          │
└─────────────────────────────────────────────────┘
      │ Pass
      ▼
┌─────────────────────────────────────────────────┐
│ ClamAV scan (services/scanService)              │
│  Scan buffer for malware before S3 upload        │
│  (Recommended — required in production)          │
└─────────────────────────────────────────────────┘
      │ Clean
      ▼
   Upload to private S3 bucket
   Return S3 key → store in MongoDB
```

---

## File Access Rule (IDOR-Protected)

```
Never:  GET /uploads/Rohan_Shah_marksheet.pdf       ← public path, no auth
Never:  GET /files?key=private/schools/s1/...       ← client passes the S3 key

Always: GET /api/files/:referenceId/:fieldName
          │
          ├── 1. Verify JWT (authMiddleware)
          ├── 2. Allowlist fieldName (only known file fields)
          ├── 3. Fetch record from DB by referenceId
          ├── 4. IDOR check: does this user own/have access to this record?
          ├── 5. Get S3 key from DB record (NOT from client request)
          └── 6. Return signed URL (15 min expiry) — raw key never exposed
```

---

## S3 Key Structure

```
private/schools/{schoolId}/students/{studentId}/{context}/{uuid}.{ext}

Examples:
  private/schools/dps-ahm-001/students/ref-550e8400/marksheets/a3f9b2c1-uuid.pdf
  private/schools/dps-ahm-001/students/ref-550e8400/photos/b7c3d4e5-uuid.jpg
  private/schools/xyz-school/counselling/case-ref/counselling-reports/uuid.pdf

NEVER:
  /uploads/student-marksheet.pdf
  /public/schools/DPS/students/Rohan_10th.pdf
  /private/schools/s1/students/u1/documents/Rohan_Shah_marksheet_2024.pdf
```

---

## Getting Started

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
# Fill in: MONGO_URI, AWS credentials, PRIVATE_BUCKET, FIELD_ENCRYPTION_SECRET
```

### 3. Set up S3 bucket
```bash
# Using Terraform (see docs/terraform-s3-bucket.tf):
cd docs && terraform init && terraform apply

# Or manually in AWS Console — ensure:
# ✓ Block all public access: ON
# ✓ Server-side encryption: AES-256
# ✓ Versioning: enabled
# ✓ No public-read ACL or bucket policy
```

### 4. Start ClamAV (optional in development)
```bash
# macOS:
brew install clamav && freshclam && clamd

# Docker:
docker run -d -p 3310:3310 --name clamav clamav/clamav:stable

# Or disable in development:
# USE_CLAMAV=false in .env
```

### 5. Run tests
```bash
npm test
```

### 6. Start the server
```bash
npm run dev      # development (nodemon)
npm start        # production
```

---

## API Endpoints

### Submit counselling form with file uploads
```
POST /api/counselling/submit
Content-Type: multipart/form-data

Fields: fullName, dob, gender, mobile, email, ...
Files:  std8FilePath, std9FilePath, std10FilePath, std11FilePath, std12FilePath, photoPath
```

### Get a signed URL for a student's file
```
GET /api/files/:referenceId/:fieldName
Authorization: Bearer <jwt>

Response: { url: "https://s3.amazonaws.com/...?X-Amz-Expires=900&...", expiresIn: 900 }
```

### Check which files exist for a record
```
GET /api/files/:referenceId
Authorization: Bearer <jwt>

Response: { referenceId: "...", files: { std8FilePath: true, photoPath: false, ... } }
```

### Close a case and clear financial data
```
PATCH /api/counselling/:referenceId/close
Authorization: Bearer <jwt>   (counsellor or admin role)
```

### Delete a record (DPDP Right to Erasure)
```
DELETE /api/counselling/:referenceId
Authorization: Bearer <jwt>   (admin role only)

Deletes: all S3 files + MongoDB record
Response: { message: "...", filesDeleted: 5 }
```

### Register for AI Workshop
```
POST /api/workshop/register
Content-Type: application/json

Body: { name, role, school, city, phone, email, preferred_date, teacher_count, consentGiven: "true", ... }
```

---

## DPDP Act 2023 Compliance

| Requirement | Implementation |
|-------------|----------------|
| Consent before processing | `consentGiven`, `docConsentGiven`, `parentConsentGiven` required fields |
| Parental consent for minors | `isMinor` derived from `dob`; `parentConsentGiven` enforced |
| Purpose limitation | File fields only accessible via counselling API — not exposed publicly |
| Data minimisation | TTL index deletes drafts after 30 days; financial data nulled on closure |
| Right to erasure | `DELETE /api/counselling/:referenceId` — cascade deletes S3 + MongoDB |
| 72-hour SLA | Document your process at `privacy@sproutsong.com` |
| No advertising profiling | Career preference fields have no analytics export |
| Data at rest protection | Field-level encryption on PII + AES-256 at S3 level |

---

## Key Dependencies

| Package | Purpose |
|---------|---------|
| `multer` | File upload parsing — memoryStorage (no disk writes) |
| `file-type` | Gate 2 MIME detection from magic bytes |
| `@aws-sdk/client-s3` | S3 upload, delete, HeadObject |
| `@aws-sdk/s3-request-presigner` | Signed URL generation |
| `mongoose-field-encryption` | Field-level encryption for PII in MongoDB |
| `clamscan` | ClamAV virus scanning wrapper |
| `express-mongo-sanitize` | Strip `$` and `.` from inputs (NoSQL injection) |
| `express-rate-limit` | Rate limiting for upload/download/form routes |
| `express-validator` | Server-side input validation and sanitization |
| `helmet` | Security response headers (CSP, HSTS, etc.) |
| `winston` | Structured logging with PII masking |
| `jsonwebtoken` | JWT authentication |
| `uuid` | UUID v4 for referenceId and file naming |

---

*Prepared for SproutSong Engineering & Compliance Team*
*Reference: SproutSong_File_Upload_Security_Guide.docx — DPDP Act 2023*
