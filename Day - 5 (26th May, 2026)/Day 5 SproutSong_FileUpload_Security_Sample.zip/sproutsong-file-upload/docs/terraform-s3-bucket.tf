# ──────────────────────────────────────────────────────────────────────────────
# docs/terraform-s3-bucket.tf
# Production-ready Terraform config for the SproutSong private S3 bucket.
#
# Security controls enforced:
#   ✓ Block all public access (4 settings)
#   ✓ Server-side encryption: AES-256 (SSE-S3)
#   ✓ Bucket versioning enabled
#   ✓ Access logging to a separate log bucket
#   ✓ CORS: only allow SproutSong origins
#   ✓ Lifecycle rules: archive to Glacier after 12 months, delete after 36 months
#   ✓ No bucket policy granting public-read
# ──────────────────────────────────────────────────────────────────────────────

terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = "ap-south-1"   # Mumbai — data residency for India
}

# ── Private documents bucket ──────────────────────────────────────────────────
resource "aws_s3_bucket" "sproutsong_private" {
  bucket = "sproutsong-private-documents"

  tags = {
    Name        = "SproutSong Private Documents"
    Environment = "production"
    Compliance  = "DPDP-2023"
    DataClass   = "Sensitive-PII"
  }
}

# Block ALL public access — 4 settings, all must be true
resource "aws_s3_bucket_public_access_block" "private" {
  bucket = aws_s3_bucket.sproutsong_private.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# Server-side encryption: AES-256
resource "aws_s3_bucket_server_side_encryption_configuration" "private" {
  bucket = aws_s3_bucket.sproutsong_private.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
    bucket_key_enabled = true
  }
}

# Versioning — enables recovery of overwritten/deleted files
resource "aws_s3_bucket_versioning" "private" {
  bucket = aws_s3_bucket.sproutsong_private.id

  versioning_configuration {
    status = "Enabled"
  }
}

# CORS — restrict to SproutSong origins only
resource "aws_s3_bucket_cors_configuration" "private" {
  bucket = aws_s3_bucket.sproutsong_private.id

  cors_rule {
    allowed_headers = ["*"]
    allowed_methods = ["GET", "PUT", "POST"]
    allowed_origins = [
      "https://auth.sproutsong.com",
      "https://www.sproutsong.com",
      "https://app.sproutmentors.com",
    ]
    expose_headers  = ["ETag"]
    max_age_seconds = 3000
  }
}

# Lifecycle rules — DPDP data retention compliance
resource "aws_s3_bucket_lifecycle_configuration" "private" {
  bucket = aws_s3_bucket.sproutsong_private.id

  rule {
    id     = "archive-old-documents"
    status = "Enabled"

    filter {
      prefix = "private/"
    }

    # Move to Glacier after 12 months (cheaper storage, still accessible)
    transition {
      days          = 365
      storage_class = "GLACIER"
    }

    # Permanently delete after 36 months
    expiration {
      days = 1095
    }

    # Clean up incomplete multipart uploads after 7 days
    abort_incomplete_multipart_upload {
      days_after_initiation = 7
    }
  }

  # Counselling drafts: delete after 30 days (matches MongoDB TTL index)
  rule {
    id     = "delete-draft-documents"
    status = "Enabled"

    filter {
      prefix = "private/drafts/"
    }

    expiration {
      days = 30
    }
  }
}

# ── Access logging bucket (separate, append-only) ─────────────────────────────
resource "aws_s3_bucket" "sproutsong_logs" {
  bucket = "sproutsong-access-logs"

  tags = {
    Name    = "SproutSong S3 Access Logs"
    Purpose = "security-audit"
  }
}

resource "aws_s3_bucket_public_access_block" "logs" {
  bucket                  = aws_s3_bucket.sproutsong_logs.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

# Enable access logging on the private bucket → log bucket
resource "aws_s3_bucket_logging" "private" {
  bucket = aws_s3_bucket.sproutsong_private.id

  target_bucket = aws_s3_bucket.sproutsong_logs.id
  target_prefix = "s3-access-logs/sproutsong-private/"
}

# ── IAM role for the application (least privilege) ────────────────────────────
resource "aws_iam_role" "sproutsong_app" {
  name = "sproutsong-app-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "ec2.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy" "sproutsong_s3" {
  name = "sproutsong-s3-policy"
  role = aws_iam_role.sproutsong_app.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        # App can only read/write to its own private bucket
        Effect   = "Allow"
        Action   = ["s3:PutObject", "s3:GetObject", "s3:DeleteObject", "s3:HeadObject"]
        Resource = "${aws_s3_bucket.sproutsong_private.arn}/private/*"
      },
      {
        # App can list the bucket (needed for cleanup jobs)
        Effect   = "Allow"
        Action   = ["s3:ListBucket"]
        Resource = aws_s3_bucket.sproutsong_private.arn
        Condition = {
          StringLike = { "s3:prefix" = ["private/*"] }
        }
      }
      # No admin, no other buckets, no ACL changes
    ]
  })
}

output "private_bucket_name" {
  value       = aws_s3_bucket.sproutsong_private.bucket
  description = "Name of the private documents bucket — use as PRIVATE_BUCKET env var"
}

output "private_bucket_arn" {
  value = aws_s3_bucket.sproutsong_private.arn
}
