/**
 * SproutSong — File Upload Security Sample
 * app.js — Express application entry point
 *
 * DPDP Act 2023 compliant file upload implementation.
 * See: SproutSong_File_Upload_Security_Guide.docx
 */

import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import mongoSanitize from 'express-mongo-sanitize';
import mongoose from 'mongoose';

import { corsOptions }         from './config/cors.js';
import { connectDB }           from './config/db.js';
import { logger }              from './utils/logger.js';
import { errorHandler }        from './middleware/errorHandler.js';

import counsellingRoutes       from './routes/counselling.routes.js';
import fileAccessRoutes        from './routes/fileAccess.routes.js';
import workshopRoutes          from './routes/workshop.routes.js';

const app = express();

// ── Security headers (helmet) ─────────────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc:  ["'self'"],
      scriptSrc:   ["'self'", 'https://www.google.com', 'https://www.gstatic.com'],
      styleSrc:    ["'self'", "'unsafe-inline'"],
      imgSrc:      ["'self'", 'data:', 'https:'],
      connectSrc:  ["'self'"],
      frameSrc:    ['https://www.google.com'],
      objectSrc:   ["'none'"],
      upgradeInsecureRequests: [],
    },
  },
  hsts:            { maxAge: 31536000, includeSubDomains: true, preload: true },
  referrerPolicy:  { policy: 'strict-origin-when-cross-origin' },
  xFrameOptions:   { action: 'deny' },
  noSniff:         true,
}));

// ── CORS ──────────────────────────────────────────────────────────────────────
app.use(cors(corsOptions));

// ── Body parsing ──────────────────────────────────────────────────────────────
app.use(express.json({ limit: '1mb' }));         // JSON body limit (not for files)
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

// ── NoSQL injection protection ────────────────────────────────────────────────
// Strips $ and . from all request body, params, and query strings
app.use(mongoSanitize());

// ── Routes ────────────────────────────────────────────────────────────────────
app.use('/api/counselling', counsellingRoutes);   // Upload marksheets, photos
app.use('/api/files',       fileAccessRoutes);    // Secure file download (signed URL)
app.use('/api/workshop',    workshopRoutes);      // AI workshop registration (no uploads)

// ── Health check ──────────────────────────────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'ok', service: 'sproutsong-file-upload' }));

// ── 404 handler ───────────────────────────────────────────────────────────────
app.use((req, res) => res.status(404).json({ message: 'Not found.' }));

// ── Central error handler ─────────────────────────────────────────────────────
app.use(errorHandler);

// ── Start ─────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;

connectDB().then(() => {
  app.listen(PORT, () => logger.info(`SproutSong file upload service running on port ${PORT}`));
});

export default app;
