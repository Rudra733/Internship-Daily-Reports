/**
 * config/s3.js — AWS S3 client (private bucket)
 *
 * Security rules enforced here:
 * 1. Credentials from env only — never hardcoded
 * 2. Bucket name from env — separates config from code
 * 3. All uploads use AES-256 server-side encryption
 * 4. All objects go to the PRIVATE bucket — no public-read ACL
 *
 * Bucket setup checklist (do this in AWS console / Terraform):
 *   ✓ Block all public access: ON
 *   ✓ Bucket versioning: enabled
 *   ✓ Server-side encryption: AES-256 (SSE-S3) or SSE-KMS
 *   ✓ Access logging: enabled → separate append-only log bucket
 *   ✓ CORS: restrict to auth.sproutsong.com and app.sproutmentors.com
 *   ✓ No bucket policy granting public-read
 */

import { S3Client } from '@aws-sdk/client-s3';

export const s3 = new S3Client({
  region: process.env.AWS_REGION || 'ap-south-1',
  credentials: {
    accessKeyId:     process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

export const PRIVATE_BUCKET = process.env.PRIVATE_BUCKET;

// Signed URL expiry: 15 minutes (900 seconds)
// Short enough to prevent URL sharing, long enough for download to complete
export const SIGNED_URL_EXPIRY = parseInt(process.env.SIGNED_URL_EXPIRY || '900', 10);
