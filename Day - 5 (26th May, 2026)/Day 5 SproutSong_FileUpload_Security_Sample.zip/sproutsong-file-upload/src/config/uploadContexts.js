/**
 * config/uploadContexts.js — Allowed file types per upload context
 *
 * This is the single source of truth for what file types, MIME types,
 * and size limits are allowed for each upload use case in SproutSong.
 *
 * Both the multer fileFilter AND the MIME validation service use this config.
 * Changing limits here automatically enforces them everywhere.
 *
 * NEVER allow:
 *   .exe .js .php .sh .bat .py .html .svg .xml .zip .rar
 *   — executables, scripts, archives, or markup that can contain scripts
 *   — SVG is especially dangerous: it can embed JavaScript
 *   — HTML files can contain XSS payloads
 */

export const UPLOAD_CONTEXTS = {
  /**
   * Student marksheets: Std 8 through Std 12
   * Used in: Counselling form (std8FilePath … std12FilePath)
   */
  marksheet: {
    allowedExtensions: ['.pdf', '.jpg', '.jpeg', '.png'],
    allowedMimeTypes:  ['application/pdf', 'image/jpeg', 'image/png'],
    maxSizeBytes:      5 * 1024 * 1024,   // 5 MB
    maxSizeLabel:      '5 MB',
    s3Prefix:          'marksheets',
  },

  /**
   * Student photograph / profile photo
   * Used in: Counselling form (photoPath)
   */
  photo: {
    allowedExtensions: ['.jpg', '.jpeg', '.png'],
    allowedMimeTypes:  ['image/jpeg', 'image/png'],
    maxSizeBytes:      2 * 1024 * 1024,   // 2 MB
    maxSizeLabel:      '2 MB',
    s3Prefix:          'photos',
  },

  /**
   * School documents: letterheads, affiliation certificates
   * Used in: School onboarding, admin panel
   */
  schoolDocument: {
    allowedExtensions: ['.pdf'],
    allowedMimeTypes:  ['application/pdf'],
    maxSizeBytes:      10 * 1024 * 1024,  // 10 MB
    maxSizeLabel:      '10 MB',
    s3Prefix:          'school-documents',
  },

  /**
   * Academic certificates and awards
   */
  certificate: {
    allowedExtensions: ['.pdf', '.jpg', '.jpeg', '.png'],
    allowedMimeTypes:  ['application/pdf', 'image/jpeg', 'image/png'],
    maxSizeBytes:      5 * 1024 * 1024,   // 5 MB
    maxSizeLabel:      '5 MB',
    s3Prefix:          'certificates',
  },

  /**
   * Counselling assessment reports
   * Used in: Counselling case management (admin/counsellor upload)
   */
  counsellingReport: {
    allowedExtensions: ['.pdf'],
    allowedMimeTypes:  ['application/pdf'],
    maxSizeBytes:      10 * 1024 * 1024,  // 10 MB
    maxSizeLabel:      '10 MB',
    s3Prefix:          'counselling-reports',
  },

  /**
   * Teacher identity and qualification documents
   */
  teacherDocument: {
    allowedExtensions: ['.pdf'],
    allowedMimeTypes:  ['application/pdf'],
    maxSizeBytes:      5 * 1024 * 1024,   // 5 MB
    maxSizeLabel:      '5 MB',
    s3Prefix:          'teacher-documents',
  },
};

/**
 * Blocklist of MIME types that must NEVER be accepted regardless of context.
 * If a detected MIME type is in this list, reject immediately.
 */
export const BLOCKED_MIME_TYPES = [
  'application/x-executable',
  'application/x-msdownload',
  'application/x-sh',
  'application/x-php',
  'application/javascript',
  'text/javascript',
  'text/html',
  'image/svg+xml',
  'application/xml',
  'text/xml',
  'application/zip',
  'application/x-rar-compressed',
  'application/x-tar',
  'application/x-7z-compressed',
];
