/**
 * config/cors.js — CORS policy
 *
 * Security rule: Only allow requests from SproutSong's own frontend origins.
 * Never use wildcard (*) — that defeats CORS protection entirely.
 */

const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '')
  .split(',')
  .map(o => o.trim())
  .filter(Boolean);

export const corsOptions = {
  origin(origin, callback) {
    // Allow server-to-server (no origin) only in development
    if (!origin && process.env.NODE_ENV !== 'production') {
      return callback(null, true);
    }
    if (ALLOWED_ORIGINS.includes(origin)) {
      return callback(null, true);
    }
    callback(new Error(`CORS: origin '${origin}' not allowed`));
  },
  methods:          ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders:   ['Content-Type', 'Authorization'],
  credentials:      true,
  optionsSuccessStatus: 200,
};
