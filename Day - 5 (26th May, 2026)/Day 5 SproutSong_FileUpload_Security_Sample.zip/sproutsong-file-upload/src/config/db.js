/**
 * config/db.js — MongoDB connection
 *
 * Security notes:
 * - Connection string from env only — never hardcoded
 * - strict: true on all schemas (set per model) rejects unknown fields
 * - App DB user has readWrite on sproutsong collection only — not admin rights
 */

import mongoose from 'mongoose';
import { logger } from '../utils/logger.js';

export async function connectDB() {
  try {
    await mongoose.connect(process.env.MONGO_URI, {
      // Enforce TLS for Atlas / remote MongoDB
      tls: process.env.NODE_ENV === 'production',
      authSource: 'admin',
    });
    logger.info('MongoDB connected');
  } catch (err) {
    // Log without exposing connection string
    logger.error('MongoDB connection failed', { error: err.message });
    process.exit(1);
  }
}
