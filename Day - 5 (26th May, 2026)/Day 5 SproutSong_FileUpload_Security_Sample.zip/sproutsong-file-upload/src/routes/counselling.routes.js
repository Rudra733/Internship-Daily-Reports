/**
 * routes/counselling.routes.js — Counselling form submission with file uploads
 *
 * Security chain for POST /api/counselling/submit:
 *   formRateLimiter        → max 5 submissions per IP per hour
 *   uploadRateLimiter      → max 10 file uploads per IP per 15 min
 *   upload.fields()        → multer: memoryStorage, extension check, size limit
 *   handleMulterError      → converts multer errors to safe JSON responses
 *   validateSubmission     → express-validator: allowlist all fields, reject unknown
 *   handler:
 *     scanAllFiles()       → ClamAV virus scan (before S3 upload)
 *     validateAllFiles()   → MIME type from buffer (Gate 2)
 *     isMinor check        → derive from dob server-side
 *     parentConsent check  → enforce if isMinor = true
 *     uploadFile() × N     → upload each file to private S3 bucket
 *     new CounsellingRequest().save() → store S3 keys (not URLs) in MongoDB
 *     response             → generic success, no internal IDs returned
 *
 * DELETE /api/counselling/:referenceId — DPDP Right to Erasure
 *   authMiddleware         → JWT required
 *   requireRole('admin')   → admin only
 *   cascadeDeleteStudentFiles() → delete all S3 objects first
 *   CounsellingRequest.deleteOne() → then delete MongoDB record
 */

import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import { v4 as uuidv4 } from 'uuid';

import { createUploader, handleMulterError } from '../middleware/upload.js';
import { authMiddleware, requireRole }        from '../middleware/auth.js';
import { uploadRateLimiter, formRateLimiter } from '../middleware/rateLimiter.js';
import { validateAllFiles }                   from '../services/mimeValidator.js';
import { scanAllFiles }                       from '../services/scanService.js';
import { uploadFile, cascadeDeleteStudentFiles } from '../services/storageService.js';
import CounsellingRequest                     from '../models/CounsellingRequest.js';
import { logger }                             from '../utils/logger.js';

const router = Router();

// ── Multer instance for counselling form ─────────────────────────────────────
// All marksheet + photo uploads use the 'marksheet' context (5 MB, PDF/JPG/PNG)
// photoPath uses the 'photo' context (2 MB, JPG/PNG) — handled separately below
const marksheetUpload = createUploader('marksheet');

const MARKSHEET_FIELDS = [
  { name: 'std8FilePath',  maxCount: 1 },
  { name: 'std9FilePath',  maxCount: 1 },
  { name: 'std10FilePath', maxCount: 1 },
  { name: 'std11FilePath', maxCount: 1 },
  { name: 'std12FilePath', maxCount: 1 },
  { name: 'photoPath',     maxCount: 1 },
];

// ── Validation rules ─────────────────────────────────────────────────────────
const validateSubmission = [
  // Student identity
  body('fullName').trim().isLength({ min: 2, max: 100 }).escape(),
  body('dob').isISO8601().withMessage('Invalid date of birth'),
  body('gender').isIn(['male', 'female', 'other']),
  body('mobile').matches(/^[6-9]\d{9}$/).withMessage('Invalid mobile number'),
  body('email').isEmail().normalizeEmail().trim(),

  // Parent
  body('fatherName').trim().isLength({ min: 2, max: 100 }).escape(),
  body('fatherOccupation').trim().isLength({ min: 1, max: 100 }).escape(),
  body('fatherContact').matches(/^[6-9]\d{9}$/).withMessage('Invalid father contact'),
  body('fatherEmail').optional().isEmail().normalizeEmail().trim(),
  body('motherName').trim().isLength({ min: 2, max: 100 }).escape(),
  body('fatherIncome').optional().trim().escape(),
  body('motherIncome').optional().trim().escape(),

  // Address
  body('house').trim().isLength({ min: 1, max: 200 }).escape(),
  body('village').trim().isLength({ min: 1, max: 200 }).escape(),
  body('city').trim().isLength({ min: 1, max: 100 }).escape(),
  body('district').trim().isLength({ min: 1, max: 100 }).escape(),
  body('state').trim().isLength({ min: 1, max: 100 }).escape(),
  body('pincode').matches(/^\d{6}$/).withMessage('Invalid pincode'),

  // Academic
  body('standard').isIn(['10th', '12th']),
  body('board').isIn(['CBSE', 'GSEB', 'ICSE', 'SSC', 'NIOS', 'CIE', 'IB', 'CISCE', 'Other']),
  body('school').trim().isLength({ min: 2, max: 200 }).escape(),
  body('medium').isIn(['english', 'gujarati']),
  body('year').isIn(['2024-25', '2025-26']),
  body('stream').optional().isIn(['science', 'commerce', 'arts', 'vocational']),
  body('scienceGroup').optional().isArray({ max: 10 }),
  body('percentage').optional().trim().escape(),

  // Career preferences
  body('interests').optional().isArray({ max: 10 }),
  body('preferredCity').optional().trim().isLength({ max: 100 }).escape(),
  body('preferredCollege').optional().trim().isLength({ max: 200 }).escape(),
  body('budget').optional().trim().escape(),

  // Submission
  body('query').optional().trim().isLength({ max: 1000 }).escape(),
  body('howHeard').optional().trim().escape(),

  // Consent — all required
  body('consentGiven').equals('true').withMessage('Consent is required'),
  body('docConsentGiven').equals('true').withMessage('Document consent is required'),
  body('parentConsentGiven').optional().isBoolean(),

  // Server-set fields — MUST NOT come from client
  body('referenceId').not().exists().withMessage('referenceId cannot be set by client'),
  body('status').not().exists().withMessage('status cannot be set by client'),
  body('adminStatus').not().exists().withMessage('adminStatus cannot be set by client'),
  body('isMinor').not().exists().withMessage('isMinor cannot be set by client'),
  body('consentTimestamp').not().exists(),
  body('consentIP').not().exists(),
  body('assignedCounsellorId').not().exists(),
];

// ── POST /api/counselling/submit ─────────────────────────────────────────────
router.post(
  '/submit',
  formRateLimiter,
  uploadRateLimiter,
  marksheetUpload.fields(MARKSHEET_FIELDS),
  handleMulterError,
  validateSubmission,
  async (req, res, next) => {
    try {
      // 1. Validation errors
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Generic message — do not return field-level detail that leaks schema info
        return res.status(422).json({ message: 'Invalid submission. Please check your form.' });
      }

      const { body: data, files, ip } = req;

      // 2. Derive isMinor from dob — NEVER trust client
      const ageMs  = Date.now() - new Date(data.dob).getTime();
      const age    = Math.floor(ageMs / (365.25 * 24 * 3600 * 1000));
      const isMinor = age < 18;

      // 3. Enforce parental consent for minors
      if (isMinor && data.parentConsentGiven !== 'true') {
        return res.status(422).json({
          message: 'Parental/guardian consent is required for students under 18.',
        });
      }

      // 4. Virus scan — before any S3 upload
      await scanAllFiles(files, ip);

      // 5. MIME type validation from buffer (Gate 2)
      const mimeMap = await validateAllFiles(files, 'marksheet', ip);

      // 6. Upload each file to private S3 bucket
      //    schoolId from data, studentId will be the new referenceId
      const referenceId = uuidv4();    // Server-generated — not from client
      const schoolId    = data.school; // In production: look up actual schoolId from DB

      const filePaths = {};
      for (const [fieldName, fileArr] of Object.entries(files || {})) {
        const file    = fileArr[0];
        const context = fieldName === 'photoPath' ? 'photo' : 'marksheet';
        const mime    = mimeMap[fieldName] || file.mimetype;

        filePaths[fieldName] = await uploadFile({
          buffer:    file.buffer,
          mimeType:  mime,
          schoolId,
          studentId: referenceId,
          context,
        });
      }

      // 7. Save record to MongoDB (S3 keys, not URLs)
      const record = new CounsellingRequest({
        ...data,
        ...filePaths,
        referenceId,                     // Server-generated
        isMinor,                         // Server-derived
        status:           'submitted',   // Hardcoded
        consentGiven:     true,
        docConsentGiven:  true,
        parentConsentGiven: isMinor ? true : undefined,
        consentTimestamp: new Date(),
        consentIP:        ip,
      });

      await record.save();

      logger.info('Counselling request submitted', {
        referenceId,
        isMinor,
        filesUploaded: Object.keys(filePaths).length,
        ip,
      });

      // 8. Generic response — no internal IDs or S3 keys returned
      res.status(201).json({
        message: 'Your counselling request has been submitted successfully. We will be in touch shortly.',
      });
    } catch (err) {
      next(err);
    }
  }
);

// ── DELETE /api/counselling/:referenceId — DPDP Right to Erasure ─────────────
router.delete(
  '/:referenceId',
  authMiddleware,
  requireRole('admin'),
  async (req, res, next) => {
    try {
      const { referenceId } = req.params;

      const record = await CounsellingRequest.findOne({ referenceId });
      if (!record) {
        return res.status(404).json({ message: 'Record not found.' });
      }

      // DPDP erasure: delete S3 files FIRST, then DB record
      const filesDeleted = await cascadeDeleteStudentFiles(record);
      await CounsellingRequest.deleteOne({ referenceId });

      // Audit log — no PII, just reference and actor
      logger.info('DPDP erasure completed', {
        referenceId,
        filesDeleted,
        deletedBy: req.user.userId,
        timestamp: new Date().toISOString(),
      });

      res.json({
        message: 'Record and all associated files have been permanently deleted.',
        filesDeleted,
      });
    } catch (err) {
      next(err);
    }
  }
);

// ── PATCH /api/counselling/:referenceId/close — Close case + clear financial data
router.patch(
  '/:referenceId/close',
  authMiddleware,
  requireRole('admin', 'counsellor'),
  async (req, res, next) => {
    try {
      const record = await CounsellingRequest.findOne({ referenceId: req.params.referenceId });
      if (!record) return res.status(404).json({ message: 'Record not found.' });

      // Data minimisation: null financial fields on closure
      await record.clearFinancialData();
      record.status = 'closed';
      await record.save();

      logger.info('Counselling case closed — financial data cleared', {
        referenceId: req.params.referenceId,
        closedBy: req.user.userId,
      });

      res.json({ message: 'Case closed. Financial data has been cleared.' });
    } catch (err) {
      next(err);
    }
  }
);

export default router;
