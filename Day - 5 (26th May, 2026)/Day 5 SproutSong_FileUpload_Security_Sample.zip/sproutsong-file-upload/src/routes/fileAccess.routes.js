/**
 * routes/fileAccess.routes.js — Secure file download via signed URLs
 *
 * This is the most security-critical route in the entire upload system.
 * It implements the complete IDOR protection chain described in Part E of the guide.
 *
 * GET /api/files/:referenceId/:fieldName
 *
 * Security chain (every step is required — skipping any step is a vulnerability):
 *   Step 1 — downloadRateLimiter   : max 30 requests per user per 15 min
 *   Step 2 — authMiddleware        : valid JWT required (401 if missing/invalid)
 *   Step 3 — fieldName allowlist   : only known file fields accepted (400 if unknown)
 *   Step 4 — DB lookup by referenceId : record fetched from DB, NOT from client URL
 *   Step 5 — IDOR check            : verify user's role/assignments match file owner
 *   Step 6 — Key retrieval         : S3 key taken from DB record, NOT from client
 *   Step 7 — Signed URL generation : 15-minute expiry URL returned (key never exposed)
 *
 * IMPORTANT:
 *   The raw S3 key is NEVER returned to the client.
 *   The client receives only a time-limited signed URL that expires in 15 minutes.
 *   The client opens the URL directly — it is NOT stored on the client side.
 */

import { Router } from 'express';
import { param, validationResult } from 'express-validator';

import { authMiddleware }        from '../middleware/auth.js';
import { downloadRateLimiter }   from '../middleware/rateLimiter.js';
import { getSignedDownloadUrl }  from '../services/storageService.js';
import { canAccessRecord }       from '../middleware/auth.js';
import CounsellingRequest        from '../models/CounsellingRequest.js';
import { logger }                from '../utils/logger.js';
import { SIGNED_URL_EXPIRY }     from '../config/s3.js';

const router = Router();

// Allowlist of file fields that can be requested.
// Any fieldName not in this set is rejected — prevents path traversal / probing.
const ALLOWED_FILE_FIELDS = new Set([
  'std8FilePath',
  'std9FilePath',
  'std10FilePath',
  'std11FilePath',
  'std12FilePath',
  'photoPath',
]);

// ── GET /api/files/:referenceId/:fieldName ────────────────────────────────────
router.get(
  '/:referenceId/:fieldName',
  downloadRateLimiter,
  authMiddleware,
  [
    param('referenceId').isUUID(4).withMessage('Invalid reference ID'),
    param('fieldName').isString().isLength({ min: 1, max: 50 }),
  ],
  async (req, res, next) => {
    try {
      // Step 3: Validate params
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ message: 'Invalid request parameters.' });
      }

      const { referenceId, fieldName } = req.params;

      // Step 3b: fieldName allowlist — never trust fieldName from the URL
      if (!ALLOWED_FILE_FIELDS.has(fieldName)) {
        logger.warn('File access attempted with unknown field name', {
          fieldName,
          userId: req.user.userId,
          ip: req.ip,
        });
        return res.status(400).json({ message: 'Invalid file field.' });
      }

      // Step 4: Fetch record from DB by referenceId
      // NEVER accept a raw S3 key or file path from the client request
      const record = await CounsellingRequest.findOne({ referenceId });
      if (!record) {
        // Return 404 — don't reveal whether record exists to unauthorised users
        return res.status(404).json({ message: 'File not found.' });
      }

      // Step 5: IDOR check — verify the requesting user has access to this record
      if (!canAccessRecord(req.user, referenceId)) {
        // Log the access attempt for security auditing
        logger.warn('IDOR access attempt blocked', {
          referenceId,
          userId:   req.user.userId,
          role:     req.user.role,
          fieldName,
          ip:       req.ip,
        });
        // Return 404 (not 403) to avoid confirming the record exists to unauthorised users
        return res.status(404).json({ message: 'File not found.' });
      }

      // School admin: additionally verify the record belongs to their school
      if (req.user.role === 'school_admin' && record.school !== req.user.schoolId) {
        logger.warn('School admin cross-school access attempt blocked', {
          referenceId,
          userId:          req.user.userId,
          userSchoolId:    req.user.schoolId,
          recordSchool:    record.school,
          ip:              req.ip,
        });
        return res.status(404).json({ message: 'File not found.' });
      }

      // Step 6: Get the S3 key from the DB record — NOT from the client request
      const s3Key = record[fieldName];
      if (!s3Key) {
        return res.status(404).json({ message: 'File not found.' });
      }

      // Step 7: Generate a pre-signed URL (15 min expiry)
      // The raw s3Key is NEVER sent to the client
      const signedUrl = await getSignedDownloadUrl(s3Key);

      // Audit log — referenceId and field only, no key or URL
      logger.info('Signed URL generated for file access', {
        referenceId,
        fieldName,
        userId: req.user.userId,
        role:   req.user.role,
        ip:     req.ip,
      });

      res.json({
        url:       signedUrl,
        expiresIn: SIGNED_URL_EXPIRY,   // seconds
        // Note: client should open this URL immediately — do not store it
      });
    } catch (err) {
      next(err);
    }
  }
);

// ── GET /api/files/:referenceId — List available files for a record ───────────
// Returns which file fields are populated (true/false) — not the URLs or keys
router.get(
  '/:referenceId',
  downloadRateLimiter,
  authMiddleware,
  async (req, res, next) => {
    try {
      const { referenceId } = req.params;

      const record = await CounsellingRequest.findOne({ referenceId });
      if (!record) return res.status(404).json({ message: 'Record not found.' });

      if (!canAccessRecord(req.user, referenceId)) {
        return res.status(404).json({ message: 'Record not found.' });
      }

      // Return presence of files only — never return the keys
      const filePresence = {};
      for (const field of ALLOWED_FILE_FIELDS) {
        filePresence[field] = !!record[field];
      }

      res.json({
        referenceId,
        files: filePresence,
      });
    } catch (err) {
      next(err);
    }
  }
);

export default router;
