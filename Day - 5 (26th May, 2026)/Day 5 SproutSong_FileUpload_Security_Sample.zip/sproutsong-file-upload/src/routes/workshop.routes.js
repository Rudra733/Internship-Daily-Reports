/**
 * routes/workshop.routes.js — AI Workshop registration form
 *
 * No file uploads in this form — but all other security controls apply:
 *   - Rate limiting
 *   - NoSQL injection protection (from global mongoSanitize middleware)
 *   - Server-side validation with express-validator
 *   - Duplicate detection (same email + date within 24h)
 *   - Status and referenceId are server-set only
 *   - PII masking in logs
 *   - Consent recorded with timestamp and IP
 *
 * POST /api/workshop/register
 * DELETE /api/workshop/:referenceId (admin only — DPDP erasure)
 */

import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import { v4 as uuidv4 } from 'uuid';
import mongoose from 'mongoose';
import { fieldEncryption } from 'mongoose-field-encryption';

import { formRateLimiter }        from '../middleware/rateLimiter.js';
import { authMiddleware, requireRole } from '../middleware/auth.js';
import { logger }                 from '../utils/logger.js';

const router = Router();

// ── Inline schema (small form — no separate model file needed) ────────────────
const workshopSchema = new mongoose.Schema(
  {
    referenceId:     { type: String, required: true, unique: true },
    name:            { type: String, required: true, trim: true, maxlength: 100 },
    role:            { type: String, required: true },
    school:          { type: String, required: true, trim: true, maxlength: 200 },
    city:            { type: String, required: true, trim: true },
    phone:           { type: String, required: true, trim: true },
    email:           { type: String, required: true, trim: true, lowercase: true },
    preferred_date:  { type: String, required: true },
    alternative_date:{ type: String, default: null },
    teacher_count:   { type: Number, required: true },
    interests:       { type: [String], default: [] },
    notes:           { type: String, default: null, maxlength: 500 },
    status:          { type: String, enum: ['pending', 'confirmed', 'cancelled'], default: 'pending' },
    // Consent
    consentGiven:    { type: Boolean, required: true },
    marketingOptIn:  { type: Boolean, default: false },
    consentTimestamp:{ type: Date },
    consentIP:       { type: String },
  },
  { strict: true, timestamps: true }
);

// Encrypt PII fields at rest
workshopSchema.plugin(fieldEncryption, {
  fields: ['name', 'phone', 'email'],
  secret: process.env.FIELD_ENCRYPTION_SECRET,
  saltGenerator: (s) => s.substring(0, 16),
});

// TTL: auto-delete pending registrations after 60 days
workshopSchema.index(
  { createdAt: 1 },
  {
    expireAfterSeconds: 60 * 24 * 60 * 60,
    partialFilterExpression: { status: 'pending' },
  }
);

const WorkshopRegistration = mongoose.model('WorkshopRegistration', workshopSchema);

// ── Validation rules ─────────────────────────────────────────────────────────
const validateWorkshop = [
  body('name').trim().isLength({ min: 2, max: 100 }).escape(),
  body('role').isIn(['Teacher', 'Principal', 'Vice Principal', 'Coordinator', 'Other']),
  body('school').trim().isLength({ min: 2, max: 200 }).escape(),
  body('city').trim().isLength({ min: 1, max: 100 }).escape(),
  body('phone').matches(/^[6-9]\d{9}$/).withMessage('Invalid phone number'),
  body('email').isEmail().normalizeEmail().trim(),
  body('preferred_date').isISO8601().isAfter(new Date().toISOString()),
  body('alternative_date').optional().isISO8601().isAfter(new Date().toISOString()),
  body('teacher_count').isInt({ min: 1, max: 500 }),
  body('interests').optional().isArray({ max: 10 }),
  body('notes').optional().trim().isLength({ max: 500 }).escape(),
  body('consentGiven').equals('true').withMessage('Consent is required'),
  body('marketingOptIn').optional().isBoolean(),
  // Server-set fields — reject from client
  body('referenceId').not().exists(),
  body('status').not().exists(),
  body('consentTimestamp').not().exists(),
  body('consentIP').not().exists(),
];

// ── POST /api/workshop/register ───────────────────────────────────────────────
router.post(
  '/register',
  formRateLimiter,
  validateWorkshop,
  async (req, res, next) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(422).json({ message: 'Invalid submission. Please check your form.' });
      }

      const { body: data, ip } = req;

      // Duplicate detection: same email + same preferred_date within 24 hours
      // Return the SAME response — no info leak about whether a duplicate exists
      const existing = await WorkshopRegistration.findOne({
        email:          data.email,
        preferred_date: data.preferred_date,
        createdAt:      { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) },
      });

      if (!existing) {
        await new WorkshopRegistration({
          ...data,
          referenceId:      uuidv4(),     // Server-generated
          status:           'pending',    // Hardcoded
          consentGiven:     true,
          marketingOptIn:   data.marketingOptIn === 'true',
          consentTimestamp: new Date(),
          consentIP:        ip,
        }).save();

        // Log without PII
        logger.info('Workshop registration submitted', {
          school:        data.school,
          teacher_count: data.teacher_count,
          ip,
        });
      } else {
        logger.info('Duplicate workshop registration suppressed', { ip });
      }

      // Always return the same response — prevents enumeration
      res.status(200).json({
        message: 'Your registration has been received. We will confirm your workshop date shortly.',
      });
    } catch (err) {
      next(err);
    }
  }
);

// ── DELETE /api/workshop/:referenceId — DPDP Erasure ─────────────────────────
router.delete(
  '/:referenceId',
  authMiddleware,
  requireRole('admin'),
  async (req, res, next) => {
    try {
      const result = await WorkshopRegistration.deleteOne({ referenceId: req.params.referenceId });
      if (result.deletedCount === 0) {
        return res.status(404).json({ message: 'Record not found.' });
      }
      logger.info('DPDP erasure: workshop registration deleted', {
        referenceId: req.params.referenceId,
        deletedBy:   req.user.userId,
      });
      res.json({ message: 'Registration permanently deleted.' });
    } catch (err) {
      next(err);
    }
  }
);

export default router;
