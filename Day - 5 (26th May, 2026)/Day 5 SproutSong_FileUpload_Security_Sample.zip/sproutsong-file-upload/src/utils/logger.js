/**
 * utils/logger.js — Winston logger with PII masking
 *
 * DPDP / Security rule:
 *   Never log PII fields (email, phone, name, file paths) in plain text.
 *   This logger automatically masks known sensitive keys before writing
 *   to any log transport (console, file, CloudWatch, Papertrail, etc.)
 *
 * Usage:
 *   logger.info('Demo request received', { schoolId, ip: req.ip });
 *   logger.error('Upload failed', { error: err.message, referenceId });
 *   // DO NOT: logger.info('Received', { email: req.body.email }); ← masked automatically
 */

import { createLogger, format, transports } from 'winston';

// Fields whose values should be masked in all log output
const PII_FIELDS = new Set([
  'email', 'schoolEmail', 'contactEmail', 'fatherEmail',
  'phone', 'schoolPhone', 'primaryContact', 'altMobile',
  'mobile', 'fatherContact', 'motherContact',
  'name', 'fullName', 'contactPerson', 'fatherName', 'motherName',
  'fatherIncome', 'motherIncome',
  'photoPath', 'std8FilePath', 'std9FilePath', 'std10FilePath',
  'std11FilePath', 'std12FilePath',
  'password', 'token', 'secret',
]);

function maskPII(obj, depth = 0) {
  if (depth > 5 || obj === null || typeof obj !== 'object') return obj;
  const masked = Array.isArray(obj) ? [] : {};
  for (const [key, value] of Object.entries(obj)) {
    if (PII_FIELDS.has(key) && value) {
      masked[key] = typeof value === 'string'
        ? value.slice(0, 3) + '***'   // Show first 3 chars only
        : '***';
    } else if (typeof value === 'object') {
      masked[key] = maskPII(value, depth + 1);
    } else {
      masked[key] = value;
    }
  }
  return masked;
}

const piiMaskFormat = format((info) => {
  if (info.metadata) info.metadata = maskPII(info.metadata);
  return info;
});

export const logger = createLogger({
  level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
  format: format.combine(
    piiMaskFormat(),
    format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    format.errors({ stack: true }),
    process.env.NODE_ENV === 'production'
      ? format.json()                   // JSON for log aggregators in prod
      : format.printf(({ level, message, timestamp, ...meta }) => {
          const metaStr = Object.keys(meta).length ? ' ' + JSON.stringify(meta) : '';
          return `${timestamp} [${level.toUpperCase()}] ${message}${metaStr}`;
        })
  ),
  transports: [
    new transports.Console(),
    // Add CloudWatch / file transports for production:
    // new transports.File({ filename: 'logs/error.log', level: 'error' }),
    // new transports.File({ filename: 'logs/combined.log' }),
  ],
});
