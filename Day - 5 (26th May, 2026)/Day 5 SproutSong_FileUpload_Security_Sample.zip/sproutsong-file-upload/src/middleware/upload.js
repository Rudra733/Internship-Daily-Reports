/**
 * middleware/upload.js — Multer configuration for secure file uploads
 *
 * Security rules enforced here:
 *   1. memoryStorage() — files NEVER touch the disk; processed entirely in RAM
 *      and sent directly to S3. Avoids leaving temp files behind.
 *   2. fileFilter — basic extension allowlist (first gate)
 *   3. limits.fileSize — enforced by multer before the buffer reaches the route
 *
 * The second gate (MIME type validation from the buffer) happens in
 * services/mimeValidator.js AFTER multer hands us the buffer.
 * Both gates are required — neither alone is sufficient.
 *
 * Usage in route:
 *   import { createUploader } from '../middleware/upload.js';
 *   const upload = createUploader('marksheet');
 *   router.post('/upload', upload.single('file'), handler);
 *
 *   // For multiple named fields (counselling form):
 *   const upload = createUploader('marksheet');
 *   router.post('/submit', upload.fields([
 *     { name: 'std8FilePath',  maxCount: 1 },
 *     { name: 'std10FilePath', maxCount: 1 },
 *     { name: 'photoPath',     maxCount: 1 },
 *   ]), handler);
 */

import multer from 'multer';
import path from 'path';
import { UPLOAD_CONTEXTS } from '../config/uploadContexts.js';

/**
 * Creates a multer instance configured for the given upload context.
 * @param {keyof typeof UPLOAD_CONTEXTS} context
 */
export function createUploader(context) {
  const ctx = UPLOAD_CONTEXTS[context];
  if (!ctx) throw new Error(`Unknown upload context: ${context}`);

  return multer({
    // CRITICAL: memoryStorage — never write to disk
    storage: multer.memoryStorage(),

    limits: {
      fileSize:  ctx.maxSizeBytes,
      files:     10,   // max files per request
      fields:    20,   // max non-file fields per request
    },

    fileFilter(req, file, cb) {
      const ext = path.extname(file.originalname).toLowerCase();

      // Gate 1: Extension allowlist
      if (!ctx.allowedExtensions.includes(ext)) {
        return cb(new multer.MulterError(
          'LIMIT_UNEXPECTED_FILE',
          `Invalid file extension '${ext}'. Allowed: ${ctx.allowedExtensions.join(', ')}`
        ));
      }

      // Note: We cannot check MIME type here reliably (client-supplied).
      // Real MIME validation from the buffer happens in mimeValidator.js.
      cb(null, true);
    },
  });
}

/**
 * Multer error handler middleware — converts multer errors into clean JSON responses.
 * Place this AFTER the multer middleware in the route chain.
 *
 * Usage:
 *   router.post('/upload', uploader.single('file'), handleMulterError, routeHandler);
 */
export function handleMulterError(err, req, res, next) {
  if (err instanceof multer.MulterError) {
    const messages = {
      LIMIT_FILE_SIZE:       `File too large. Maximum allowed size for this upload type is ${err.field || 'the limit'}.`,
      LIMIT_FILE_COUNT:      'Too many files uploaded at once.',
      LIMIT_UNEXPECTED_FILE: err.message || 'Unexpected file field or invalid file type.',
      LIMIT_FIELD_COUNT:     'Too many form fields.',
    };
    return res.status(422).json({
      message: messages[err.code] || 'File upload error.',
    });
  }
  next(err);
}
