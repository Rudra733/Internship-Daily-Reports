/**
 * middleware/errorHandler.js — Central error handler
 *
 * Security rule:
 *   NEVER expose stack traces, internal error messages, MongoDB errors,
 *   or file paths to API clients. Log the full error server-side only.
 *   Return only generic, safe messages to the client.
 */

import { logger } from '../utils/logger.js';

export function errorHandler(err, req, res, next) {
  // Log the full error internally (PII fields will be masked by the logger)
  logger.error('Unhandled error', {
    message:  err.message,
    stack:    process.env.NODE_ENV !== 'production' ? err.stack : undefined,
    path:     req.path,
    method:   req.method,
    ip:       req.ip,
  });

  // CORS errors
  if (err.message?.startsWith('CORS:')) {
    return res.status(403).json({ message: 'Request origin not allowed.' });
  }

  // Validation errors (from express-validator)
  if (err.name === 'ValidationError') {
    return res.status(422).json({ message: 'Invalid submission.' });
  }

  // JWT errors (shouldn't reach here — auth middleware handles them — but just in case)
  if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
    return res.status(401).json({ message: 'Authentication failed.' });
  }

  // Generic fallback — never expose err.message to the client in production
  return res.status(500).json({
    message: process.env.NODE_ENV === 'production'
      ? 'An error occurred. Please try again.'
      : err.message,   // Show detail in development only
  });
}
