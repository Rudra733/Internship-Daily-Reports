/**
 * middleware/auth.js — JWT authentication and role-based access control
 *
 * Security rules:
 *   - All file access routes MUST use authMiddleware
 *   - Role checks prevent counsellors from accessing other counsellors' files
 *   - assignedCases is extracted from the JWT — not from the request body
 *     (so the client cannot self-assign access to any case)
 *
 * JWT payload shape:
 *   {
 *     userId:        string,
 *     role:          'admin' | 'counsellor' | 'school_admin' | 'student' | 'parent',
 *     schoolId:      string,       (for school_admin / counsellor)
 *     assignedCases: string[],     (referenceIds this counsellor is assigned to)
 *   }
 */

import jwt from 'jsonwebtoken';
import { logger } from '../utils/logger.js';

/**
 * Verifies the JWT from the Authorization header and attaches user to req.user.
 * Returns 401 if token is missing or invalid.
 */
export function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authentication required.' });
  }

  const token = authHeader.split(' ')[1];
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch (err) {
    logger.warn('JWT verification failed', { ip: req.ip, error: err.message });
    return res.status(401).json({ message: 'Invalid or expired token.' });
  }
}

/**
 * Role guard factory — restricts a route to the specified roles.
 *
 * Usage:
 *   router.get('/admin-only', authMiddleware, requireRole('admin'), handler);
 *   router.get('/counsellors', authMiddleware, requireRole('admin', 'counsellor'), handler);
 */
export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ message: 'Authentication required.' });
    if (!roles.includes(req.user.role)) {
      logger.warn('Unauthorised role access attempt', {
        userId: req.user.userId,
        role:   req.user.role,
        needed: roles,
        path:   req.path,
      });
      return res.status(403).json({ message: 'Access denied.' });
    }
    next();
  };
}

/**
 * Checks that the requesting counsellor is assigned to the given referenceId,
 * OR that the user is an admin (who can access all records).
 *
 * Returns true if access is allowed, false otherwise.
 * Use this inside route handlers for IDOR checks.
 *
 * @param {object} user - req.user from JWT
 * @param {string} referenceId - the counselling record's referenceId
 */
export function canAccessRecord(user, referenceId) {
  if (user.role === 'admin') return true;
  if (user.role === 'counsellor') {
    return Array.isArray(user.assignedCases) && user.assignedCases.includes(referenceId);
  }
  if (user.role === 'school_admin') {
    // School admin access is checked against schoolId in the record, not here.
    // Return true and let the route do the schoolId check.
    return true;
  }
  return false;
}
