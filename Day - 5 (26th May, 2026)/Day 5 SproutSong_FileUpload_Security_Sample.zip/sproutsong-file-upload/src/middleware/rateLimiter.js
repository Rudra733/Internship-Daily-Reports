/**
 * middleware/rateLimiter.js — Rate limiting for upload and form endpoints
 *
 * Security rule:
 *   File upload endpoints need tighter limits than regular API calls.
 *   A single request can consume significant server resources (memory, S3 PUT, ClamAV).
 *   Rate limiting prevents DoS via upload flooding and protects the S3 cost budget.
 *
 *   Store rate limit state in Redis in production so limits survive server
 *   restarts and work correctly across multiple instances / load balancer nodes.
 *   (This sample uses the default in-memory store for simplicity.)
 */

import rateLimit from 'express-rate-limit';

/**
 * Upload rate limiter:
 *   Max 10 file uploads per IP per 15 minutes.
 *   Much tighter than the general API limit — each upload is expensive.
 */
export const uploadRateLimiter = rateLimit({
  windowMs:        parseInt(process.env.UPLOAD_RATE_LIMIT_WINDOW_MS || '900000', 10), // 15 min
  max:             parseInt(process.env.UPLOAD_RATE_LIMIT_MAX       || '10',     10),
  standardHeaders: true,
  legacyHeaders:   false,
  message: {
    message: 'Too many file uploads from this IP. Please try again in 15 minutes.',
  },
  // In production, replace with Redis store:
  // import RedisStore from 'rate-limit-redis';
  // store: new RedisStore({ sendCommand: (...args) => redisClient.sendCommand(args) }),
});

/**
 * Form submission rate limiter:
 *   Max 5 form submissions per IP per hour.
 *   Used for counselling form, demo request form, contact form.
 */
export const formRateLimiter = rateLimit({
  windowMs:        60 * 60 * 1000,  // 1 hour
  max:             5,
  standardHeaders: true,
  legacyHeaders:   false,
  message: {
    message: 'Too many submissions from this IP. Please try again in an hour.',
  },
});

/**
 * File download rate limiter:
 *   Max 30 signed URL requests per user per 15 minutes.
 *   Prevents bulk scraping of student documents via the signed URL endpoint.
 */
export const downloadRateLimiter = rateLimit({
  windowMs:        15 * 60 * 1000,  // 15 min
  max:             30,
  standardHeaders: true,
  legacyHeaders:   false,
  message: {
    message: 'Too many download requests. Please slow down.',
  },
  keyGenerator: (req) => req.user?.userId || req.ip, // Limit per user, not just IP
});
