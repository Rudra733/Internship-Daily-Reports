/**
 * models/CounsellingRequest.js — Mongoose schema for the counselling form
 *
 * Security rules enforced here:
 *   1. strict: true — rejects any fields not defined in this schema
 *   2. PII fields (email, phone, names) encrypted at rest via mongoose-field-encryption
 *   3. File path fields store ONLY the S3 key — never a URL or original filename
 *   4. referenceId is server-generated UUID — never accepted from client
 *   5. isMinor is derived server-side from dob — never accepted from client
 *   6. adminStatus and status are server-set only — routes reject them from client
 *   7. Financial fields (fatherIncome, motherIncome) are nulled on case closure
 *   8. consentGiven, parentConsentGiven, docConsentGiven are required before save
 *   9. TTL index auto-deletes draft records after 30 days (data minimisation)
 *
 * Dependency: npm install mongoose mongoose-field-encryption
 */

import mongoose from 'mongoose';
import { fieldEncryption } from 'mongoose-field-encryption';

const { Schema } = mongoose;

const counsellingSchema = new Schema(
  {
    // ── Section 1: Student identity ─────────────────────────────────────────
    referenceId:   { type: String, required: true, unique: true, index: true },
    fullName:      { type: String, required: true, trim: true, maxlength: 100 },
    dob:           { type: Date,   required: true },
    gender:        { type: String, required: true, enum: ['male', 'female', 'other'] },
    mobile:        { type: String, required: true, trim: true },
    email:         { type: String, required: true, trim: true, lowercase: true },
    photoPath:     { type: String, default: null }, // S3 key only — NOT a URL

    // Derived server-side from dob — never accepted from client
    isMinor:       { type: Boolean, required: true },

    // ── Section 2: Parent / guardian ────────────────────────────────────────
    fatherName:       { type: String, required: true,  trim: true, maxlength: 100 },
    fatherOccupation: { type: String, required: true,  trim: true },
    fatherIncome:     { type: String, default: null },   // Encrypted; nulled on closure
    fatherContact:    { type: String, required: true,  trim: true },
    fatherEmail:      { type: String, default: null,   trim: true, lowercase: true },
    motherName:       { type: String, required: true,  trim: true, maxlength: 100 },
    motherOccupation: { type: String, default: null,   trim: true },
    motherIncome:     { type: String, default: null },   // Encrypted; nulled on closure
    motherContact:    { type: String, default: null,   trim: true },

    // ── Section 3: Home address ──────────────────────────────────────────────
    house:     { type: String, required: true, trim: true },
    landmark:  { type: String, default: null,  trim: true },
    village:   { type: String, required: true, trim: true },
    city:      { type: String, required: true, trim: true },
    district:  { type: String, required: true, trim: true },
    state:     { type: String, required: true, trim: true },
    pincode:   { type: String, required: true, trim: true },

    // ── Section 4: Academic profile ──────────────────────────────────────────
    standard:     { type: String, required: true, enum: ['10th', '12th'] },
    board:        { type: String, required: true, enum: ['CBSE', 'GSEB', 'ICSE', 'SSC', 'NIOS', 'CIE', 'IB', 'CISCE', 'Other'] },
    school:       { type: String, required: true, trim: true, maxlength: 200 },
    medium:       { type: String, required: true, enum: ['english', 'gujarati'] },
    year:         { type: String, required: true, enum: ['2024-25', '2025-26'] },
    stream:       { type: String, default: null, enum: ['science', 'commerce', 'arts', 'vocational', null] },
    scienceGroup: { type: [String], default: [] },

    // ── Section 5: Document file paths (S3 keys — NOT URLs) ─────────────────
    std8FilePath:  { type: String, required: true, default: null },
    std9FilePath:  { type: String, required: true, default: null },
    std10FilePath: { type: String, required: true },
    std11FilePath: { type: String, default: null },  // Required for 12th standard
    std12FilePath: { type: String, default: null },
    percentage:    { type: String, default: null },

    // ── Section 6: Career preferences ───────────────────────────────────────
    interests:        { type: [String], default: [] },
    preferredCity:    { type: String,   default: null, maxlength: 100 },
    preferredCollege: { type: String,   default: null, maxlength: 200 },
    budget:           { type: String,   default: null },

    // ── Section 7: Submission metadata ──────────────────────────────────────
    query:     { type: String, default: null, maxlength: 1000 },
    howHeard:  { type: String, default: null },
    status:    { type: String, enum: ['draft', 'submitted', 'counselled', 'closed'], default: 'draft' },

    // ── Consent record (DPDP requirement) ───────────────────────────────────
    consentGiven:       { type: Boolean, required: true },
    parentConsentGiven: { type: Boolean, default: null }, // Required if isMinor = true
    docConsentGiven:    { type: Boolean, required: true },
    consentTimestamp:   { type: Date },
    consentIP:          { type: String },

    // ── Admin metadata (server-set only — never from client) ─────────────────
    assignedCounsellorId: { type: String, default: null },
    adminNotes:           { type: String, default: null, maxlength: 2000 },
    closedAt:             { type: Date,   default: null },
  },
  {
    strict:     true,        // Rejects any fields not defined above
    timestamps: true,        // Adds createdAt, updatedAt
  }
);

// ── Field-level encryption for PII ──────────────────────────────────────────
// These fields are encrypted before saving and decrypted on read.
// The encryption key must be exactly 32 characters.
// Store the key in process.env.FIELD_ENCRYPTION_SECRET — never in code.
counsellingSchema.plugin(fieldEncryption, {
  fields: [
    'fullName', 'mobile', 'email', 'photoPath',
    'fatherName', 'fatherContact', 'fatherEmail', 'fatherIncome',
    'motherName', 'motherContact', 'motherIncome',
    'house', 'landmark', 'village',
    'std8FilePath', 'std9FilePath', 'std10FilePath',
    'std11FilePath', 'std12FilePath',
  ],
  secret:        process.env.FIELD_ENCRYPTION_SECRET,
  saltGenerator: (secret) => secret.substring(0, 16),
});

// ── Indexes ──────────────────────────────────────────────────────────────────
// TTL: auto-delete DRAFT records 30 days after creation (data minimisation)
counsellingSchema.index(
  { createdAt: 1 },
  {
    expireAfterSeconds: 30 * 24 * 60 * 60, // 30 days
    partialFilterExpression: { status: 'draft' },
  }
);

// Index for school admin queries
counsellingSchema.index({ school: 1 });
counsellingSchema.index({ assignedCounsellorId: 1 });

// ── Instance methods ─────────────────────────────────────────────────────────

/**
 * Null financial fields on case closure (data minimisation).
 * Call when status transitions to 'closed' or 'counselled'.
 */
counsellingSchema.methods.clearFinancialData = async function () {
  this.fatherIncome = null;
  this.motherIncome = null;
  this.closedAt = new Date();
  await this.save();
};

/**
 * Returns a safe version of the record for API responses.
 * Strips fields that should never be returned to the client.
 */
counsellingSchema.methods.toSafeObject = function () {
  const obj = this.toObject();
  // Never return S3 keys to the client — use the /files/:referenceId/:field route instead
  delete obj.std8FilePath;
  delete obj.std9FilePath;
  delete obj.std10FilePath;
  delete obj.std11FilePath;
  delete obj.std12FilePath;
  delete obj.photoPath;
  // Never return consent IP to the client
  delete obj.consentIP;
  // Never return financial data to non-admin clients
  delete obj.fatherIncome;
  delete obj.motherIncome;
  delete obj._id;
  delete obj.__v;
  return obj;
};

export default mongoose.model('CounsellingRequest', counsellingSchema);
