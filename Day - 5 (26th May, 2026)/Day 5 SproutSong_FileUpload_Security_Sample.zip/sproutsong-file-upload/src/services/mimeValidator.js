/**
 * services/mimeValidator.js — Server-side MIME type validation from file buffer
 *
 * WHY THIS IS NECESSARY:
 *   The Content-Type header and file extension are both client-supplied.
 *   An attacker can rename a .php file to .pdf or set Content-Type: application/pdf
 *   on an executable. We detect the REAL type by reading the file's magic bytes
 *   (the first few bytes of the buffer) using the 'file-type' library.
 *
 * This is Gate 2 of the two-gate validation:
 *   Gate 1 (multer fileFilter): extension allowlist  → runs before buffer exists
 *   Gate 2 (this module):       buffer magic bytes   → runs after buffer is in memory
 *
 * Both gates must pass. Neither alone is sufficient.
 *
 * Dependency: npm install file-type
 */

import { fileTypeFromBuffer } from 'file-type';
import { UPLOAD_CONTEXTS, BLOCKED_MIME_TYPES } from '../config/uploadContexts.js';
import { logger } from '../utils/logger.js';

/**
 * Validates the MIME type of a file buffer for a given upload context.
 *
 * @param {Buffer} buffer  - The file buffer from multer (req.file.buffer)
 * @param {string} context - Upload context key (e.g. 'marksheet', 'photo')
 * @param {string} ip      - Request IP for logging
 * @returns {string} The detected MIME type (trusted, from magic bytes)
 * @throws {Error} If the MIME type is invalid, blocked, or undetectable
 */
export async function validateMimeType(buffer, context, ip = 'unknown') {
  const ctx = UPLOAD_CONTEXTS[context];
  if (!ctx) throw new Error(`Unknown upload context: ${context}`);

  // Detect MIME from magic bytes — not from the header or extension
  const detected = await fileTypeFromBuffer(buffer);

  if (!detected) {
    logger.warn('MIME detection failed — file type undetectable', { context, ip });
    throw new Error('Cannot determine file type. Only PDF, JPG, and PNG are allowed.');
  }

  // Hard block: reject mime types that are always dangerous regardless of context
  if (BLOCKED_MIME_TYPES.includes(detected.mime)) {
    logger.warn('Blocked MIME type detected', { detectedMime: detected.mime, context, ip });
    throw new Error(`File type '${detected.mime}' is not permitted on this platform.`);
  }

  // Context-specific allowlist check
  if (!ctx.allowedMimeTypes.includes(detected.mime)) {
    logger.warn('MIME type not allowed for context', {
      detectedMime: detected.mime,
      context,
      allowed: ctx.allowedMimeTypes,
      ip,
    });
    throw new Error(
      `File type '${detected.mime}' is not allowed for ${context} uploads. ` +
      `Allowed types: ${ctx.allowedMimeTypes.join(', ')}`
    );
  }

  return detected.mime;
}

/**
 * Validate all files in a req.files map (from upload.fields()).
 * Returns a map of { fieldName: detectedMimeType }.
 *
 * @param {object} files    - req.files (multer fields map)
 * @param {string} context  - Upload context for all fields
 * @param {string} ip       - Request IP
 */
export async function validateAllFiles(files, context, ip) {
  const results = {};
  for (const [fieldName, fileArr] of Object.entries(files || {})) {
    for (const file of fileArr) {
      const mime = await validateMimeType(file.buffer, context, ip);
      results[fieldName] = mime;
    }
  }
  return results;
}
