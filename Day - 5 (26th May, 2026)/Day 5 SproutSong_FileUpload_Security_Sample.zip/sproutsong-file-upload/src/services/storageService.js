/**
 * services/storageService.js — Private S3 bucket operations
 *
 * All file storage interactions go through this service.
 * Routes and controllers NEVER interact with S3 directly.
 *
 * Key security rules enforced here:
 *   1. Files are stored under a structured private path — never /public/ or /uploads/
 *      Pattern: private/schools/{schoolId}/students/{studentId}/{context}/{uuid}.ext
 *
 *   2. All objects are uploaded with AES-256 server-side encryption.
 *
 *   3. The S3 key (path) is returned and stored in MongoDB.
 *      A signed URL is generated separately on demand — the key is never
 *      returned to the client directly.
 *
 *   4. Signed URLs expire in 15 minutes (SIGNED_URL_EXPIRY).
 *
 *   5. Cascade delete: deleteFile() removes the S3 object AND must be called
 *      before or alongside the MongoDB record deletion to prevent orphaned files.
 */

import {
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
  HeadObjectCommand,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';
import { s3, PRIVATE_BUCKET, SIGNED_URL_EXPIRY } from '../config/s3.js';
import { UPLOAD_CONTEXTS } from '../config/uploadContexts.js';
import { logger } from '../utils/logger.js';

/**
 * Builds the S3 object key for a file.
 * Pattern enforces the File Access Rule from the DPDP guide:
 *   /private/schools/{schoolId}/students/{studentId}/{context}/{uuid}.ext
 *
 * @param {string} mimeType   - Validated MIME type (from mimeValidator)
 * @param {string} schoolId
 * @param {string} studentId  - Can be referenceId or userId
 * @param {string} context    - e.g. 'marksheet', 'photo'
 * @returns {string} The S3 key
 */
function buildS3Key(mimeType, schoolId, studentId, context) {
  // Derive extension from MIME — never from the original filename
  const extMap = {
    'application/pdf': '.pdf',
    'image/jpeg':      '.jpg',
    'image/png':       '.png',
  };
  const ext = extMap[mimeType] || '.bin';

  const ctx = UPLOAD_CONTEXTS[context];
  const prefix = ctx?.s3Prefix || context;

  // UUID as the filename — original filename is discarded entirely
  return `private/schools/${schoolId}/students/${studentId}/${prefix}/${uuidv4()}${ext}`;
}

/**
 * Uploads a file buffer to the private S3 bucket.
 *
 * @param {object} params
 * @param {Buffer} params.buffer        - File buffer from multer memoryStorage
 * @param {string} params.mimeType      - Validated MIME type
 * @param {string} params.schoolId
 * @param {string} params.studentId
 * @param {string} params.context       - Upload context key
 * @param {object} params.metadata      - Optional S3 object metadata (no PII)
 * @returns {Promise<string>} The S3 key — store this in MongoDB, not a URL
 */
export async function uploadFile({ buffer, mimeType, schoolId, studentId, context, metadata = {} }) {
  const key = buildS3Key(mimeType, schoolId, studentId, context);

  await s3.send(new PutObjectCommand({
    Bucket:                  PRIVATE_BUCKET,
    Key:                     key,
    Body:                    buffer,
    ContentType:             mimeType,
    ServerSideEncryption:    'AES256',           // Encrypt at rest
    // No ACL property → bucket default applies (private)
    Metadata: {
      schoolId,
      studentId,
      context,
      uploadedAt: new Date().toISOString(),
      ...metadata,
    },
  }));

  logger.info('File uploaded to private bucket', {
    key,
    context,
    schoolId,
    // Never log studentId, filenames, or content
  });

  // Return the key — caller stores this in MongoDB
  // NEVER return a public URL or the buffer
  return key;
}

/**
 * Generates a pre-signed download URL for an S3 object.
 * The URL expires in SIGNED_URL_EXPIRY seconds (default: 900 = 15 minutes).
 *
 * IMPORTANT: This function ONLY generates the URL.
 * The CALLER (the route handler) is responsible for:
 *   1. Authenticating the user (JWT)
 *   2. Checking IDOR (does this user own / have access to this key?)
 *   3. Only then calling this function
 *
 * @param {string} key - S3 object key (from MongoDB record)
 * @returns {Promise<string>} A time-limited signed URL
 */
export async function getSignedDownloadUrl(key) {
  const url = await getSignedUrl(
    s3,
    new GetObjectCommand({ Bucket: PRIVATE_BUCKET, Key: key }),
    { expiresIn: SIGNED_URL_EXPIRY }
  );
  return url;
}

/**
 * Deletes a file from S3.
 *
 * DPDP Right to Erasure:
 *   This MUST be called before or alongside the MongoDB record deletion.
 *   A DB deletion without S3 deletion is an incomplete erasure.
 *
 * @param {string} key - S3 object key to delete
 */
export async function deleteFile(key) {
  if (!key) return;   // null/undefined keys are a no-op

  await s3.send(new DeleteObjectCommand({
    Bucket: PRIVATE_BUCKET,
    Key:    key,
  }));

  logger.info('File deleted from bucket', { key });
}

/**
 * Checks whether an S3 object exists without downloading it.
 * Used in virus scanning pipeline to check scan-status tag.
 *
 * @param {string} key
 * @returns {Promise<boolean>}
 */
export async function fileExists(key) {
  try {
    await s3.send(new HeadObjectCommand({ Bucket: PRIVATE_BUCKET, Key: key }));
    return true;
  } catch {
    return false;
  }
}

/**
 * Cascade delete — removes all files associated with a student record.
 *
 * @param {object} record - Mongoose document with file path fields
 * @returns {Promise<number>} Count of files deleted
 */
export async function cascadeDeleteStudentFiles(record) {
  const FILE_FIELDS = [
    'std8FilePath', 'std9FilePath', 'std10FilePath',
    'std11FilePath', 'std12FilePath', 'photoPath',
  ];

  const deletions = FILE_FIELDS
    .filter(field => record[field])
    .map(field => deleteFile(record[field]));

  await Promise.allSettled(deletions);  // allSettled — don't abort on partial failure

  const count = deletions.length;
  logger.info('Cascade file deletion complete', {
    referenceId: record.referenceId,
    filesDeleted: count,
  });

  return count;
}
