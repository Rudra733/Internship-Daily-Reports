/**
 * services/scanService.js — Virus / malware scanning via ClamAV
 *
 * Security rule (from DPDP guide, Part H):
 *   Virus scanning is RECOMMENDED for all student document uploads
 *   (marksheets, photos, counselling reports).
 *
 *   A malicious PDF can carry embedded scripts or exploits that
 *   execute when opened by a counsellor or admin.
 *
 * Two modes:
 *   1. ClamAV (self-hosted): scan buffer before uploading to S3
 *   2. Lambda-based (cloud): upload to S3 first, Lambda scans on PutObject event
 *
 * This file implements Mode 1 (scan-first).
 * Set USE_CLAMAV=false in .env to skip scanning in local development.
 *
 * Dependency: npm install clamscan
 */

import NodeClam from 'clamscan';
import { logger } from '../utils/logger.js';

let clamInstance = null;

/**
 * Initialise ClamAV connection (call once at app startup).
 * Silently skips if USE_CLAMAV=false (development mode).
 */
export async function initClamAV() {
  if (process.env.USE_CLAMAV !== 'true') {
    logger.warn('ClamAV scanning DISABLED (USE_CLAMAV=false). Enable in production.');
    return;
  }

  try {
    clamInstance = await new NodeClam().init({
      removeInfected:  false,                // We manage deletion ourselves
      quarantineInfected: false,
      scanLog:         null,
      debugMode:       false,
      clamdscan: {
        host:    process.env.CLAMAV_HOST || 'localhost',
        port:    parseInt(process.env.CLAMAV_PORT || '3310', 10),
        timeout: 60000,   // 60s timeout per scan
        active:  true,
      },
    });
    logger.info('ClamAV initialised successfully');
  } catch (err) {
    logger.error('ClamAV initialisation failed', { error: err.message });
    // In production, fail open or fail closed depending on your risk tolerance.
    // Fail closed (throw): safer, but if ClamAV goes down uploads stop.
    // Fail open (warn):   uploads continue but unscanned — log and alert.
    if (process.env.NODE_ENV === 'production') {
      throw new Error('Virus scanner unavailable — uploads blocked for safety.');
    }
  }
}

/**
 * Scans a file buffer for viruses/malware.
 * Must be called BEFORE uploading to S3.
 *
 * @param {Buffer} buffer        - File buffer from multer
 * @param {string} fieldName     - For logging only (no PII)
 * @param {string} ip            - Request IP for logging
 * @throws {Error} If the file is infected or the scanner is unavailable
 */
export async function scanBuffer(buffer, fieldName = 'file', ip = 'unknown') {
  // Skip in development / if ClamAV is disabled
  if (process.env.USE_CLAMAV !== 'true') {
    logger.debug('Virus scan skipped (dev mode)', { fieldName });
    return;
  }

  if (!clamInstance) {
    throw new Error('Virus scanner not initialised. Call initClamAV() at startup.');
  }

  try {
    const { isInfected, viruses } = await clamInstance.scanBuffer(buffer);

    if (isInfected) {
      // Log the incident — virus name is not PII
      logger.error('VIRUS DETECTED — file rejected', {
        fieldName,
        viruses,
        ip,
        fileSize: buffer.length,
      });
      // Alert the security team (integrate with SNS / PagerDuty / Slack here)
      // await alertSecurityTeam({ fieldName, viruses, ip });

      throw new Error('File failed security scan and has been rejected.');
    }

    logger.info('Virus scan passed', { fieldName, fileSize: buffer.length });
  } catch (err) {
    if (err.message.includes('failed security scan')) throw err;  // Re-throw infected error
    logger.error('Virus scan error', { error: err.message, fieldName });
    throw new Error('File security scan encountered an error. Please try again.');
  }
}

/**
 * Scans all files in a multer req.files map.
 *
 * @param {object} files - req.files from upload.fields()
 * @param {string} ip
 */
export async function scanAllFiles(files, ip) {
  for (const [fieldName, fileArr] of Object.entries(files || {})) {
    for (const file of fileArr) {
      await scanBuffer(file.buffer, fieldName, ip);
    }
  }
}
