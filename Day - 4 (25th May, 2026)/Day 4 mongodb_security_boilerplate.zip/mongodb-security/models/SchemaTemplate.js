'use strict';

/**
 * ============================================================
 *  models/SchemaTemplate.js
 *
 *  Copy-paste template for every new Mongoose model.
 *  Replace COLLECTION_NAME and add your fields inside
 *  the CUSTOM FIELDS section.
 *
 *  Every model in SproutSong must follow these rules:
 *   ✓ schoolId  — required, indexed (multi-tenancy)
 *   ✓ status    — enum, not free-text
 *   ✓ strings   — trim + maxlength always
 *   ✓ numbers   — min + max always
 *   ✓ sensitive — select: false
 *   ✓ timestamps: true
 *   ✓ strict: true
 *   ✓ toJSON strips __v
 * ============================================================
 */

const mongoose   = require('mongoose');
const auditPlugin = require('./plugins/auditPlugin');

const SchemaTemplateSchema = new mongoose.Schema(
  {
    // ── REQUIRED on every model ───────────────────────────────

    // Multi-tenancy anchor — filters all queries to one school
    schoolId: {
      type:     mongoose.Schema.Types.ObjectId,
      ref:      'School',
      required: true,
      index:    true,
    },

    // Status as enum — never allow arbitrary strings
    status: {
      type:    String,
      enum:    ['active', 'inactive', 'archived'],
      default: 'active',
      index:   true,
    },

    // Audit trail — who created/last updated this record
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },

    // ── CUSTOM FIELDS — add your fields here ─────────────────

    // String example — always trim + maxlength
    name: {
      type:      String,
      required:  true,
      trim:      true,
      maxlength: 200,
    },

    // Number example — always min + max
    amount: {
      type:    Number,
      default: 0,
      min:     0,
      max:     9_999_999,
    },

    // Enum string example
    category: {
      type: String,
      enum: ['typeA', 'typeB', 'typeC'],
    },

    // Sensitive string — select: false (never returned by default)
    internalNotes: {
      type:      String,
      select:    false,
      maxlength: 2000,
    },

    // ObjectId reference
    relatedId: {
      type:  mongoose.Schema.Types.ObjectId,
      ref:   'OtherModel',
      index: true,
    },
  },
  {
    // Auto createdAt + updatedAt on every document
    timestamps: true,

    // Reject any field not defined above
    strict: true,

    // Strip __v from all JSON output
    toJSON: {
      transform(_doc, ret) {
        delete ret.__v;
        return ret;
      },
    },
  }
);

// ── Indexes ───────────────────────────────────────────────────
// schoolId FIRST in all compound indexes (multi-tenancy)
SchemaTemplateSchema.index({ schoolId: 1, status: 1 });
SchemaTemplateSchema.index({ schoolId: 1, createdAt: -1 });

// ── Audit plugin (attach to sensitive models only) ────────────
// SchemaTemplateSchema.plugin(auditPlugin, { module: 'your-module-name' });

// ── Pre-save hook example ─────────────────────────────────────
SchemaTemplateSchema.pre('save', function (next) {
  // Example: normalize name before saving
  if (this.isModified('name')) {
    this.name = this.name.trim();
  }
  next();
});

module.exports = mongoose.model('SchemaTemplate', SchemaTemplateSchema);
