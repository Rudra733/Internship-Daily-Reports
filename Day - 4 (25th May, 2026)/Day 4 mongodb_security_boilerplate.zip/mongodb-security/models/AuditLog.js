'use strict';

/**
 * ============================================================
 *  models/AuditLog.js
 *
 *  Append-only audit log collection.
 *  TTL index auto-deletes entries after 90 days.
 *  Sensitive targets stored AES-256-GCM encrypted.
 * ============================================================
 */

const mongoose = require('mongoose');

const AuditLogSchema = new mongoose.Schema(
  {
    userId:   { type: mongoose.Schema.Types.ObjectId, ref: 'User',   index: true },
    schoolId: { type: mongoose.Schema.Types.ObjectId, ref: 'School', index: true },
    role:     { type: String },
    action: {
      type: String,
      enum: ['READ', 'WRITE', 'DELETE', 'LOGIN', 'LOGOUT',
             'LOGIN_FAILED', 'PERMISSION_DENIED', 'TOKEN_INVALID', 'ROLE_CHANGE'],
      required: true,
      index:    true,
    },
    result:   { type: String, enum: ['allowed', 'denied', 'error'], required: true },
    reason:   { type: String, maxlength: 500 },
    module:   { type: String, index: true },
    endpoint: { type: String, maxlength: 200 },
    method:   { type: String, enum: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'] },
    ip:       { type: String, maxlength: 50 },  // last octet masked: 192.168.1.xxx

    // AES-256-GCM encrypted — decryptable by compliance officer only
    // Format: "v1:<iv>:<authTag>:<data>"
    encryptedTarget: { type: String, select: false },

    ts: { type: Date, default: Date.now, index: true },
  },
  {
    timestamps: { createdAt: 'createdAt', updatedAt: false }, // append-only
    strict: true,
    toJSON: { transform(_doc, ret) { delete ret.__v; return ret; } },
  }
);

// TTL — auto-delete after 90 days
AuditLogSchema.index({ ts: 1 }, { expireAfterSeconds: 60 * 60 * 24 * 90 });
AuditLogSchema.index({ userId: 1, ts: -1 });
AuditLogSchema.index({ schoolId: 1, action: 1, ts: -1 });
AuditLogSchema.index({ result: 1, ts: -1 });

// ── Static helpers ────────────────────────────────────────────
AuditLogSchema.statics.log = async function (data) {
  try {
    await this.create(data);
  } catch (err) {
    console.error('[AuditLog] create failed:', err.message);
  }
};

AuditLogSchema.statics.logDenial = function ({ userId, schoolId, role, module, endpoint, method, reason, ip }) {
  return this.log({ userId, schoolId, role, module, endpoint, method, reason, ip, action: 'PERMISSION_DENIED', result: 'denied', ts: new Date() });
};

AuditLogSchema.statics.logSensitiveAccess = function ({ userId, schoolId, role, module, endpoint, method, action, targetValue, ip }) {
  const { encrypt } = require('../utils/fieldEncryption');
  return this.log({
    userId, schoolId, role, module, endpoint, method, action,
    result:          'allowed',
    encryptedTarget: targetValue ? encrypt(String(targetValue)) : undefined,
    ip,
    ts: new Date(),
  });
};

module.exports = mongoose.model('AuditLog', AuditLogSchema);
