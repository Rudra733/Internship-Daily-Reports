'use strict';

/**
 * ============================================================
 *  models/User.js
 *
 *  Mongoose User model demonstrating all MongoDB security
 *  best practices for SproutSong:
 *
 *   - password:      bcrypt hashed, select: false
 *   - tokenVersion:  for JWT invalidation, select: false
 *   - aadhaar:       last 4 only, full Aadhaar never stored
 *   - otp:           hashed + expiry + used flag
 *   - resetToken:    hashed + expiry + used flag
 *   - schoolId:      multi-tenancy anchor, required + indexed
 *   - role:          strict enum, never free-text
 *   - strict: true   (global, rejects unknown fields)
 * ============================================================
 */

const mongoose = require('mongoose');
const { hashPassword, comparePassword } = require('../utils/sensitiveFieldHelpers');

const ROLES = [
  'super_admin', 'school_admin', 'principal', 'teacher', 'coordinator',
  'counsellor', 'accountant', 'librarian', 'sports', 'extra_curricular',
  'analytics', 'hostel_warden', 'sales_admission', 'marketing', 'exam_admin',
  'parent', 'student',
];

const UserSchema = new mongoose.Schema(
  {
    // ── Identity ──────────────────────────────────────────────
    name:  { type: String, required: true, trim: true, maxlength: 200 },
    email: {
      type:      String,
      required:  true,
      unique:    true,
      lowercase: true,
      trim:      true,
      match:     [/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Invalid email format'],
    },

    // ── Password — NEVER returned in queries ──────────────────
    password: {
      type:     String,
      required: true,
      select:   false,  // must explicitly .select('+password') to read
      minlength: 8,
    },

    // ── RBAC ─────────────────────────────────────────────────
    role: {
      type:     String,
      enum:     ROLES,
      required: true,
      index:    true,
    },

    // Multi-tenancy anchor — every non-super_admin user belongs to a school
    schoolId: {
      type:     mongoose.Schema.Types.ObjectId,
      ref:      'School',
      index:    true,
      required: function () { return this.role !== 'super_admin'; },
    },

    // ── Token versioning — increment to invalidate all JWTs ───
    tokenVersion: {
      type:    Number,
      default: 0,
      select:  false, // never returned in API responses
    },

    isActive: { type: Boolean, default: true, index: true },

    // ── Aadhaar — last 4 digits ONLY ─────────────────────────
    // Full 12-digit Aadhaar is NEVER stored (UIDAI compliance)
    aadhaarLast4: {
      type:    String,
      match:   [/^\d{4}$/, 'Must be exactly 4 digits'],
      select:  false,
    },
    isAadhaarVerified: { type: Boolean, default: false },

    // ── OTP — hashed, never plain text ───────────────────────
    otpHash:   { type: String, select: false },
    otpExpiry: { type: Date,   select: false },
    otpUsed:   { type: Boolean, default: false, select: false },

    // ── Password reset token — hashed, short-lived ───────────
    resetTokenHash:   { type: String, select: false },
    resetTokenExpiry: { type: Date,   select: false },
    resetTokenUsed:   { type: Boolean, default: false, select: false },

    // ── Role-specific scoping ─────────────────────────────────
    assignedClassIds:       [{ type: mongoose.Schema.Types.ObjectId, ref: 'Class' }],
    childIds:               [{ type: mongoose.Schema.Types.ObjectId, ref: 'Student' }],
    assignedHostelBlockIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'HostelBlock' }],
    assignedExamIds:        [{ type: mongoose.Schema.Types.ObjectId, ref: 'Exam' }],

    // ── Audit ─────────────────────────────────────────────────
    lastLogin: { type: Date },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
    strict:     true,  // rejects any field not in schema
    toJSON: {
      transform(_doc, ret) {
        // Strip sensitive fields from any JSON output
        delete ret.password;
        delete ret.tokenVersion;
        delete ret.otpHash;
        delete ret.otpExpiry;
        delete ret.otpUsed;
        delete ret.resetTokenHash;
        delete ret.resetTokenExpiry;
        delete ret.resetTokenUsed;
        delete ret.aadhaarLast4;
        delete ret.__v;
        return ret;
      },
    },
  }
);

// ── Indexes ───────────────────────────────────────────────────
UserSchema.index({ schoolId: 1, role: 1 });
UserSchema.index({ schoolId: 1, isActive: 1 });
UserSchema.index({ email: 1 }, { unique: true });

// ── Hash password before save ─────────────────────────────────
UserSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await hashPassword(this.password);
  next();
});

// ── Instance methods ──────────────────────────────────────────
UserSchema.methods.comparePassword = function (candidate) {
  return comparePassword(candidate, this.password);
};

// Increment tokenVersion — invalidates all existing JWTs immediately
UserSchema.methods.invalidateTokens = function () {
  this.tokenVersion += 1;
  return this.save();
};

module.exports = mongoose.model('User', UserSchema);
