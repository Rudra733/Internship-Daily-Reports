'use strict';

/**
 * ============================================================
 *  models/plugins/auditPlugin.js
 *
 *  Reusable Mongoose plugin — auto-logs all write and delete
 *  operations on sensitive collections to AuditLog.
 *
 *  Attach to any sensitive schema:
 *    CounsellingSchema.plugin(auditPlugin, { module: 'management' });
 *    ExamResultSchema.plugin(auditPlugin,  { module: 'examinations' });
 *    FeeRecordSchema.plugin(auditPlugin,   { module: 'accountant' });
 *
 *  In your controller, pass userId before saving:
 *    const doc = new Counselling({ ...data });
 *    doc._userId = req.user.id;
 *    await doc.save();
 * ============================================================
 */

function auditPlugin(schema, options = {}) {
  const { module: moduleName = 'unknown' } = options;

  // Virtual to carry userId from controller into post-save hook
  schema.virtual('_userId').get(function () { return this.__userId; })
                            .set(function (v) { this.__userId = v; });

  // ── After save (create + update) ─────────────────────────
  schema.post('save', async function (doc) {
    try {
      const AuditLog = require('../AuditLog');
      await AuditLog.log({
        userId:   this._userId || null,
        schoolId: doc.schoolId,
        action:   'WRITE',
        result:   'allowed',
        module:   moduleName,
        method:   this.$locals?.isNew ? 'POST' : 'PATCH',
        ts:       new Date(),
      });
    } catch (err) {
      console.error(`[auditPlugin:${moduleName}] post-save log failed:`, err.message);
    }
  });

  // ── After findOneAndUpdate ────────────────────────────────
  schema.post('findOneAndUpdate', async function (doc) {
    if (!doc) return;
    try {
      const AuditLog = require('../AuditLog');
      await AuditLog.log({
        schoolId: doc.schoolId,
        action:   'WRITE',
        result:   'allowed',
        module:   moduleName,
        method:   'PATCH',
        ts:       new Date(),
      });
    } catch (err) {
      console.error(`[auditPlugin:${moduleName}] post-findOneAndUpdate log failed:`, err.message);
    }
  });

  // ── After deleteOne ───────────────────────────────────────
  schema.post('deleteOne', { document: true, query: false }, async function () {
    try {
      const AuditLog = require('../AuditLog');
      await AuditLog.log({
        userId:   this._userId || null,
        schoolId: this.schoolId,
        action:   'DELETE',
        result:   'allowed',
        module:   moduleName,
        method:   'DELETE',
        ts:       new Date(),
      });
    } catch (err) {
      console.error(`[auditPlugin:${moduleName}] post-deleteOne log failed:`, err.message);
    }
  });
}

module.exports = auditPlugin;
