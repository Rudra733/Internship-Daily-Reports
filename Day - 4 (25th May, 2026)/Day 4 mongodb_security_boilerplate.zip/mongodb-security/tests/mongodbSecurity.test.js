'use strict';

/**
 * ============================================================
 *  tests/mongodbSecurity.test.js
 *  Run: node --test tests/mongodbSecurity.test.js
 * ============================================================
 */

const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

// Set up env before requiring modules
process.env.FIELD_ENCRYPTION_KEY = 'a'.repeat(64);
process.env.HMAC_SECRET_KEY      = 'b'.repeat(64);

const { encrypt, decrypt, isEncrypted, encryptedField }
  = require('../utils/fieldEncryption');
const {
  hashPassword, comparePassword,
  generateOtp, hashOtp, createOtpPayload, verifyOtp,
  generateResetToken, verifyResetToken, sanitizeAadhaar,
} = require('../utils/sensitiveFieldHelpers');

// ============================================================
//  Field Encryption
// ============================================================
describe('fieldEncryption — encrypt/decrypt', () => {
  it('produces a v1: versioned envelope', () => {
    const env = encrypt('hello world');
    assert.ok(env.startsWith('v1:'), `Expected v1: prefix, got: ${env.slice(0, 10)}`);
  });

  it('has 4 colon-separated parts', () => {
    const parts = encrypt('test').split(':');
    assert.equal(parts.length, 4);
  });

  it('round-trips correctly', () => {
    const original = 'Counselling note — Jane Doe — session 3';
    assert.equal(decrypt(encrypt(original)), original);
  });

  it('produces different ciphertext each call (random IV)', () => {
    const a = encrypt('same input');
    const b = encrypt('same input');
    assert.notEqual(a, b, 'Different IVs must produce different envelopes');
  });

  it('ciphertext does not contain the original value', () => {
    const env = encrypt('SensitiveData123');
    assert.ok(!env.includes('SensitiveData123'));
  });

  it('handles empty string', () => {
    const env = encrypt('');
    const dec = decrypt(env);
    assert.equal(dec, '');
  });

  it('returns null for null input', () => {
    assert.equal(encrypt(null), null);
    assert.equal(decrypt(null), null);
  });

  it('throws on tampered auth tag', () => {
    const env   = encrypt('test data');
    const parts = env.split(':');
    parts[2]    = 'f'.repeat(parts[2].length); // corrupt auth tag
    assert.throws(() => decrypt(parts.join(':')));
  });

  it('throws on unknown version', () => {
    const env = encrypt('test').replace(/^v1:/, 'v99:');
    assert.throws(() => decrypt(env), /Unknown key version/);
  });

  it('isEncrypted() correctly identifies envelopes', () => {
    assert.equal(isEncrypted(encrypt('hello')), true);
    assert.equal(isEncrypted('plain text'), false);
    assert.equal(isEncrypted(''), false);
    assert.equal(isEncrypted(null), false);
  });
});

// ============================================================
//  Password Hashing
// ============================================================
describe('hashPassword / comparePassword', () => {
  it('hashes password with bcrypt ($2b$ prefix)', async () => {
    const hash = await hashPassword('MyPassword@123');
    assert.ok(hash.startsWith('$2'), `Expected bcrypt hash, got: ${hash.slice(0, 5)}`);
  });

  it('hash is different from plaintext', async () => {
    const pwd  = 'MyPassword@123';
    const hash = await hashPassword(pwd);
    assert.notEqual(hash, pwd);
  });

  it('same password produces different hashes (random salt)', async () => {
    const a = await hashPassword('password123');
    const b = await hashPassword('password123');
    assert.notEqual(a, b, 'bcrypt must use random salt');
  });

  it('comparePassword: correct password returns true', async () => {
    const pwd  = 'Correct@Pass1';
    const hash = await hashPassword(pwd);
    assert.equal(await comparePassword(pwd, hash), true);
  });

  it('comparePassword: wrong password returns false', async () => {
    const hash = await hashPassword('correct');
    assert.equal(await comparePassword('wrong', hash), false);
  });
});

// ============================================================
//  OTP Helpers
// ============================================================
describe('generateOtp / hashOtp / verifyOtp', () => {
  it('generateOtp returns correct length numeric string', () => {
    const otp = generateOtp(6);
    assert.equal(otp.length, 6);
    assert.match(otp, /^\d{6}$/);
  });

  it('hashOtp returns 64-char hex (SHA-256)', () => {
    const hash = hashOtp('123456');
    assert.equal(hash.length, 64);
    assert.match(hash, /^[a-f0-9]{64}$/);
  });

  it('hashOtp is deterministic', () => {
    assert.equal(hashOtp('123456'), hashOtp('123456'));
  });

  it('hashOtp does not contain original OTP', () => {
    assert.ok(!hashOtp('123456').includes('123456'));
  });

  it('createOtpPayload never stores raw OTP', () => {
    const otp     = '987654';
    const payload = createOtpPayload(otp);
    assert.ok(!JSON.stringify(payload).includes(otp));
    assert.equal(payload.otpUsed, false);
    assert.ok(payload.otpExpiry instanceof Date);
    assert.ok(payload.otpExpiry > new Date());
  });

  it('verifyOtp: valid OTP returns { valid: true }', () => {
    const otp    = '123456';
    const hash   = hashOtp(otp);
    const expiry = new Date(Date.now() + 600_000);
    assert.equal(verifyOtp(otp, hash, expiry, false).valid, true);
  });

  it('verifyOtp: wrong OTP returns { valid: false }', () => {
    const hash   = hashOtp('123456');
    const expiry = new Date(Date.now() + 600_000);
    const result = verifyOtp('999999', hash, expiry, false);
    assert.equal(result.valid, false);
    assert.equal(result.reason, 'Invalid OTP');
  });

  it('verifyOtp: expired OTP returns { valid: false }', () => {
    const otp    = '123456';
    const result = verifyOtp(otp, hashOtp(otp), new Date(Date.now() - 1000), false);
    assert.equal(result.valid, false);
    assert.equal(result.reason, 'OTP expired');
  });

  it('verifyOtp: used OTP returns { valid: false }', () => {
    const otp    = '123456';
    const result = verifyOtp(otp, hashOtp(otp), new Date(Date.now() + 600_000), true);
    assert.equal(result.valid, false);
    assert.equal(result.reason, 'OTP already used');
  });
});

// ============================================================
//  Reset Token
// ============================================================
describe('generateResetToken / verifyResetToken', () => {
  it('rawToken is 64-char hex', () => {
    const { rawToken } = generateResetToken();
    assert.equal(rawToken.length, 64);
    assert.match(rawToken, /^[a-f0-9]{64}$/);
  });

  it('rawToken and tokenHash are different', () => {
    const { rawToken, tokenHash } = generateResetToken();
    assert.notEqual(rawToken, tokenHash);
  });

  it('valid token verifies successfully', () => {
    const { rawToken, tokenHash, expiresAt } = generateResetToken(15);
    assert.equal(verifyResetToken(rawToken, tokenHash, expiresAt, false).valid, true);
  });

  it('wrong token rejected', () => {
    const { tokenHash, expiresAt } = generateResetToken(15);
    assert.equal(verifyResetToken('badtoken', tokenHash, expiresAt, false).valid, false);
  });

  it('expired token rejected', () => {
    const { rawToken, tokenHash } = generateResetToken(15);
    const past = new Date(Date.now() - 1000);
    assert.equal(verifyResetToken(rawToken, tokenHash, past, false).valid, false);
  });

  it('used token rejected', () => {
    const { rawToken, tokenHash, expiresAt } = generateResetToken(15);
    assert.equal(verifyResetToken(rawToken, tokenHash, expiresAt, true).valid, false);
  });
});

// ============================================================
//  Aadhaar sanitization
// ============================================================
describe('sanitizeAadhaar', () => {
  it('stores only last 4 digits', () => {
    const result = sanitizeAadhaar('123456789012');
    assert.equal(result.aadhaarLast4, '9012');
  });

  it('does not expose full Aadhaar number in return value', () => {
    const result = sanitizeAadhaar('123456789012');
    assert.ok(!JSON.stringify(result).includes('123456789012'),
      'Full Aadhaar must not appear in sanitized output');
  });

  it('sets isAadhaarVerified to false by default', () => {
    const result = sanitizeAadhaar('123456789012');
    assert.equal(result.isAadhaarVerified, false);
  });

  it('throws on invalid Aadhaar (not 12 digits)', () => {
    assert.throws(() => sanitizeAadhaar('12345'), /Invalid Aadhaar/);
    assert.throws(() => sanitizeAadhaar('abcdefghijkl'), /Invalid Aadhaar/);
  });

  it('handles Aadhaar with spaces', () => {
    const result = sanitizeAadhaar('1234 5678 9012');
    assert.equal(result.aadhaarLast4, '9012');
  });
});

// ============================================================
//  Security Invariants
// ============================================================
describe('Security invariants — PII must never appear in stored values', () => {
  it('bcrypt hash of password must not contain the password', async () => {
    const pwd  = 'SuperSecret@123';
    const hash = await hashPassword(pwd);
    assert.ok(!hash.includes('SuperSecret'), 'Password must not appear in hash');
  });

  it('OTP hash must not contain the OTP', () => {
    const otp = '567890';
    assert.ok(!hashOtp(otp).includes(otp));
  });

  it('encrypted counselling note must not contain plaintext', () => {
    const note = 'Student expressed anxiety about exams';
    const env  = encrypt(note);
    assert.ok(!env.includes('anxiety'));
    assert.ok(!env.includes('Student'));
  });

  it('sanitizeAadhaar result must not contain full Aadhaar', () => {
    const full   = '998877665544';
    const result = sanitizeAadhaar(full);
    assert.ok(!JSON.stringify(result).includes(full));
  });
});
