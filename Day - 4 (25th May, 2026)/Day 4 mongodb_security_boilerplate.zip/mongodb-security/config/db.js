'use strict';

/**
 * ============================================================
 *  config/db.js
 *
 *  Secure Mongoose connection for SproutSong.
 *  Implements all MongoDB Security Guide recommendations:
 *   - strict + strictQuery mode globally
 *   - No debug logging in production (queries may contain PII)
 *   - TLS support
 *   - Graceful shutdown
 *   - Safe error logging (never logs connection URI)
 * ============================================================
 */

const mongoose = require('mongoose');

// ── Global security settings ──────────────────────────────────
// Must be set BEFORE any connect() call

// Reject document fields not defined in schema
mongoose.set('strict', true);

// Reject query filter fields not defined in schema (prevents $where injection)
mongoose.set('strictQuery', true);

// Never log raw queries in production — they may contain PII or sensitive filters
mongoose.set('debug', process.env.NODE_ENV === 'development' && process.env.MONGO_DEBUG === 'true');

// ── Connection ────────────────────────────────────────────────
async function connectDB() {
  const uri = process.env.MONGODB_URI;

  if (!uri) {
    throw new Error('[db] MONGODB_URI is not set. Add it to your .env file.');
  }

  // Safe log — mask credentials in URI before logging
  const safeUri = uri.replace(/\/\/([^:]+):([^@]+)@/, '//<user>:<password>@');
  console.info(`[db] Connecting to MongoDB: ${safeUri}`);

  const options = {
    serverSelectionTimeoutMS: 5000,   // fail fast if DB is unreachable
    socketTimeoutMS:          45000,
    maxPoolSize:              10,     // max concurrent connections from this process
    minPoolSize:              2,
  };

  // TLS — enabled via env var (required for production self-hosted)
  if (process.env.MONGO_TLS === 'true') {
    options.tls       = true;
    options.tlsCAFile = process.env.MONGO_TLS_CA_FILE;
  }

  try {
    await mongoose.connect(uri, options);
    console.info('[db] MongoDB connected successfully');
  } catch (err) {
    // Log message + code only — never log the full error (may contain URI with password)
    console.error(`[db] MongoDB connection failed: ${err.message} (code: ${err.code})`);
    process.exit(1);
  }
}

async function disconnectDB() {
  await mongoose.disconnect();
  console.info('[db] MongoDB disconnected');
}

// ── Mongoose connection events ────────────────────────────────
mongoose.connection.on('error', (err) => {
  console.error(`[db] MongoDB error: ${err.message}`);
});

mongoose.connection.on('disconnected', () => {
  console.warn('[db] MongoDB disconnected — attempting reconnect...');
});

// ── Graceful shutdown ─────────────────────────────────────────
process.on('SIGINT',  () => disconnectDB().then(() => process.exit(0)));
process.on('SIGTERM', () => disconnectDB().then(() => process.exit(0)));

module.exports = { connectDB, disconnectDB };
