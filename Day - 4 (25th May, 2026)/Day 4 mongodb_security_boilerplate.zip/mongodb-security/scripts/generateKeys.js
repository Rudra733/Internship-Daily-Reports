#!/usr/bin/env node
'use strict';

/**
 * ============================================================
 *  scripts/generateKeys.js
 *
 *  Generates all cryptographic keys needed for .env.
 *  Run once per environment (dev / staging / production).
 *
 *  Usage: node scripts/generateKeys.js
 * ============================================================
 */

const crypto = require('crypto');

const hex32 = () => crypto.randomBytes(32).toString('hex');

console.log('\n============================================================');
console.log('  SproutSong MongoDB Security — Key Generator');
console.log('  Copy these into your .env file.');
console.log('  NEVER commit these to source control.');
console.log('============================================================\n');

console.log('# AES-256-GCM key for sensitive field encryption at rest');
console.log(`FIELD_ENCRYPTION_KEY=${hex32()}`);
console.log();
console.log('# HMAC key for deterministic PII masking in logs');
console.log(`HMAC_SECRET_KEY=${hex32()}`);
console.log();
console.log('============================================================');
console.log('  Rotate these keys every 6 months.');
console.log('  When rotating FIELD_ENCRYPTION_KEY:');
console.log('   - The versioned envelope (v1:...) lets you decrypt old');
console.log('     records with the old key while encrypting new ones');
console.log('     with v2:... — implement key version mapping in');
console.log('     utils/fieldEncryption.js as needed.');
console.log('============================================================\n');
