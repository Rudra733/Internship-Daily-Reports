'use strict';

/**
 * ============================================================
 *  scripts/verifySetup.js
 *
 *  Runs automated checks against your MongoDB instance to
 *  verify all security controls are correctly configured.
 *
 *  Usage:
 *    node scripts/verifySetup.js
 *
 *  Run before every production deployment.
 * ============================================================
 */

require('dotenv').config();
const { MongoClient } = require('mongodb');
const mongoose        = require('mongoose');

let passed = 0;
let failed = 0;

function check(name, result, detail = '') {
  if (result) {
    console.log(`  ✓  ${name}`);
    passed++;
  } else {
    console.error(`  ✗  ${name}${detail ? ' — ' + detail : ''}`);
    failed++;
  }
}

async function run() {
  console.log('\n============================================================');
  console.log('  SproutSong — MongoDB Security Verification');
  console.log('============================================================\n');

  // ── 1. Environment variables ──────────────────────────────
  console.log('[ Environment Variables ]');
  check('MONGODB_URI is set',            !!process.env.MONGODB_URI);
  check('MONGODB_BACKUP_URI is set',     !!process.env.MONGODB_BACKUP_URI);
  check('FIELD_ENCRYPTION_KEY is 64 chars', process.env.FIELD_ENCRYPTION_KEY?.length === 64);
  check('HMAC_SECRET_KEY is 64 chars',   process.env.HMAC_SECRET_KEY?.length === 64);
  check('MONGODB_URI does not contain "0.0.0.0"',
    !process.env.MONGODB_URI?.includes('0.0.0.0'));
  check('MONGODB_URI uses 127.0.0.1 or private host',
    process.env.MONGODB_URI?.includes('127.0.0.1') ||
    process.env.MONGODB_URI?.includes('10.') ||
    process.env.MONGODB_URI?.includes('172.') ||
    process.env.MONGODB_URI?.includes('192.168.'));
  console.log();

  // ── 2. App user connection ────────────────────────────────
  console.log('[ App User Connection ]');
  let appClient;
  try {
    appClient = new MongoClient(process.env.MONGODB_URI, { serverSelectionTimeoutMS: 3000 });
    await appClient.connect();
    check('App user can connect', true);

    const db = appClient.db('sproutsong');

    // Can read
    try {
      await db.collection('users').findOne({});
      check('App user can read collections', true);
    } catch { check('App user can read collections', false); }

    // Can write
    try {
      const testCol = db.collection('_security_test_');
      await testCol.insertOne({ test: true, ts: new Date() });
      await testCol.deleteOne({ test: true });
      check('App user can write collections', true);
    } catch { check('App user can write collections', false); }

    // Cannot access admin database
    try {
      await appClient.db('admin').command({ listDatabases: 1 });
      check('App user CANNOT access admin DB', false, 'SECURITY ISSUE — app user has admin access');
    } catch {
      check('App user cannot access admin DB (correct)', true);
    }

    await appClient.close();
  } catch (err) {
    check('App user can connect', false, err.message);
  }
  console.log();

  // ── 3. Backup user connection ─────────────────────────────
  console.log('[ Backup User Connection ]');
  let backupClient;
  try {
    backupClient = new MongoClient(process.env.MONGODB_BACKUP_URI, { serverSelectionTimeoutMS: 3000 });
    await backupClient.connect();
    check('Backup user can connect', true);

    const db = backupClient.db('sproutsong');

    // Can read
    try {
      await db.collection('users').findOne({});
      check('Backup user can read', true);
    } catch { check('Backup user can read', false); }

    // Cannot write
    try {
      await db.collection('users').insertOne({ _securityTest: true });
      await db.collection('users').deleteOne({ _securityTest: true });
      check('Backup user CANNOT write', false, 'SECURITY ISSUE — backup user has write access');
    } catch {
      check('Backup user cannot write (correct)', true);
    }

    await backupClient.close();
  } catch (err) {
    check('Backup user can connect', false, err.message);
  }
  console.log();

  // ── 4. Mongoose configuration ─────────────────────────────
  console.log('[ Mongoose Configuration ]');
  mongoose.set('strict', true);
  mongoose.set('strictQuery', true);
  check('strict mode enabled', mongoose.get('strict') === true);
  check('strictQuery mode enabled', mongoose.get('strictQuery') === true);
  check('debug disabled in production',
    process.env.NODE_ENV !== 'production' || !mongoose.get('debug'));
  console.log();

  // ── 5. Field encryption ───────────────────────────────────
  console.log('[ Field Encryption ]');
  try {
    const { encrypt, decrypt, isEncrypted } = require('../utils/fieldEncryption');
    const original  = 'Test counselling note — sensitive';
    const envelope  = encrypt(original);
    const decrypted = decrypt(envelope);
    check('encrypt() produces v1: envelope',  envelope.startsWith('v1:'));
    check('decrypt() restores original value', decrypted === original);
    check('isEncrypted() detects envelope',    isEncrypted(envelope));
    check('Encrypted value does not contain plaintext', !envelope.includes('Test'));

    // Different ciphertext each time (random IV)
    const enc2 = encrypt(original);
    check('Random IV — different ciphertext each call', envelope !== enc2);
  } catch (err) {
    check('Field encryption functional', false, err.message);
    check('Field encryption — skipped further checks', false);
  }
  console.log();

  // ── 6. Sensitive field helpers ────────────────────────────
  console.log('[ Sensitive Field Helpers ]');
  try {
    const { hashPassword, comparePassword, generateOtp, hashOtp,
            generateResetToken, sanitizeAadhaar } = require('../utils/sensitiveFieldHelpers');

    const pwd  = 'TestPassword@123';
    const hash = await hashPassword(pwd);
    check('bcrypt hash starts with $2',         hash.startsWith('$2'));
    check('comparePassword correct → true',     await comparePassword(pwd, hash));
    check('comparePassword wrong → false',      !(await comparePassword('wrongpwd', hash)));

    const otp     = generateOtp(6);
    check('generateOtp produces 6-digit string', /^\d{6}$/.test(otp));
    const otpHash = hashOtp(otp);
    check('hashOtp is 64-char hex',             /^[a-f0-9]{64}$/.test(otpHash));
    check('hashOtp does not contain raw OTP',   !otpHash.includes(otp));

    const { rawToken, tokenHash, expiresAt } = generateResetToken();
    check('generateResetToken rawToken is 64 chars', rawToken.length === 64);
    check('tokenHash differs from rawToken',         rawToken !== tokenHash);
    check('expiresAt is in the future',              expiresAt > new Date());

    const aadhaar = sanitizeAadhaar('123456789012');
    check('sanitizeAadhaar stores only last 4',      aadhaar.aadhaarLast4 === '9012');
    check('sanitizeAadhaar does not return full num', !JSON.stringify(aadhaar).includes('123456789012'));
  } catch (err) {
    check('Sensitive field helpers functional', false, err.message);
  }
  console.log();

  // ── Summary ───────────────────────────────────────────────
  const total = passed + failed;
  console.log('============================================================');
  console.log(`  Results: ${passed}/${total} checks passed`);
  if (failed > 0) {
    console.error(`  ✗ ${failed} check(s) FAILED — fix before deploying to production`);
  } else {
    console.log('  ✓ All checks passed');
  }
  console.log('============================================================\n');
  process.exit(failed > 0 ? 1 : 0);
}

run().catch(err => { console.error('Verification error:', err.message); process.exit(1); });
