#!/bin/bash
# ============================================================
#  scripts/backup.sh
#
#  Daily encrypted MongoDB backup for SproutSong.
#  Crontab: 0 2 * * * /opt/sproutsong/scripts/backup.sh
#
#  What it does:
#    1. mongodump using read-only backup user
#    2. GPG asymmetric encryption (only backup officer decrypts)
#    3. Upload to S3 with server-side encryption
#    4. Verify upload
#    5. Clean up local temp files
#    6. Prune local backups older than 30 days
#
#  Required env vars (set in /etc/environment or systemd):
#    MONGODB_BACKUP_URI  — uses sproutsong_backup (read-only)
#    GPG_RECIPIENT       — backup officer GPG public key email
#    S3_BACKUP_BUCKET    — S3 bucket name
#    BACKUP_LOG          — path to log file
# ============================================================

set -euo pipefail

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/tmp/sproutsong_backup_${DATE}"
ARCHIVE_RAW="/tmp/sproutsong_backup_${DATE}.tar.gz"
ARCHIVE_ENC="/var/backups/sproutsong/backup_${DATE}.tar.gz.gpg"
LOG_FILE="${BACKUP_LOG:-/var/log/sproutsong/backup.log}"

mkdir -p "$(dirname "${ARCHIVE_ENC}")" "$(dirname "${LOG_FILE}")"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "${LOG_FILE}"; }

log "===== SproutSong MongoDB Backup Started: ${DATE} ====="

# Validate required env vars
: "${MONGODB_BACKUP_URI:?MONGODB_BACKUP_URI not set}"
: "${GPG_RECIPIENT:?GPG_RECIPIENT not set}"
: "${S3_BACKUP_BUCKET:?S3_BACKUP_BUCKET not set}"

# ── 1. mongodump ──────────────────────────────────────────────
log "Running mongodump..."
mongodump \
  --uri="${MONGODB_BACKUP_URI}" \
  --out="${BACKUP_DIR}" \
  --gzip \
  --quiet
log "Dump complete — size: $(du -sh "${BACKUP_DIR}" | cut -f1)"

# ── 2. Compress ───────────────────────────────────────────────
tar -czf "${ARCHIVE_RAW}" -C "$(dirname "${BACKUP_DIR}")" "$(basename "${BACKUP_DIR}")"
log "Compressed: $(du -sh "${ARCHIVE_RAW}" | cut -f1)"

# ── 3. GPG encrypt ───────────────────────────────────────────
log "Encrypting with GPG for ${GPG_RECIPIENT}..."
gpg --batch --yes \
    --trust-model always \
    --encrypt \
    --recipient "${GPG_RECIPIENT}" \
    --output "${ARCHIVE_ENC}" \
    "${ARCHIVE_RAW}"
log "Encrypted: ${ARCHIVE_ENC}"

# ── 4. Upload to S3 ──────────────────────────────────────────
log "Uploading to s3://${S3_BACKUP_BUCKET}/mongodb/..."
aws s3 cp "${ARCHIVE_ENC}" \
    "s3://${S3_BACKUP_BUCKET}/mongodb/backup_${DATE}.tar.gz.gpg" \
    --storage-class STANDARD_IA \
    --sse aws:kms
log "Upload complete"

# ── 5. Verify ────────────────────────────────────────────────
aws s3 ls "s3://${S3_BACKUP_BUCKET}/mongodb/backup_${DATE}.tar.gz.gpg" \
  | tee -a "${LOG_FILE}"
log "S3 verification OK"

# ── 6. Cleanup ────────────────────────────────────────────────
rm -rf "${BACKUP_DIR}" "${ARCHIVE_RAW}" "${ARCHIVE_ENC}"
find /var/backups/sproutsong/ -name "*.gpg" -mtime +30 -delete 2>/dev/null || true
log "Cleanup done — local backups older than 30 days pruned"

log "===== Backup Complete: backup_${DATE} ====="
