'use strict';

/**
 * ============================================================
 *  scripts/setupMongoUsers.js
 *
 *  Run ONCE on a fresh MongoDB instance to create all required
 *  database users with least-privilege permissions.
 *
 *  Prerequisites:
 *    1. MongoDB running with auth DISABLED (initial state)
 *    2. Run this script
 *    3. Enable auth in /etc/mongod.conf, restart MongoDB
 *    4. Verify with: mongosh -u sproutsong_admin -p
 *
 *  Usage:
 *    MONGO_ADMIN_PWD=<pwd> MONGO_APP_PWD=<pwd> MONGO_BACKUP_PWD=<pwd> \
 *      node scripts/setupMongoUsers.js
 * ============================================================
 */

const { MongoClient } = require('mongodb');

const BASE_URI    = process.env.MONGO_SETUP_URI || 'mongodb://127.0.0.1:27017';
const DB_NAME     = 'sproutsong';

const ADMIN_PWD    = process.env.MONGO_ADMIN_PWD;
const APP_PWD      = process.env.MONGO_APP_PWD;
const BACKUP_PWD   = process.env.MONGO_BACKUP_PWD;
const READONLY_PWD = process.env.MONGO_READONLY_PWD; // optional

async function run() {
  if (!ADMIN_PWD || !APP_PWD || !BACKUP_PWD) {
    console.error('\nERROR: All three passwords must be set as environment variables:');
    console.error('  MONGO_ADMIN_PWD    — admin user (migrations only)');
    console.error('  MONGO_APP_PWD      — app user (Express.js)');
    console.error('  MONGO_BACKUP_PWD   — backup user (read-only)');
    console.error('\nGenerate strong passwords:');
    console.error('  openssl rand -base64 32\n');
    process.exit(1);
  }

  const client = new MongoClient(BASE_URI);
  await client.connect();
  console.log('\n[setup] Connected to MongoDB');

  // ── 1. Admin user (on admin database) ────────────────────
  await client.db('admin').command({
    createUser: 'sproutsong_admin',
    pwd:   ADMIN_PWD,
    roles: [
      { role: 'userAdminAnyDatabase', db: 'admin' },
      { role: 'dbAdminAnyDatabase',   db: 'admin' },
    ],
  });
  console.log('[setup] ✓ Created: sproutsong_admin (userAdmin + dbAdmin)');

  // ── 2. App user (readWrite on sproutsong only) ────────────
  await client.db(DB_NAME).command({
    createUser: 'sproutsong_app',
    pwd:   APP_PWD,
    roles: [{ role: 'readWrite', db: DB_NAME }],
  });
  console.log(`[setup] ✓ Created: sproutsong_app (readWrite on "${DB_NAME}" only)`);

  // ── 3. Backup user (read-only on sproutsong) ──────────────
  await client.db(DB_NAME).command({
    createUser: 'sproutsong_backup',
    pwd:   BACKUP_PWD,
    roles: [{ role: 'read', db: DB_NAME }],
  });
  console.log(`[setup] ✓ Created: sproutsong_backup (read on "${DB_NAME}" only)`);

  // ── 4. Read-only user (optional — analytics / BI tools) ──
  if (READONLY_PWD) {
    await client.db(DB_NAME).command({
      createUser: 'sproutsong_readonly',
      pwd:   READONLY_PWD,
      roles: [{ role: 'read', db: DB_NAME }],
    });
    console.log(`[setup] ✓ Created: sproutsong_readonly (read on "${DB_NAME}" only)`);
  }

  await client.close();

  console.log('\n============================================================');
  console.log('  Next steps:');
  console.log('  1. Edit /etc/mongod.conf:');
  console.log('       security:');
  console.log('         authorization: enabled');
  console.log('       net:');
  console.log('         bindIp: 127.0.0.1');
  console.log('  2. Restart: sudo systemctl restart mongod');
  console.log('  3. Copy to your .env:');
  console.log(`       MONGODB_URI=mongodb://sproutsong_app:<APP_PWD>@127.0.0.1:27017/${DB_NAME}`);
  console.log(`       MONGODB_BACKUP_URI=mongodb://sproutsong_backup:<BACKUP_PWD>@127.0.0.1:27017/${DB_NAME}`);
  console.log('  4. Verify port is NOT public:');
  console.log('       sudo ss -tlnp | grep 27017  →  must show 127.0.0.1 only');
  console.log('============================================================\n');
}

run().catch(err => { console.error('[setup] Failed:', err.message); process.exit(1); });
