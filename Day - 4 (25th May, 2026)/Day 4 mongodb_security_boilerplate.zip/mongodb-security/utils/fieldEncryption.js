'use strict';

/**
 * ============================================================
 *  utils/fieldEncryption.js
 *
 *  AES-256-GCM field-level encryption for sensitive MongoDB
 *  fields that must be stored but protected at rest.
 *
 *  Use for:
 *   - Counselling notes
 *   - Encrypted audit log targets
 *   - Any field that must be retrievable but protected
 *
 *  Versioned envelope format: "v1:<iv_hex>:<authTag_hex>:<data_hex>"
 *  The "v1" prefix enables key rotation without breaking old records.
 *
 *  Env: FIELD_ENCRYPTION_KEY = 64-char hex string (32 bytes)
 *  Generate: node scripts/generateKeys.js
 * ============================================================
 */

const crypto = require('crypto');

const ALGO     = 'aes-256-gcm';
const IV_BYTES = 12;  // 96-bit IV — recommended for GCM

let _key = null;

function getKey() {
  if (_key) return _key;
  const hex = process.env.FIELD_ENCRYPTION_KEY;
  if (!hex || hex.length !== 64) {
    throw new Error(
      '[fieldEncryption] FIELD_ENCRYPTION_KEY must be a 64-char hex string.\n' +
      'Generate one: node scripts/generateKeys.js'
    );
  }
  _key = Buffer.from(hex, 'hex');
  return _key;
}

// ── Encrypt a single field value ─────────────────────────────
function encrypt(value) {
  if (value === null || value === undefined) return null;
  const key      = getKey();
  const iv       = crypto.randomBytes(IV_BYTES);
  const cipher   = crypto.createCipheriv(ALGO, key, iv);
  const encrypted = Buffer.concat([cipher.update(String(value), 'utf8'), cipher.final()]);
  const authTag   = cipher.getAuthTag();
  return ['v1', iv.toString('hex'), authTag.toString('hex'), encrypted.toString('hex')].join(':');
}

// ── Decrypt a field value ─────────────────────────────────────
function decrypt(envelope) {
  if (!envelope) return null;
  const parts = String(envelope).split(':');
  if (parts.length !== 4) throw new Error('[fieldEncryption] Invalid envelope format.');
  const [version, ivHex, authTagHex, dataHex] = parts;
  if (version !== 'v1') throw new Error(`[fieldEncryption] Unknown key version "${version}".`);
  const key      = getKey();
  const decipher = crypto.createDecipheriv(ALGO, key, Buffer.from(ivHex, 'hex'));
  decipher.setAuthTag(Buffer.from(authTagHex, 'hex'));
  return Buffer.concat([
    decipher.update(Buffer.from(dataHex, 'hex')),
    decipher.final(),
  ]).toString('utf8');
}

// ── Check if a value is an encrypted envelope ────────────────
function isEncrypted(value) {
  return typeof value === 'string' && value.startsWith('v1:') && value.split(':').length === 4;
}

// ── Mongoose schema type for auto encrypt/decrypt ────────────
/**
 * Usage in a Mongoose schema:
 *
 *   const { encryptedField } = require('../utils/fieldEncryption');
 *
 *   CounsellingSchema.add({
 *     notes: encryptedField({ required: false }),
 *   });
 *
 * When you set doc.notes = 'plain text', it auto-encrypts on save.
 * When you read doc.notes, it auto-decrypts.
 */
function encryptedField(schemaOptions = {}) {
  return {
    type: String,
    select: false,  // never returned in queries by default
    get(value) {
      if (!value) return value;
      try { return isEncrypted(value) ? decrypt(value) : value; }
      catch { return '[DECRYPT_ERROR]'; }
    },
    set(value) {
      if (!value) return value;
      if (isEncrypted(value)) return value; // already encrypted
      return encrypt(value);
    },
    ...schemaOptions,
  };
}

module.exports = { encrypt, decrypt, isEncrypted, encryptedField };
