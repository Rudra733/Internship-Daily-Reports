'use strict';

/**
 * ============================================================
 *  utils/sensitiveFieldHelpers.js
 *
 *  Secure helpers for all sensitive fields that must be stored
 *  in MongoDB but never in plain text:
 *
 *   - Passwords     → bcrypt hash (rounds 12)
 *   - OTPs          → SHA-256 hash + expiry + used flag
 *   - Reset tokens  → SHA-256 hash + short expiry
 *   - Aadhaar       → last 4 digits + isVerified flag only
 * ============================================================
 */

const crypto  = require('crypto');
const bcrypt  = require('bcryptjs');

const BCRYPT_ROUNDS   = 12;
const OTP_EXPIRY_MIN  = 10;
const TOKEN_EXPIRY_MIN = 15;

// ============================================================
//  PASSWORDS — bcrypt
// ============================================================

async function hashPassword(plainText) {
  return bcrypt.hash(plainText, BCRYPT_ROUNDS);
}

async function comparePassword(plainText, hash) {
  return bcrypt.compare(plainText, hash);
}

// ============================================================
//  OTP — SHA-256 hash + expiry + used flag
// ============================================================

function generateOtp(length = 6) {
  // crypto.randomInt — cryptographically secure, uniform distribution
  return Array.from({ length }, () => crypto.randomInt(0, 10)).join('');
}

function hashOtp(otp) {
  return crypto.createHash('sha256').update(String(otp)).digest('hex');
}

// Returns the object to spread into a User.updateOne() call
function createOtpPayload(otp, expiryMinutes = OTP_EXPIRY_MIN) {
  return {
    otpHash:   hashOtp(otp),
    otpExpiry: new Date(Date.now() + expiryMinutes * 60_000),
    otpUsed:   false,
  };
}

// Returns { valid: boolean, reason: string }
function verifyOtp(inputOtp, storedHash, storedExpiry, isUsed) {
  if (isUsed)                              return { valid: false, reason: 'OTP already used' };
  if (!storedExpiry || new Date() > new Date(storedExpiry))
                                           return { valid: false, reason: 'OTP expired' };
  if (hashOtp(inputOtp) !== storedHash)    return { valid: false, reason: 'Invalid OTP' };
  return { valid: true, reason: 'OK' };
}

// ============================================================
//  RESET TOKENS — random bytes, SHA-256 hash, short expiry
// ============================================================

// Returns { rawToken, tokenHash, expiresAt }
// Store tokenHash + expiresAt in DB. Send rawToken to user.
function generateResetToken(expiryMinutes = TOKEN_EXPIRY_MIN) {
  const rawToken  = crypto.randomBytes(32).toString('hex'); // 64-char URL-safe
  const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
  return { rawToken, tokenHash, expiresAt: new Date(Date.now() + expiryMinutes * 60_000) };
}

function verifyResetToken(inputToken, storedHash, storedExpiry, isUsed) {
  if (isUsed)                                             return { valid: false, reason: 'Token already used' };
  if (!storedExpiry || new Date() > new Date(storedExpiry)) return { valid: false, reason: 'Token expired' };
  const inputHash = crypto.createHash('sha256').update(inputToken).digest('hex');
  if (inputHash !== storedHash)                           return { valid: false, reason: 'Invalid token' };
  return { valid: true, reason: 'OK' };
}

// ============================================================
//  AADHAAR — store only last 4 digits + verified flag
// ============================================================

// Call this before saving any Aadhaar-related data
function sanitizeAadhaar(fullAadhaar) {
  const digits = String(fullAadhaar).replace(/\D/g, '');
  if (digits.length !== 12) throw new Error('Invalid Aadhaar: must be 12 digits');
  return {
    aadhaarLast4:       digits.slice(-4),  // store ONLY last 4
    isAadhaarVerified:  false,             // set true after UIDAI verification
    // fullAadhaar is discarded here — never stored
  };
}

module.exports = {
  hashPassword,
  comparePassword,
  generateOtp,
  hashOtp,
  createOtpPayload,
  verifyOtp,
  generateResetToken,
  verifyResetToken,
  sanitizeAadhaar,
};
