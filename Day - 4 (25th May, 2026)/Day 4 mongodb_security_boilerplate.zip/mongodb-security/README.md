# SproutSong — MongoDB Security
## Complete Implementation Package

---

## File Structure

```
mongodb-security/
│
├── .env.example                         ← Copy to .env, fill in values
├── package.json
│
├── config/
│   ├── db.js                            ← Secure Mongoose connection
│   └── mongod.conf                      ← Hardened MongoDB server config
│
├── middleware/
│   └── mongoSanitize.js                 ← NoSQL injection prevention
│
├── utils/
│   ├── fieldEncryption.js               ← AES-256-GCM field-level encryption
│   └── sensitiveFieldHelpers.js         ← bcrypt, OTP, reset tokens, Aadhaar
│
├── models/
│   ├── User.js                          ← Secure User model (all best practices)
│   ├── AuditLog.js                      ← Audit log with TTL (90 days)
│   ├── SchemaTemplate.js                ← Copy-paste template for new models
│   └── plugins/
│       └── auditPlugin.js               ← Auto-log writes/deletes on sensitive collections
│
├── scripts/
│   ├── generateKeys.js                  ← Generate FIELD_ENCRYPTION_KEY + HMAC_SECRET_KEY
│   ├── setupMongoUsers.js               ← Create app / admin / backup DB users
│   ├── verifySetup.js                   ← Run security checks before deployment
│   └── backup.sh                        ← Daily encrypted GPG backup → S3
│
└── tests/
    └── mongodbSecurity.test.js          ← 40+ tests covering all security controls
```

---

## Quick Start

### Step 1 — Install dependencies
```bash
npm install
```

### Step 2 — Generate encryption keys
```bash
node scripts/generateKeys.js
# Copy output into your .env
```

### Step 3 — Configure environment
```bash
cp .env.example .env
# Fill in: FIELD_ENCRYPTION_KEY, HMAC_SECRET_KEY, MONGODB_URI, MONGODB_BACKUP_URI
```

### Step 4 — Harden MongoDB server config
```bash
sudo cp config/mongod.conf /etc/mongod.conf
sudo systemctl restart mongod

# Verify port is NOT public:
sudo ss -tlnp | grep 27017
# Must show: 127.0.0.1:27017 only
```

### Step 5 — Create database users
```bash
MONGO_ADMIN_PWD=$(openssl rand -base64 32) \
MONGO_APP_PWD=$(openssl rand -base64 32) \
MONGO_BACKUP_PWD=$(openssl rand -base64 32) \
  node scripts/setupMongoUsers.js
```

### Step 6 — Enable MongoDB authentication
Edit `/etc/mongod.conf`:
```yaml
security:
  authorization: enabled
```
```bash
sudo systemctl restart mongod
```

### Step 7 — Register NoSQL sanitization in Express
```js
// app.js — after body parsing, before routes
const mongoSanitize = require('./middleware/mongoSanitize');
app.use(mongoSanitize);
```

### Step 8 — Verify everything
```bash
node scripts/verifySetup.js
# All checks must pass before production deployment
```

### Step 9 — Run tests
```bash
node --test tests/
```

---

## Key Files Explained

### `config/db.js`
- `strict: true` — rejects document fields not in schema
- `strictQuery: true` — rejects query filters not in schema (NoSQL injection prevention)
- `debug: false` in production — never logs raw queries (may contain PII)
- TLS support via `MONGO_TLS=true`
- Safe error logging — never logs URI (contains password)

### `config/mongod.conf`
- `bindIp: 127.0.0.1` — not `0.0.0.0` (critical)
- `authorization: enabled` — mandatory
- `quiet: true` — reduces log noise
- TLS configuration (commented — uncomment with certificate)

### `middleware/mongoSanitize.js`
Prevents NoSQL injection:
```js
// Attacker sends: { "email": { "$gt": "" } }
// After sanitization: { "email": { "_gt": "" } }  → no match, access denied
```

### `utils/fieldEncryption.js`
AES-256-GCM encryption for sensitive fields at rest:
```js
const { encrypt, decrypt, encryptedField } = require('./utils/fieldEncryption');

// Manual:
const envelope = encrypt('Counselling note text');  // "v1:iv:authTag:data"
const original = decrypt(envelope);                 // "Counselling note text"

// Auto (schema field):
CounsellingSchema.add({ notes: encryptedField() });
// doc.notes = 'text'  → auto-encrypts on save
// doc.notes           → auto-decrypts on read
```

### `utils/sensitiveFieldHelpers.js`

| Function | Use for | Storage |
|----------|---------|---------|
| `hashPassword(pwd)` | User passwords | bcrypt hash |
| `comparePassword(pwd, hash)` | Login verification | — |
| `generateOtp(6)` | SMS/email OTP | Never stored raw |
| `createOtpPayload(otp)` | OTP DB payload | `{ otpHash, otpExpiry, otpUsed }` |
| `verifyOtp(input, hash, expiry, used)` | OTP check | — |
| `generateResetToken()` | Password reset | `{ rawToken (send to user), tokenHash, expiresAt }` |
| `verifyResetToken(input, hash, expiry, used)` | Reset check | — |
| `sanitizeAadhaar(full)` | Aadhaar input | `{ aadhaarLast4, isAadhaarVerified: false }` |

### `models/User.js`
Demonstrates all sensitive field patterns:
- `password` — `select: false`, hashed via `pre('save')`
- `tokenVersion` — `select: false`, increment to invalidate all JWTs
- `aadhaarLast4` — stores only last 4 digits; full Aadhaar never stored
- `otpHash / otpExpiry / otpUsed` — `select: false`
- `resetTokenHash / resetTokenExpiry / resetTokenUsed` — `select: false`
- `toJSON` transform strips all sensitive fields from API responses

### `models/plugins/auditPlugin.js`
Attach to sensitive schemas:
```js
CounsellingSchema.plugin(auditPlugin, { module: 'management' });
ExamResultSchema.plugin(auditPlugin,  { module: 'examinations' });
FeeRecordSchema.plugin(auditPlugin,   { module: 'accountant' });
```
Auto-logs `WRITE` and `DELETE` operations to the `AuditLog` collection.

### `scripts/backup.sh`
Daily encrypted backup:
1. `mongodump` using `sproutsong_backup` (read-only) user
2. GPG asymmetric encryption — only backup officer can decrypt
3. Upload to S3 with SSE
4. Auto-prune local backups older than 30 days

Add to crontab: `0 2 * * * /opt/sproutsong/scripts/backup.sh`

---

## Sensitive Fields — What is Stored

| Field | ❌ Never stored | ✅ Stored as |
|-------|---------------|-------------|
| Password | Plain text | bcrypt hash (rounds 12) |
| Full Aadhaar | 12-digit number | Last 4 digits + `isVerified` flag |
| OTP | Raw code | SHA-256 hash + expiry + used flag |
| Reset token | Raw token | SHA-256 hash + expiry + used flag |
| Counselling notes | Plain text | AES-256-GCM encrypted envelope |
| Bank card number | Full number | Gateway transaction ID only |
| JWT / session token | Token string | SHA-256 hash (if stored at all) |

---

## Security Checklist (run before every deployment)

```bash
node scripts/verifySetup.js
```

Manual checks:
- [ ] `sudo ss -tlnp | grep 27017` → shows `127.0.0.1:27017` only
- [ ] `.gitignore` includes `.env`
- [ ] `git log -S 'mongodb://'` returns nothing
- [ ] Backup test restored successfully this month
- [ ] FIELD_ENCRYPTION_KEY rotated in last 6 months
- [ ] All DB passwords are 20+ chars
