'use strict';

/**
 * ============================================================
 *  middleware/mongoSanitize.js
 *
 *  Prevents NoSQL injection attacks by stripping MongoDB
 *  operator characters ($ and .) from all request inputs
 *  before they reach controllers or DB queries.
 *
 *  Attack example without sanitization:
 *    POST /api/v1/auth/login
 *    { "email": { "$gt": "" }, "password": { "$gt": "" } }
 *    → Would return ANY user, bypassing password check
 *
 *  Register in app.js AFTER body parsing, BEFORE all routes.
 * ============================================================
 */

const mongoSanitize = require('express-mongo-sanitize');

// ── Primary sanitization middleware ──────────────────────────
const sanitizeMiddleware = mongoSanitize({
  // Replace $ and . with _ instead of removing entirely.
  // This way the request still reaches validation and returns
  // a proper 422 error rather than silently dropping fields.
  replaceWith: '_',

  // Log injection attempts for security monitoring
  onSanitize: ({ req, key }) => {
    console.warn(JSON.stringify({
      level:     'warn',
      msg:       'NoSQL injection attempt blocked',
      key,
      path:      req.path,
      method:    req.method,
      ip:        req.ip,
      userId:    req.user?.id || null,
      timestamp: new Date().toISOString(),
    }));
  },
});

// ── Manual sanitization helper (use in controllers if needed) ─
/**
 * Call this if you need to sanitize a specific value
 * outside of the request middleware chain.
 *
 * Usage: const safe = sanitizeValue(req.query.filter);
 */
function sanitizeValue(value) {
  if (typeof value === 'string') {
    return value.replace(/[$\.]/g, '_');
  }
  if (typeof value === 'object' && value !== null) {
    return JSON.parse(
      JSON.stringify(value).replace(/"\$[^"]*"/g, '"_$1"')
    );
  }
  return value;
}

module.exports = sanitizeMiddleware;
module.exports.sanitizeValue = sanitizeValue;
