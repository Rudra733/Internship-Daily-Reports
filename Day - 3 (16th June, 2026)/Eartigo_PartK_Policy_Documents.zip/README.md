# Eartigo — Part K: Privacy Policy & Compliance Documents

This package contains 12 draft policy and compliance documents prepared for
Eartigo (fresh.eartigo.com) as part of the Cybersecurity & Data Protection
Internship "Part K" deliverable.

## IMPORTANT — READ BEFORE USE

Every document in this package is a **structured DRAFT** intended to give the
incoming team a complete, legally-grounded starting point. Each document:

- Is consistent with the data inventory, consent framework, security
  architecture, AI safeguards, and breach response process described in
  Parts A–J of the internship guide.
- Contains yellow-highlighted **PLACEHOLDER** boxes wherever
  company-specific information is required (legal entity name, registered
  address, Grievance Officer details, named vendors/processors, specific
  numeric thresholds such as fee percentages or refund timelines, etc.).
- Must be reviewed by qualified legal counsel before being published,
  signed, or relied upon as a binding document. This is internship
  coursework / internal draft material, not a substitute for legal advice.

## Contents

| # | File | Document | Required? (per Part K table) |
|---|------|----------|-------------------------------|
| 01 | 01_Privacy_Policy.docx | Privacy Policy | Yes |
| 02 | 02_Terms_and_Conditions.docx | Terms & Conditions | Yes |
| 03 | 03_Farmer_Data_Protection_Policy.docx | Farmer Data Protection Policy | Strongly Recommended |
| 04 | 04_Cookie_and_Tracking_Policy.docx | Cookie & Tracking Policy | Yes, if applicable |
| 05 | 05_Consent_Policy_and_Notice.docx | Consent Policy & Notice | Yes |
| 06 | 06_Data_Retention_Policy.docx | Data Retention Policy | Yes |
| 07 | 07_Breach_Response_Policy.docx | Breach Response Policy | Recommended |
| 08 | 08_Drone_and_Satellite_Data_Usage_Policy.docx | Drone & Satellite Data Usage Policy | Recommended |
| 09 | 09_AIML_Advisory_Disclaimer.docx | AI/ML Advisory Disclaimer | Recommended |
| 10 | 10_Payment_and_Payout_Terms.docx | Payment & Payout Terms | Yes |
| 11 | 11_Seller_Farmer_Agreement.docx | Seller/Farmer Agreement | Yes |
| 12 | 12_Third_Party_Processor_List.docx | Third-Party Processor List | Internal |

## Cross-References

Each document lists its "Related Documents" on the cover page. The set is
designed to be internally consistent — for example, the Privacy Policy
references the Farmer Data Protection Policy and Consent Policy & Notice for
farm intelligence data, the Terms & Conditions reference the Seller/Farmer
Agreement and Payment & Payout Terms, and the Breach Response Policy
references the Third-Party Processor List when identifying who to notify
during an incident.

## Suggested Next Steps

1. Fill in every PLACEHOLDER box across all 12 documents (legal entity
   details, Grievance Officer contact, named processors/vendors, fee and
   timeline figures).
2. Complete the cookie audit referenced in the Cookie & Tracking Policy
   (Section 3) before publishing that document.
3. Complete the Third-Party Processor Register entries (Section 5) as each
   vendor integration (Payment Aggregator, KYC intermediary, satellite/drone
   vendors, etc.) is finalised, ensuring each has a signed DPA.
4. Route all 12 documents to legal counsel for review prior to publication.
5. Publish the public-facing documents (01, 02, 03, 04, 05, 06, 08, 09, 10,
   11) on the Platform with links from account registration and footer
   navigation, consistent with the consent flows described in Part E and the
   Consent Policy & Notice.
6. Retain the internal-only documents (07 Breach Response Policy, 12
   Third-Party Processor List) as restricted internal compliance records.
