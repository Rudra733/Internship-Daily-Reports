# SproutSong — Secure Logging & PII Masking

**Version:** 1.0 | **Classification:** CONFIDENTIAL | **May 2026**

DPDP Act 2023-compliant logging implementation for the SproutSong School Management Platform.

---

## File Structure

```
sproutsong-secure-logging/
├── backend/
│   ├── config/
│   │   ├── logger.js          # Pino logger — single source of truth, PII redaction
│   │   └── logRotation.js     # File-based rotation (fallback only)
│   ├── middleware/
│   │   ├── httpLogger.js      # pino-http middleware — HTTP request logging
│   │   └── requestId.js       # Correlation ID + AsyncLocalStorage context
│   ├── utils/
│   │   ├── piiMask.js         # hmacMask, partialMask, maskEmail, maskIp, maskAadhaar
│   │   └── auditEncrypt.js    # AES-256-GCM encrypt/decrypt for audit log storage
│   ├── models/
│   │   └── AuditLog.js        # MongoDB model — 90-day TTL, encrypted PII fields
│   └── controllers/
│       ├── authController.js  # Auth flow — login/logout/password (reference impl)
│       └── studentController.js # Student data access (reference impl)
├── tests/
│   └── secureLogging.test.js  # Automated tests — verifies PII never appears in logs
├── .env.example               # Required environment variables
├── package.json
└── README.md
```

---

## Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env — generate keys with:
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Set `LOG_HMAC_KEY` and `AUDIT_ENCRYPTION_KEY` to unique 64-char hex strings.

### 3. Register Middleware in app.js

```javascript
const express             = require('express');
const httpLogger          = require('./backend/middleware/httpLogger');
const { requestIdMiddleware, setLogContext } = require('./backend/middleware/requestId');
const authenticate        = require('./backend/middleware/authenticate'); // your JWT middleware

const app = express();
app.use(express.json());
app.use(requestIdMiddleware);   // 1. Always first — attaches correlation ID
app.use(httpLogger);            // 2. HTTP request logging (after requestId)
app.use('/api', authenticate);  // 3. JWT verification
app.use('/api', setLogContext);  // 4. Inject user context into logger
// ... routes
```

### 4. Use in Controllers

```javascript
const { getLogger }           = require('./backend/middleware/requestId');
const { hmacMask, maskEmail } = require('./backend/utils/piiMask');
const { encryptForAudit }     = require('./backend/utils/auditEncrypt');

async function loginController(req, res) {
  const log = getLogger(); // child logger — requestId + userId baked in
  const { email } = req.body;

  log.info({
    emailHash: hmacMask(email),    // "hmac:3f7a2b8c..." — correlatable, irreversible
    emailMask: maskEmail(email),   // "j**@school.com" — human readable
    // password: NEVER LOG
  }, 'Login attempt');
}
```

### 5. Run Tests

```bash
npm test
```

Tests verify:
- All PII masking functions produce correct output
- AES-256-GCM encrypt/decrypt round-trips correctly
- Pino redaction catches passwords, tokens, email, phone, Aadhaar
- Known PII strings never appear in log output under any logging call

---

## PII Masking Quick Reference

| PII Field       | Function          | Output Example              |
|-----------------|-------------------|-----------------------------|
| Email           | `hmacMask(email)` | `hmac:3f7a2b8c1e9d4a6f`   |
| Email (display) | `maskEmail(email)`| `j**@school.com`            |
| Phone           | `partialMask(phone)` | `******3210`             |
| Aadhaar         | `maskAadhaar(n)`  | `xxxx-xxxx-1234`            |
| IP address      | `maskIp(ip)`      | `192.168.1.xxx`             |
| Password/Token  | Pino redact       | `[REDACTED]`                |
| Audit PII       | `encryptForAudit` | `v1:<iv>:<tag>:<cipher>`    |

---

## Environment Variables

| Variable              | Purpose                                  | Required      |
|-----------------------|------------------------------------------|---------------|
| `LOG_LEVEL`           | `error\|warn\|info\|debug\|trace`         | Yes (prod: `info`) |
| `LOG_HMAC_KEY`        | 64-char hex — HMAC-SHA256 masking key    | Yes           |
| `AUDIT_ENCRYPTION_KEY`| 64-char hex — AES-256-GCM key           | Yes           |
| `SERVICE_NAME`        | Appears on every log entry               | Recommended   |
| `NODE_ENV`            | `production` disables pino-pretty        | Yes           |

---

## Compliance Notes (DPDP Act 2023)

- **Never log** student name, parent name, email (plain), phone (plain), Aadhaar, DOB, counselling notes
- **Always log** ObjectId references instead of names
- **Audit log** retains 90 days in MongoDB (TTL index) + 1 year encrypted backup
- **Rotate** `AUDIT_ENCRYPTION_KEY` every 6 months
- **Access** to audit logs: Super Admin + DevOps only

---

*SproutSong School Management Platform — Internal Use Only*
