// backend/controllers/authController.js
// SproutSong — Auth Controller (Secure Logging Reference Implementation)
//
// Demonstrates correct vs. incorrect logging patterns for authentication flows.
// Every log line in this file is safe to ship to production without PII exposure.
//
// v1.0 | May 2026 | CONFIDENTIAL

'use strict';

const AuditLog          = require('../models/AuditLog');
const { getLogger, getRequestContext } = require('../middleware/requestId');
const { hmacMask, maskEmail, partialMask, maskIp, sanitiseKeys } =
  require('../utils/piiMask');
const { encryptForAudit } = require('../utils/auditEncrypt');

// ─── loginController ─────────────────────────────────────────────────────────
/**
 * POST /api/v1/auth/login
 * Authenticates a user and returns a JWT.
 *
 * Logging contract:
 *   - Email: logged as hmacMask (correlation) + maskEmail (human readable)
 *   - Password: NEVER logged under any circumstances
 *   - userId: logged as ObjectId string after successful auth
 *   - JWT: NEVER logged (Pino redact catches accidental leaks)
 */
async function loginController(req, res) {
  const log = getLogger();
  const { requestId } = getRequestContext();

  const { email, password } = req.body;

  // ✅ Safe: log structure of request body — never the values
  log.debug({ bodyKeys: sanitiseKeys(req.body) }, 'Login request received');

  // ── Validate Input ────────────────────────────────────────────────────────
  if (!email || !password) {
    log.warn({
      emailHash: hmacMask(email),
      missing:   [!email && 'email', !password && 'password'].filter(Boolean),
    }, 'Login attempt with missing fields');

    return res.status(400).json({ error: 'Email and password are required' });
  }

  try {
    // ── Lookup User (stub — replace with real DB call) ─────────────────────
    // const user = await User.findOne({ email }).select('+password');
    const user = await _stubFindUser(email); // replace in production

    // ── Wrong credentials ─────────────────────────────────────────────────
    if (!user || !_stubVerifyPassword(password, user.passwordHash)) {
      // ✅ Safe: log HMAC hash — correlatable but not reversible
      log.warn({
        emailHash: hmacMask(email),
        emailMask: maskEmail(email),
        ip:        maskIp(req.ip),
        reason:    'Invalid credentials',
      }, 'Login failed');

      await AuditLog.record({
        action:    'LOGIN_FAILURE',
        endpoint:  '/api/v1/auth/login',
        method:    'POST',
        result:    'denied',
        statusCode: 401,
        requestId,
        ipMasked:  maskIp(req.ip),
        userAgent: req.headers['user-agent'],
        reason:    'Invalid credentials',
        // No userId — user not yet identified / may not exist
      });

      return res.status(401).json({ error: 'Invalid email or password' });
    }

    // ── Successful Authentication ──────────────────────────────────────────
    // const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, ...);

    // ✅ Safe: userId (ObjectId), role, schoolId — NOT email, name, or token
    log.info({
      userId:    String(user._id),
      role:      user.role,
      schoolId:  String(user.schoolId),
      emailHash: hmacMask(email),           // for correlation only
    }, 'User login successful');

    await AuditLog.record({
      userId:    user._id,
      schoolId:  user.schoolId,
      role:      user.role,
      action:    'LOGIN_SUCCESS',
      endpoint:  '/api/v1/auth/login',
      method:    'POST',
      result:    'allowed',
      statusCode: 200,
      requestId,
      ipMasked:  maskIp(req.ip),
      userAgent: req.headers['user-agent'],
    });

    // ❌ WRONG  — never do this:
    // res.json({ token, user });             // would log full user object
    // log.info('Login: ' + email + ' ' + token);

    // ✅ CORRECT — return minimal payload
    return res.status(200).json({
      token:  'stub_jwt_token', // replace with real JWT
      userId: String(user._id),
      role:   user.role,
    });

  } catch (err) {
    // ✅ Safe: log err.message and err.code — NOT err.stack in production
    log.error({
      err: {
        message: err.message,
        code:    err.code,
        // stack: NEVER log in production — reveals code structure
      },
      emailHash: hmacMask(email),
    }, 'Login error — unexpected exception');

    return res.status(500).json({ error: 'Internal server error' });
  }
}

// ─── logoutController ────────────────────────────────────────────────────────
/**
 * POST /api/v1/auth/logout
 */
async function logoutController(req, res) {
  const log = getLogger();
  const { requestId, userId, schoolId, role } = getRequestContext();

  log.info({ userId, role }, 'User logout');

  await AuditLog.record({
    userId,
    schoolId,
    role,
    action:    'LOGOUT',
    endpoint:  '/api/v1/auth/logout',
    method:    'POST',
    result:    'allowed',
    statusCode: 200,
    requestId,
    ipMasked:  maskIp(req.ip),
  });

  // Invalidate token on client side
  return res.status(200).json({ message: 'Logged out' });
}

// ─── changePasswordController ─────────────────────────────────────────────────
/**
 * PATCH /api/v1/auth/password
 * Demonstrates: never log old or new password even on error.
 */
async function changePasswordController(req, res) {
  const log = getLogger();
  const { requestId, userId, schoolId, role } = getRequestContext();

  // ✅ Only log that a password change was attempted — not what the passwords were
  log.info({ userId, role }, 'Password change initiated');

  const { currentPassword, newPassword } = req.body;

  if (!currentPassword || !newPassword) {
    log.warn({ userId, missing: sanitiseKeys(req.body) }, 'Password change: missing fields');
    return res.status(400).json({ error: 'Both current and new password are required' });
  }

  try {
    // ... verify currentPassword against hash, update with newPassword hash ...

    log.info({ userId, schoolId, role }, 'Password changed successfully');

    await AuditLog.record({
      userId, schoolId, role,
      action:    'PASSWORD_CHANGE',
      endpoint:  '/api/v1/auth/password',
      method:    'PATCH',
      result:    'allowed',
      statusCode: 200,
      requestId,
      ipMasked:  maskIp(req.ip),
    });

    return res.status(200).json({ message: 'Password updated successfully' });

  } catch (err) {
    log.error({ err: { message: err.message, code: err.code }, userId }, 'Password change failed');
    return res.status(500).json({ error: 'Internal server error' });
  }
}

// ─── Stubs (replace with real implementations) ───────────────────────────────
async function _stubFindUser(email) {
  // Replace: return User.findOne({ email }).select('+password +tokenVersion');
  return {
    _id:          '6641a3f000000000000000ab',
    schoolId:     '6641a3f000000000000000cd',
    role:         'teacher',
    passwordHash: 'hashed_password_stub',
  };
}

function _stubVerifyPassword(plain, hash) {
  // Replace: return bcrypt.compare(plain, hash);
  return plain === 'correct_password'; // stub only
}

module.exports = {
  loginController,
  logoutController,
  changePasswordController,
};
