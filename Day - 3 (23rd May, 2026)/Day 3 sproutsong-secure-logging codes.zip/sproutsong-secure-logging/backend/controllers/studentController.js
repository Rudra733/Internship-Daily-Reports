// backend/controllers/studentController.js
// SproutSong — Student Controller (Secure Logging Reference Implementation)
//
// Demonstrates secure logging for student-related operations.
// Student names, Aadhaar, parent contacts — NEVER appear in logs.
//
// v1.0 | May 2026 | CONFIDENTIAL

'use strict';

const AuditLog = require('../models/AuditLog');
const { getLogger, getRequestContext } = require('../middleware/requestId');
const { hmacMask, maskAadhaar, maskIp } = require('../utils/piiMask');
const { encryptForAudit } = require('../utils/auditEncrypt');

// ─── getStudentController ─────────────────────────────────────────────────────
/**
 * GET /api/v1/students/:id
 * Fetch a single student record.
 */
async function getStudentController(req, res) {
  const log = getLogger();
  const { requestId, userId, schoolId, role } = getRequestContext();

  const { id: studentId } = req.params;

  // ✅ Log the ObjectId — not the student's name
  log.info({ studentId, schoolId, role }, 'Student record fetch requested');

  try {
    // const student = await Student.findOne({ _id: studentId, schoolId });
    const student = _stubGetStudent(studentId, schoolId); // stub

    if (!student) {
      log.warn({ studentId, schoolId, role }, 'Student not found');
      return res.status(404).json({ error: 'Student not found' });
    }

    // ✅ Audit log: encrypt the student's name for compliance trail
    // This records WHO was accessed without exposing PII in plain log lines
    await AuditLog.record({
      userId, schoolId, role,
      action:          'STUDENT_RECORD_READ',
      endpoint:        '/api/v1/students/:id',
      method:          'GET',
      result:          'allowed',
      statusCode:      200,
      encryptedTarget: encryptForAudit(student.name), // AES-256-GCM
      requestId,
      ipMasked:        maskIp(req.ip),
    });

    // ✅ Log success with ObjectId only — no name, no Aadhaar
    log.info({
      studentId:  String(student._id),
      schoolId,
      grade:      student.grade,    // grade is not PII
      section:    student.section,  // section is not PII
    }, 'Student record fetched');

    return res.status(200).json({ student });

  } catch (err) {
    log.error({
      err:       { message: err.message, code: err.code },
      studentId,
      schoolId,
    }, 'Error fetching student record');

    return res.status(500).json({ error: 'Internal server error' });
  }
}

// ─── enrollStudentController ──────────────────────────────────────────────────
/**
 * POST /api/v1/students
 * Enrol a new student.
 */
async function enrollStudentController(req, res) {
  const log = getLogger();
  const { requestId, userId, schoolId, role } = getRequestContext();

  log.info({ schoolId, role }, 'Student enrolment initiated');

  try {
    // const student = await Student.create({ ...req.body, schoolId });
    const student = _stubCreateStudent(req.body, schoolId); // stub

    // ✅ Log ObjectId and non-PII fields only
    log.info({
      studentId: String(student._id),
      schoolId,
      grade:     student.grade,
      // ❌ NEVER: student.name, student.aadhaar, student.parentName
    }, 'Student enrolled');

    await AuditLog.record({
      userId, schoolId, role,
      action:          'STUDENT_ENROLLED',
      endpoint:        '/api/v1/students',
      method:          'POST',
      result:          'allowed',
      statusCode:      201,
      encryptedTarget: encryptForAudit(student.name), // encrypted for audit trail
      requestId,
      ipMasked:        maskIp(req.ip),
    });

    // ✅ Return full record to client but don't log it
    return res.status(201).json({ studentId: String(student._id) });

  } catch (err) {
    log.error({
      err:      { message: err.message, code: err.code },
      schoolId,
      role,
    }, 'Student enrolment failed');

    return res.status(500).json({ error: 'Internal server error' });
  }
}

// ─── getCounsellingRecordController ──────────────────────────────────────────
/**
 * GET /api/v1/counselling/:studentId
 * Highly sensitive — counselling notes are NEVER logged.
 */
async function getCounsellingRecordController(req, res) {
  const log = getLogger();
  const { requestId, userId, schoolId, role } = getRequestContext();
  const { studentId } = req.params;

  // Only teachers/counsellors/admin can access — enforce in middleware
  log.info({ studentId, role }, 'Counselling record access');

  try {
    // const record = await CounsellingRecord.findOne({ studentId, schoolId });
    const record = _stubGetCounselling(studentId); // stub

    if (!record) {
      log.warn({ studentId, schoolId, role }, 'Counselling record not found');
      return res.status(404).json({ error: 'Record not found' });
    }

    // ✅ Mandatory audit entry for every sensitive record read
    await AuditLog.record({
      userId, schoolId, role,
      action:          'COUNSELLING_RECORD_READ',
      endpoint:        '/api/v1/counselling/:studentId',
      method:          'GET',
      result:          'allowed',
      statusCode:      200,
      encryptedTarget: encryptForAudit(studentId), // who was accessed
      requestId,
      ipMasked:        maskIp(req.ip),
    });

    // ✅ Log access event — NEVER log the notes themselves
    log.info({
      studentId,
      schoolId,
      role,
      // ❌ NEVER: record.notes, record.diagnosis, any counselling content
    }, 'Counselling record accessed — content not logged');

    return res.status(200).json({ record });

  } catch (err) {
    log.error({
      err: { message: err.message, code: err.code },
      studentId,
    }, 'Error fetching counselling record');
    return res.status(500).json({ error: 'Internal server error' });
  }
}

// ─── Stubs ─────────────────────────────────────────────────────────────────────
function _stubGetStudent(id, schoolId) {
  return { _id: id, schoolId, name: 'Priya Sharma', grade: '8', section: 'A', aadhaar: '123412341234' };
}
function _stubCreateStudent(body, schoolId) {
  return { _id: '6641b2c000000000000000ef', ...body, schoolId };
}
function _stubGetCounselling(studentId) {
  return { studentId, notes: 'Confidential counselling content — never log this' };
}

module.exports = {
  getStudentController,
  enrollStudentController,
  getCounsellingRecordController,
};
