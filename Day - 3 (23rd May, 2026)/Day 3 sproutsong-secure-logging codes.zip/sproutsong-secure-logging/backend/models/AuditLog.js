// backend/models/AuditLog.js
// SproutSong — Security Audit Log Model (MongoDB / Mongoose)
//
// Stores security-sensitive events: authentication failures, access denials,
// role changes, and sensitive data access. PII fields are encrypted with
// AES-256-GCM (see utils/auditEncrypt.js) before storage.
//
// Retention: 90 days in MongoDB (TTL index) + 1-year encrypted backup (S3/GCS).
// Access:    Super Admin + DevOps only — not accessible to regular developers.
//
// v1.0 | May 2026 | CONFIDENTIAL

'use strict';

const mongoose = require('mongoose');
const { Schema } = mongoose;

// ─── Action Types ─────────────────────────────────────────────────────────────
const ACTION_TYPES = [
  // Auth
  'LOGIN_SUCCESS',
  'LOGIN_FAILURE',
  'LOGOUT',
  'TOKEN_REFRESH',
  'PASSWORD_CHANGE',
  'OTP_VERIFIED',
  'OTP_FAILED',

  // Access control
  'ACCESS_DENIED_401',
  'ACCESS_DENIED_403',
  'RATE_LIMIT_HIT',

  // Sensitive reads
  'STUDENT_RECORD_READ',
  'COUNSELLING_RECORD_READ',
  'FEE_RECORD_READ',
  'PARENT_CONTACT_READ',

  // Writes
  'STUDENT_ENROLLED',
  'STUDENT_UPDATED',
  'STUDENT_DELETED',
  'FEE_PAYMENT_RECORDED',
  'ROLE_CHANGED',
  'USER_CREATED',
  'USER_DEACTIVATED',
  'EXAM_PUBLISHED',
  'HOSTEL_RECORD_UPDATED',
];

// ─── Schema ───────────────────────────────────────────────────────────────────
const auditLogSchema = new Schema(
  {
    // ── Who ────────────────────────────────────────────────────────────────
    userId: {
      type: Schema.Types.ObjectId,
      ref:  'User',
      index: true,
      // NOTE: Store ObjectId only. Email is NOT stored here — use encryptedEmail
      // if email must appear for compliance reasons.
    },

    schoolId: {
      type:  Schema.Types.ObjectId,
      ref:   'School',
      index: true,
      // Tenant anchor — ensures cross-school data is never mixed
    },

    role: {
      type: String,
      enum: ['superAdmin', 'admin', 'teacher', 'parent', 'student', 'system'],
    },

    // ── What ───────────────────────────────────────────────────────────────
    action: {
      type:     String,
      enum:     ACTION_TYPES,
      required: true,
      index:    true,
    },

    endpoint: {
      type: String,
      // Route PATTERN only — never actual param values
      // e.g. '/api/v1/students/:id' not '/api/v1/students/6641a3f...'
    },

    method: {
      type: String,
      enum: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
    },

    result: {
      type: String,
      enum: ['allowed', 'denied', 'error'],
    },

    statusCode: {
      type: Number,
    },

    // ── Encrypted PII Fields (AES-256-GCM) ────────────────────────────────
    // Only populate these when compliance requires knowing WHO was affected.
    // All values stored as encrypted envelopes: "v1:<iv>:<tag>:<ciphertext>"
    encryptedTarget: {
      type: String,
      // The student/user whose record was accessed — encrypted before storage
    },

    encryptedEmail: {
      type: String,
      // Actor's email — only for compliance audit; encrypted with AES-256-GCM
    },

    // ── Context ────────────────────────────────────────────────────────────
    requestId: {
      type: String,
      // UUID — correlates this audit entry with application log lines
    },

    ipMasked: {
      type: String,
      // Last octet truncated: "192.168.1.xxx"
    },

    userAgent: {
      type: String,
      // Browser/app agent string — not PII but useful for security investigation
    },

    // ── Reason / Notes ─────────────────────────────────────────────────────
    reason: {
      type: String,
      // Human-readable reason for denial/error — must NOT contain PII
      // e.g. 'Insufficient role: teacher cannot access superAdmin endpoint'
    },

    // ── TTL Field ──────────────────────────────────────────────────────────
    // MongoDB TTL index deletes documents 90 days after this timestamp.
    // For compliance backups, export to encrypted S3/GCS before TTL fires.
    ts: {
      type:    Date,
      default: Date.now,
      index:   true,
      expires: 60 * 60 * 24 * 90,  // 90 days in seconds
    },
  },
  {
    // Disable Mongoose's default __v field
    versionKey: false,

    // Use a dedicated collection — separate from application data
    collection: 'audit_logs',
  },
);

// ─── Compound Indexes ─────────────────────────────────────────────────────────
// Support common audit queries without full collection scans

// Query: "All actions by user X in school Y between date A and date B"
auditLogSchema.index({ schoolId: 1, userId: 1, ts: -1 });

// Query: "All ACCESS_DENIED events in school Y last 7 days"
auditLogSchema.index({ schoolId: 1, action: 1, ts: -1 });

// Query: "All events for a specific request (correlate with app logs)"
auditLogSchema.index({ requestId: 1 });

// ─── Static: Create Audit Entry ──────────────────────────────────────────────
/**
 * Convenience method — enforces required shape and avoids ad-hoc create() calls.
 *
 * @param {object} params
 * @returns {Promise<AuditLog>}
 */
auditLogSchema.statics.record = async function ({
  userId,
  schoolId,
  role,
  action,
  endpoint,
  method,
  result,
  statusCode,
  encryptedTarget,
  encryptedEmail,
  requestId,
  ipMasked,
  userAgent,
  reason,
}) {
  return this.create({
    userId,
    schoolId,
    role,
    action,
    endpoint,
    method,
    result,
    statusCode,
    encryptedTarget,
    encryptedEmail,
    requestId,
    ipMasked,
    userAgent,
    reason,
    ts: new Date(),
  });
};

const AuditLog = mongoose.model('AuditLog', auditLogSchema);

module.exports = AuditLog;

// ─── Usage Examples ───────────────────────────────────────────────────────────
//
//  const AuditLog       = require('../models/AuditLog');
//  const { encryptForAudit } = require('../utils/auditEncrypt');
//  const { maskIp }          = require('../utils/piiMask');
//  const { getRequestContext } = require('../middleware/requestId');
//
//  // 1. Log a 403 denial
//  const { requestId, userId, schoolId, role } = getRequestContext();
//  await AuditLog.record({
//    userId, schoolId, role,
//    action:     'ACCESS_DENIED_403',
//    endpoint:   req.route?.path,
//    method:     req.method,
//    result:     'denied',
//    statusCode: 403,
//    requestId,
//    ipMasked:   maskIp(req.ip),
//    reason:     'Insufficient role: teacher cannot access admin endpoint',
//  });
//
//  // 2. Log a sensitive counselling record read WITH encrypted target
//  await AuditLog.record({
//    userId, schoolId, role,
//    action:          'COUNSELLING_RECORD_READ',
//    endpoint:        '/api/v1/counselling/:id',
//    method:          'GET',
//    result:          'allowed',
//    statusCode:      200,
//    encryptedTarget: encryptForAudit(student.name),  // AES-256-GCM
//    requestId,
//    ipMasked:        maskIp(req.ip),
//  });
