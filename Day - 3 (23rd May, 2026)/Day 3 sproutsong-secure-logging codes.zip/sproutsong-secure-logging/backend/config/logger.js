// backend/config/logger.js
// SproutSong — Production-Ready Pino Logger with Built-in PII Redaction
// v1.0 | May 2026 | CONFIDENTIAL

'use strict';

const pino = require('pino');

// ─── PII & Sensitive Field Redaction Paths ───────────────────────────────────
// Pino will AUTOMATICALLY censor these fields before writing any log line.
// Add new fields here as the schema evolves — never rely on callers to remember.
const REDACT_PATHS = [
  // ── Auth & Credentials ──────────────────────────────────────────────────
  'req.headers.authorization',
  'req.headers.cookie',
  'body.password',
  'body.confirmPassword',
  'body.currentPassword',
  'body.newPassword',
  'body.token',
  'body.refreshToken',
  'body.accessToken',
  'body.sessionToken',
  'body.otp',
  'body.pin',

  // ── PII — Student & Parent Data (DPDP Act 2023) ─────────────────────────
  'body.email',
  'body.phone',
  'body.phoneNumber',
  'body.mobileNumber',
  'body.aadhaar',
  'body.aadhaarNumber',
  'body.dateOfBirth',
  'body.dob',
  'body.address',
  'body.parentName',
  'body.guardianName',
  'body.studentName',
  'body.name',                   // Generic name field — log ObjectId instead

  // ── Wildcard: catches nested PII regardless of object depth ─────────────
  '*.email',
  '*.phone',
  '*.aadhaar',
  '*.password',
  '*.token',
  '*.otp',

  // ── Financial (PCI-DSS equivalent) ──────────────────────────────────────
  'body.cardNumber',
  'body.cvv',
  'body.accountNumber',
  'body.ifsc',
  'body.bankAccount',

  // ── Internal / Infrastructure ────────────────────────────────────────────
  'body.tokenVersion',
  'body.secretKey',
  'body.apiKey',
];

// ─── Logger Instance ─────────────────────────────────────────────────────────
const logger = pino({
  // Log level controlled exclusively via env — NEVER hardcode
  level: process.env.LOG_LEVEL || 'info',

  // Redact all PII fields before any log is written to stdout
  redact: {
    paths: REDACT_PATHS,
    censor: '[REDACTED]',
  },

  // Base fields automatically added to every single log entry
  base: {
    service: process.env.SERVICE_NAME || 'sproutsong-api',
    env:     process.env.NODE_ENV     || 'development',
    version: process.env.npm_package_version || '1.0.0',
  },

  // ISO 8601 UTC timestamps on every log line
  timestamp: pino.stdTimeFunctions.isoTime,

  // Human-readable in dev (pino-pretty), fast JSON in production
  transport: process.env.NODE_ENV !== 'production'
    ? {
        target: 'pino-pretty',
        options: {
          colorize:        true,
          translateTime:   'SYS:standard',
          ignore:          'pid,hostname',
          messageFormat:   '[{service}] {msg}',
        },
      }
    : undefined,
});

module.exports = logger;
