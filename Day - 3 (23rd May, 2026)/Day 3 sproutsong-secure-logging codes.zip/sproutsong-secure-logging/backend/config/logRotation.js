// backend/config/logRotation.js
// SproutSong — File-Based Log Rotation (Fallback Only)
//
// Use this ONLY if a log aggregator (Loki, Datadog, CloudWatch) is not yet
// configured. Primary logging always targets stdout → aggregator.
//
// Requires: npm install pino-roll
//
// Rotation policy:
//   - Rotate daily OR when the file exceeds 50 MB (whichever comes first)
//   - Keep 30 rotated files (= 30 days of history)
//   - Log directory: /var/log/sproutsong/
//
// v1.0 | May 2026 | CONFIDENTIAL

'use strict';

const pino = require('pino');
const path = require('path');

const LOG_DIR  = process.env.LOG_DIR  || '/var/log/sproutsong';
const LOG_FILE = path.join(LOG_DIR, 'app.log');

const REDACT_PATHS = [
  'req.headers.authorization', 'req.headers.cookie',
  'body.password', 'body.confirmPassword', 'body.token',
  'body.refreshToken', 'body.otp', 'body.email', 'body.phone',
  'body.aadhaar', 'body.cardNumber', 'body.cvv', 'body.accountNumber',
  '*.password', '*.token', '*.otp', '*.email', '*.phone', '*.aadhaar',
];

/**
 * Creates a Pino logger with pino-roll file rotation.
 * Only instantiate this when LOG_TRANSPORT=file is set.
 * Default transport remains stdout → aggregator.
 */
function createFileLogger() {
  return pino({
    level: process.env.LOG_LEVEL || 'info',

    redact: {
      paths:  REDACT_PATHS,
      censor: '[REDACTED]',
    },

    base: {
      service: process.env.SERVICE_NAME || 'sproutsong-api',
      env:     process.env.NODE_ENV,
    },

    timestamp: pino.stdTimeFunctions.isoTime,

    transport: {
      targets: [
        // ── File rotation (primary target in this config) ─────────────────
        {
          target:  'pino-roll',
          level:   'info',
          options: {
            file:      LOG_FILE,
            frequency: 'daily',       // Rotate at midnight UTC
            size:      '50m',         // Also rotate if file reaches 50 MB
            limit:     { count: 30 }, // Retain 30 files = 30 days
            // Files are named: app.log, app.log.1, app.log.2, ...
          },
        },

        // ── Separate error log for alerting ──────────────────────────────
        {
          target:  'pino-roll',
          level:   'error',
          options: {
            file:      path.join(LOG_DIR, 'error.log'),
            frequency: 'daily',
            size:      '20m',
            limit:     { count: 90 }, // Keep error logs longer
          },
        },
      ],
    },
  });
}

// Export factory so app.js can decide which transport to use
module.exports = { createFileLogger };

// ─── Usage in app.js ──────────────────────────────────────────────────────────
//
//  let logger;
//  if (process.env.LOG_TRANSPORT === 'file') {
//    const { createFileLogger } = require('./config/logRotation');
//    logger = createFileLogger();
//    logger.warn('Using file-based log rotation. Configure an aggregator for production.');
//  } else {
//    logger = require('./config/logger');  // stdout → aggregator (default)
//  }
//  module.exports = logger;
