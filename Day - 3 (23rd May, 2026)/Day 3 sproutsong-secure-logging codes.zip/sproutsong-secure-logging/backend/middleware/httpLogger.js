// backend/middleware/httpLogger.js
// SproutSong — HTTP Request Logging Middleware (pino-http)
// Replaces Morgan. Logs route PATTERNS, not actual param values.
// v1.0 | May 2026 | CONFIDENTIAL

'use strict';

const pinoHttp = require('pino-http');
const logger   = require('../config/logger');

// ─── pino-http middleware ─────────────────────────────────────────────────────
const httpLogger = pinoHttp({
  logger,

  // Log the route pattern (/api/v1/students/:id) instead of the actual URL
  // to prevent student IDs and other path params from appearing in logs.
  customSuccessMessage(req, res) {
    const route = req.route?.path || req.url?.split('?')[0] || req.url;
    return `${req.method} ${route} → ${res.statusCode}`;
  },

  customErrorMessage(req, res, err) {
    const route = req.route?.path || req.url?.split('?')[0] || req.url;
    return `${req.method} ${route} → ${res.statusCode} — ${err.message}`;
  },

  // Log level by HTTP status code
  customLogLevel(req, res, err) {
    if (res.statusCode >= 500 || err) return 'error';
    if (res.statusCode >= 400)       return 'warn';
    return 'info';
  },

  // Rename req/res keys for clarity
  customAttributeKeys: {
    req:          'request',
    res:          'response',
    err:          'error',
    responseTime: 'duration_ms',
  },

  // Serialise only safe, non-PII fields from request and response
  serializers: {
    req(req) {
      return {
        method:    req.method,
        // Strip query string entirely — may contain PII (email=..., phone=...)
        url:       req.url.split('?')[0],
        userAgent: req.headers['user-agent'],
        // ❌ NEVER log: req.headers.authorization, req.headers.cookie, req.body
      };
    },
    res(res) {
      return {
        statusCode: res.statusCode,
        // ❌ NEVER log: res.body — may contain student records
      };
    },
  },

  // Do not log health-check endpoints to reduce noise
  autoLogging: {
    ignore(req) {
      return ['/health', '/ping', '/favicon.ico'].includes(req.url);
    },
  },
});

module.exports = httpLogger;

// ─── Usage ────────────────────────────────────────────────────────────────────
// In app.js — register BEFORE all route handlers:
//
//   const httpLogger = require('./middleware/httpLogger');
//   app.use(httpLogger);
