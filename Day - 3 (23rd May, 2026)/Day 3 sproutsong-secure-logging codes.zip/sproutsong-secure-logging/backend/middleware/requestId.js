// backend/middleware/requestId.js
// SproutSong — Request ID (Correlation ID) Middleware
//
// Every inbound request gets a unique UUID. All log lines generated during
// that request's lifecycle share the same requestId, enabling full trace
// reconstruction in any log aggregator (Loki, Datadog, CloudWatch).
//
// Uses Node.js AsyncLocalStorage so the context is propagated automatically
// through async/await chains — no need to pass req/res through every function.
//
// v1.0 | May 2026 | CONFIDENTIAL

'use strict';

const { randomUUID }        = require('crypto');
const { AsyncLocalStorage } = require('async_hooks');
const logger                = require('../config/logger');

// ─── Storage ─────────────────────────────────────────────────────────────────
// One store per async execution chain (i.e. per request).
// Shape: { requestId, userId, schoolId, role }
const als = new AsyncLocalStorage();

// ─── Middleware 1: Attach Request ID (register FIRST in app.js) ───────────────
/**
 * Generates or inherits a requestId for every incoming request.
 * Downstream services can pass `x-request-id` to maintain the same ID
 * across service boundaries.
 */
const requestIdMiddleware = (req, res, next) => {
  const requestId = req.headers['x-request-id'] || randomUUID();

  // Echo the ID back so the client can correlate their logs too
  res.setHeader('x-request-id', requestId);

  // Initialise the store — userId/schoolId/role filled in after auth
  als.run(
    {
      requestId,
      userId:   null,
      schoolId: null,
      role:     null,
    },
    next,
  );
};

// ─── Middleware 2: Populate User Context (register AFTER authenticate) ─────────
/**
 * Called after the authenticate middleware has verified the JWT.
 * Injects user context (ObjectId, schoolId, role) into the store so every
 * subsequent log line includes them automatically.
 *
 * IMPORTANT: Only logs ObjectId — never email or name.
 */
const setLogContext = (req, _res, next) => {
  const store = als.getStore();
  if (store && req.user) {
    store.userId   = req.user.id;        // MongoDB ObjectId string — NOT email
    store.schoolId = req.user.schoolId;  // Tenant anchor
    store.role     = req.user.role;      // Role at time of request
  }
  next();
};

// ─── Helper: Get Context-Aware Child Logger ───────────────────────────────────
/**
 * Returns a Pino child logger with the current request's context baked in.
 * Every log line from this logger will automatically include:
 *   { requestId, userId, schoolId, role }
 *
 * Usage in controllers/services:
 *   const { getLogger } = require('../middleware/requestId');
 *   const log = getLogger();
 *   log.info({ studentId }, 'Student record fetched');
 */
const getLogger = () => {
  const ctx = als.getStore() || {};
  return logger.child(ctx);
};

// ─── Helper: Read raw store (for non-logging needs) ──────────────────────────
const getRequestContext = () => als.getStore() || {};

module.exports = {
  requestIdMiddleware,
  setLogContext,
  getLogger,
  getRequestContext,
};

// ─── Usage in app.js ──────────────────────────────────────────────────────────
//
//   const { requestIdMiddleware, setLogContext } = require('./middleware/requestId');
//   const authenticate = require('./middleware/authenticate');
//
//   app.use(requestIdMiddleware);          // 1. Always first
//   app.use(httpLogger);                   // 2. HTTP request logging
//   app.use('/api', authenticate);         // 3. JWT verification
//   app.use('/api', setLogContext);        // 4. Populate user context into logger
//   app.use('/api', routes);              // 5. Route handlers
