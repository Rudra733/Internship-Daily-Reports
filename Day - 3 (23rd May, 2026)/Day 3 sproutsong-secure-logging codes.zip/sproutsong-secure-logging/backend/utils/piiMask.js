// backend/utils/piiMask.js
// SproutSong — PII Masking Utilities
//
// Provides deterministic, irreversible masking functions for use in log
// statements. Choose the technique based on whether you need correlation,
// human readability, or strict compliance.
//
// Algorithm Guide:
//   hmacMask()    — Email, phone, Aadhaar. Irreversible but correlatable.
//   partialMask() — Phone / Aadhaar display (last 4 digits shown).
//   maskEmail()   — Human-readable email (j**@school.com).
//   maskIp()      — Truncates last IP octet (DPDP/GDPR compliance).
//
// v1.0 | May 2026 | CONFIDENTIAL

'use strict';

const crypto = require('crypto');

// ─── HMAC Key ─────────────────────────────────────────────────────────────────
// Loaded once at startup. Missing key crashes fast — better than silent PII leaks.
const HMAC_KEY = process.env.LOG_HMAC_KEY;

if (!HMAC_KEY || HMAC_KEY.length < 32) {
  // Crash in production; warn in test/dev where key may not be set
  if (process.env.NODE_ENV === 'production') {
    throw new Error(
      '[piiMask] LOG_HMAC_KEY is missing or too short. ' +
      'Generate with: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"',
    );
  } else {
    console.warn(
      '[piiMask] WARNING: LOG_HMAC_KEY not set. Using insecure fallback for non-production.',
    );
  }
}

const _hmacKey = HMAC_KEY || 'INSECURE_DEV_KEY_DO_NOT_USE_IN_PRODUCTION_00000000';

// ─── hmacMask ─────────────────────────────────────────────────────────────────
/**
 * HMAC-SHA256 — keyed, deterministic, irreversible.
 *
 * The same input always produces the same output (per key), so you can still
 * correlate log entries for the same user across requests without ever storing
 * or exposing the original value.
 *
 * Output: "hmac:3f7a2b8c1e9d4a6f" (prefix + first 16 hex chars = 64 bits)
 *
 * Use for: email, phone, Aadhaar number
 *
 * @param {string|number} value - The PII value to mask
 * @returns {string}
 */
function hmacMask(value) {
  if (value === null || value === undefined || value === '') return '[EMPTY]';
  try {
    return (
      'hmac:' +
      crypto
        .createHmac('sha256', _hmacKey)
        .update(String(value).toLowerCase().trim())
        .digest('hex')
        .slice(0, 16)  // 16 hex chars = 64-bit — sufficient for log correlation
    );
  } catch {
    return '[MASK_ERROR]';
  }
}

// ─── partialMask ──────────────────────────────────────────────────────────────
/**
 * Partial masking — keeps the last N characters, replaces the rest with `char`.
 *
 * Use for: phone numbers (+91 ****7890), Aadhaar (xxxx-xxxx-1234)
 *
 * @param {string|number} value    - The value to mask
 * @param {number}        keepLast - Number of trailing characters to reveal (default: 4)
 * @param {string}        char     - Replacement character (default: '*')
 * @returns {string}
 */
function partialMask(value, keepLast = 4, char = '*') {
  if (value === null || value === undefined || value === '') return '[EMPTY]';
  const s = String(value).replace(/\s/g, '');           // strip whitespace
  if (s.length <= keepLast) return char.repeat(s.length); // mask entirely if too short
  return char.repeat(s.length - keepLast) + s.slice(-keepLast);
}

// ─── maskEmail ────────────────────────────────────────────────────────────────
/**
 * Human-readable email masking.
 * Shows first character of local part + domain.
 * Example: "jane.doe@school.com" → "j**@school.com"
 *
 * Use when a human must be able to roughly identify the account from logs
 * without exposing the full address. Combine with hmacMask() for correlation.
 *
 * @param {string} email
 * @returns {string}
 */
function maskEmail(email) {
  if (!email || typeof email !== 'string') return '[INVALID_EMAIL]';
  if (!email.includes('@'))               return '[INVALID_EMAIL]';

  const [local, domain] = email.split('@');
  if (!local || !domain)                  return '[INVALID_EMAIL]';

  const visibleChar = local[0] || '*';
  return `${visibleChar}**@${domain}`;
}

// ─── maskIp ───────────────────────────────────────────────────────────────────
/**
 * IP address anonymisation — truncates the last octet.
 * Compliant with GDPR recital 26 and DPDP Act guidance on pseudonymisation.
 *
 * IPv4: "192.168.1.45"  → "192.168.1.xxx"
 * IPv6: "2001:db8::1"   → "2001:db8::xxx" (last segment)
 *
 * @param {string} ip
 * @returns {string}
 */
function maskIp(ip) {
  if (!ip || typeof ip !== 'string') return '[NO_IP]';

  // IPv4
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(ip.trim())) {
    return ip.replace(/\.\d+$/, '.xxx');
  }

  // IPv6 — truncate last colon-separated segment
  if (ip.includes(':')) {
    return ip.replace(/:[^:]+$/, ':xxx');
  }

  return '[UNKNOWN_IP_FORMAT]';
}

// ─── maskAadhaar ─────────────────────────────────────────────────────────────
/**
 * Aadhaar-specific masking — shows only last 4 digits in xxxx-xxxx-1234 format.
 * Full Aadhaar logging is a UIDAI violation with criminal liability.
 *
 * @param {string|number} aadhaar
 * @returns {string}
 */
function maskAadhaar(aadhaar) {
  if (!aadhaar) return '[EMPTY]';
  const digits = String(aadhaar).replace(/\D/g, '');
  if (digits.length !== 12) return '[INVALID_AADHAAR]';
  return `xxxx-xxxx-${digits.slice(-4)}`;
}

// ─── sanitiseKeys ─────────────────────────────────────────────────────────────
/**
 * Given a request body object, returns only the top-level key names.
 * Safe to log — reveals the structure without exposing any values.
 *
 * Use instead of: logger.debug(req.body)
 * Use as:         logger.debug({ bodyKeys: sanitiseKeys(req.body) }, 'Request received')
 *
 * @param {object} obj
 * @returns {string[]}
 */
function sanitiseKeys(obj) {
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return [];
  return Object.keys(obj);
}

module.exports = {
  hmacMask,
  partialMask,
  maskEmail,
  maskIp,
  maskAadhaar,
  sanitiseKeys,
};

// ─── Usage Examples ───────────────────────────────────────────────────────────
//
//  const { hmacMask, maskEmail, partialMask, maskAadhaar, sanitiseKeys } =
//    require('../utils/piiMask');
//
//  // Login controller
//  log.info({
//    emailHash: hmacMask(email),        // "hmac:3f7a2b8c1e9d4a6f" — correlatable
//    emailMask: maskEmail(email),       // "j**@school.com"        — human readable
//    // password: NEVER LOG
//  }, 'Login attempt');
//
//  // Student enrolment
//  log.info({
//    studentId: student._id,            // ObjectId only
//    schoolId,
//    // student.name:   NEVER LOG
//    // student.aadhaar: use hmacMask or maskAadhaar
//    aadhaarMask: maskAadhaar(student.aadhaar),  // "xxxx-xxxx-1234"
//  }, 'Student enrolled');
//
//  // Phone in access log
//  log.info({
//    phoneMask: partialMask(phone),     // "********7890"
//  }, 'OTP sent');
//
//  // Request body (safe structure log)
//  log.debug({
//    bodyKeys: sanitiseKeys(req.body),  // ["email","password","deviceId"]
//  }, 'Request received');
