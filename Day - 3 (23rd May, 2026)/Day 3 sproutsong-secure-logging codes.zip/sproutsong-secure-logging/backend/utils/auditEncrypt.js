// backend/utils/auditEncrypt.js
// SproutSong — AES-256-GCM Encryption for Audit Log Storage
//
// When PII MUST be stored in the audit log for compliance purposes (e.g. who
// accessed a student's counselling record), encrypt the sensitive field at rest
// using AES-256-GCM. Only authorised personnel with the decryption key can
// recover the original value.
//
// Output format (versioned envelope for future key rotation):
//   "v1:<iv_hex>:<authTag_hex>:<ciphertext_hex>"
//
// Security properties:
//   - 96-bit random IV per encryption (NIST recommended for GCM)
//   - 128-bit GCM authentication tag (tamper-evident)
//   - Versioned envelope — supports key rotation without re-encrypting old records
//
// v1.0 | May 2026 | CONFIDENTIAL

'use strict';

const crypto = require('crypto');

const ALGO        = 'aes-256-gcm';
const KEY_VERSION = 'v1';

// ─── Key Loading ──────────────────────────────────────────────────────────────
// AUDIT_ENCRYPTION_KEY must be a 64-character hex string (= 32 bytes).
// Generate: node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
// Rotate: every 6 months. Store securely (AWS Secrets Manager, GCP Secret Manager).

function _loadKey() {
  const hexKey = process.env.AUDIT_ENCRYPTION_KEY;

  if (!hexKey || hexKey.length !== 64) {
    if (process.env.NODE_ENV === 'production') {
      throw new Error(
        '[auditEncrypt] AUDIT_ENCRYPTION_KEY must be a 64-char hex string (32 bytes). ' +
        'Generate: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"',
      );
    }
    // Non-production: use a deterministic insecure key for tests/dev
    console.warn('[auditEncrypt] WARNING: AUDIT_ENCRYPTION_KEY not set. Using insecure dev key.');
    return Buffer.from('0'.repeat(64), 'hex');
  }

  return Buffer.from(hexKey, 'hex');
}

const KEY = _loadKey();

// ─── encryptForAudit ──────────────────────────────────────────────────────────
/**
 * Encrypts a single sensitive string value for storage in the audit log.
 *
 * Each call uses a fresh random IV — identical plaintexts produce different
 * ciphertexts, preventing frequency analysis.
 *
 * @param {string|number} value - The PII value to encrypt (name, email, etc.)
 * @returns {string} Versioned envelope: "v1:<iv>:<authTag>:<ciphertext>"
 * @throws  {Error}  If encryption fails
 */
function encryptForAudit(value) {
  if (value === null || value === undefined) {
    throw new Error('[auditEncrypt] Cannot encrypt null/undefined value');
  }

  const plaintext = String(value);
  const iv        = crypto.randomBytes(12);               // 96-bit IV (NIST GCM recommendation)
  const cipher    = crypto.createCipheriv(ALGO, KEY, iv);

  const encrypted = Buffer.concat([
    cipher.update(plaintext, 'utf8'),
    cipher.final(),
  ]);

  const authTag = cipher.getAuthTag();                    // 128-bit GCM authentication tag

  // Versioned envelope — prefix 'v1:' enables future key rotation
  return [
    KEY_VERSION,
    iv.toString('hex'),
    authTag.toString('hex'),
    encrypted.toString('hex'),
  ].join(':');
}

// ─── decryptFromAudit ─────────────────────────────────────────────────────────
/**
 * Decrypts a value previously encrypted with encryptForAudit().
 * Only authorised personnel / services with the AUDIT_ENCRYPTION_KEY may call this.
 *
 * @param {string} envelope - The "v1:<iv>:<authTag>:<ciphertext>" string
 * @returns {string} Original plaintext value
 * @throws  {Error}  If tampered, malformed, or wrong key
 */
function decryptFromAudit(envelope) {
  if (!envelope || typeof envelope !== 'string') {
    throw new Error('[auditEncrypt] Invalid envelope: expected non-empty string');
  }

  const parts = envelope.split(':');
  if (parts.length !== 4) {
    throw new Error('[auditEncrypt] Malformed envelope — expected 4 colon-separated parts');
  }

  const [version, ivHex, tagHex, dataHex] = parts;

  if (version !== KEY_VERSION) {
    throw new Error(
      `[auditEncrypt] Unknown key version "${version}". ` +
      'Implement version-specific key lookup for key rotation support.',
    );
  }

  const iv       = Buffer.from(ivHex,  'hex');
  const authTag  = Buffer.from(tagHex, 'hex');
  const data     = Buffer.from(dataHex, 'hex');

  const decipher = crypto.createDecipheriv(ALGO, KEY, iv);
  decipher.setAuthTag(authTag);

  const decrypted = Buffer.concat([
    decipher.update(data),
    decipher.final(),  // Throws if authTag verification fails (tamper detection)
  ]);

  return decrypted.toString('utf8');
}

// ─── isEncryptedEnvelope ──────────────────────────────────────────────────────
/**
 * Guard — returns true if the string looks like a valid audit envelope.
 * Use before attempting decryption on untrusted input.
 *
 * @param {string} value
 * @returns {boolean}
 */
function isEncryptedEnvelope(value) {
  if (typeof value !== 'string') return false;
  const parts = value.split(':');
  return parts.length === 4 && parts[0] === KEY_VERSION;
}

module.exports = {
  encryptForAudit,
  decryptFromAudit,
  isEncryptedEnvelope,
};

// ─── Usage Examples ───────────────────────────────────────────────────────────
//
//  const { encryptForAudit } = require('../utils/auditEncrypt');
//
//  // Counselling record access — store encrypted PII for compliance audit trail
//  await AuditLog.create({
//    userId:           req.user.id,                        // ObjectId — not PII
//    schoolId:         req.user.schoolId,
//    endpoint:         '/api/v1/counselling/:id',
//    action:           'READ',
//    result:           'allowed',
//    encryptedTarget:  encryptForAudit(student.name),     // AES-256-GCM envelope
//    ts:               new Date(),
//  });
//
//  // Decrypt when a compliance officer requests the audit trail
//  const { decryptFromAudit } = require('../utils/auditEncrypt');
//  const originalName = decryptFromAudit(auditRecord.encryptedTarget);
