// tests/secureLogging.test.js
// SproutSong — Automated Tests for Secure Logging & PII Masking
//
// Test categories:
//   1. PII Mask utilities (hmacMask, partialMask, maskEmail, maskIp, maskAadhaar)
//   2. AES-256-GCM audit encryption (encryptForAudit / decryptFromAudit)
//   3. Pino logger redaction — verifies PII never appears in log output
//   4. Compliance assertions — passwords, tokens, emails, Aadhaar never in logs
//
// Run: npm test   (or: node --test tests/secureLogging.test.js)
//
// v1.0 | May 2026 | CONFIDENTIAL

'use strict';

// ── Set required env vars before any module loads ────────────────────────────
process.env.LOG_HMAC_KEY          = 'a'.repeat(64);
process.env.AUDIT_ENCRYPTION_KEY  = 'b'.repeat(64);
process.env.NODE_ENV              = 'test';
process.env.LOG_LEVEL             = 'debug';

const assert = require('assert');
const { Writable } = require('stream');
const pino   = require('pino');

const { hmacMask, partialMask, maskEmail, maskIp, maskAadhaar, sanitiseKeys } =
  require('../backend/utils/piiMask');

const { encryptForAudit, decryptFromAudit, isEncryptedEnvelope } =
  require('../backend/utils/auditEncrypt');

// ─── Test Helpers ─────────────────────────────────────────────────────────────

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    console.log(`  ✅  ${name}`);
    passed++;
  } catch (err) {
    console.error(`  ❌  ${name}`);
    console.error(`       ${err.message}`);
    failed++;
  }
}

function eq(actual, expected, msg) {
  assert.strictEqual(actual, expected, msg || `Expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
}

function ok(condition, msg) {
  assert.ok(condition, msg);
}

function notContains(haystack, needle, msg) {
  assert.ok(
    !String(haystack).includes(needle),
    msg || `Expected output NOT to contain "${needle}" but it did`,
  );
}

// ─── 1. PII Masking Utilities ─────────────────────────────────────────────────

console.log('\n── 1. PII Masking Utilities ──────────────────────────────────');

test('hmacMask: returns "hmac:" prefix', () => {
  ok(hmacMask('test@example.com').startsWith('hmac:'), 'Expected hmac: prefix');
});

test('hmacMask: output is 5 + 16 = 21 chars', () => {
  eq(hmacMask('test@example.com').length, 21, 'Expected 21 chars: "hmac:" + 16 hex chars');
});

test('hmacMask: deterministic — same input, same output', () => {
  eq(hmacMask('user@school.com'), hmacMask('user@school.com'));
});

test('hmacMask: case-insensitive — normalised before hashing', () => {
  eq(hmacMask('User@School.COM'), hmacMask('user@school.com'));
});

test('hmacMask: different inputs produce different hashes', () => {
  ok(hmacMask('a@school.com') !== hmacMask('b@school.com'));
});

test('hmacMask: handles empty string', () => {
  eq(hmacMask(''), '[EMPTY]');
});

test('hmacMask: handles null', () => {
  eq(hmacMask(null), '[EMPTY]');
});

test('partialMask: masks all but last 4 chars', () => {
  eq(partialMask('9876543210'), '******3210');
});

test('partialMask: custom keepLast', () => {
  eq(partialMask('9876543210', 6), '****543210');
});

test('partialMask: strips spaces before masking', () => {
  eq(partialMask('9876 5432 1098 1234', 4), '***************1234');
});

test('partialMask: handles empty', () => {
  eq(partialMask(''), '[EMPTY]');
  eq(partialMask(null), '[EMPTY]');
});

test('maskEmail: shows first char + ** + @ + domain', () => {
  eq(maskEmail('jane.doe@school.com'), 'j**@school.com');
});

test('maskEmail: works with single-char local', () => {
  eq(maskEmail('a@example.com'), 'a**@example.com');
});

test('maskEmail: rejects invalid email', () => {
  eq(maskEmail('not-an-email'), '[INVALID_EMAIL]');
  eq(maskEmail(''), '[INVALID_EMAIL]');
  eq(maskEmail(null), '[INVALID_EMAIL]');
});

test('maskEmail: does NOT expose full local part', () => {
  const result = maskEmail('verylongname@school.com');
  notContains(result, 'erylongname', 'Should not contain most of local part');
});

test('maskIp: truncates last IPv4 octet', () => {
  eq(maskIp('192.168.1.45'), '192.168.1.xxx');
});

test('maskIp: handles different IPv4 addresses', () => {
  eq(maskIp('10.0.0.1'), '10.0.0.xxx');
  eq(maskIp('255.255.255.255'), '255.255.255.xxx');
});

test('maskIp: handles null/empty', () => {
  eq(maskIp(null), '[NO_IP]');
  eq(maskIp(''), '[NO_IP]');
});

test('maskAadhaar: formats as xxxx-xxxx-NNNN', () => {
  eq(maskAadhaar('123412341234'), 'xxxx-xxxx-1234');
  eq(maskAadhaar('123456789012'), 'xxxx-xxxx-9012');
});

test('maskAadhaar: rejects non-12-digit input', () => {
  eq(maskAadhaar('12345'), '[INVALID_AADHAAR]');
  eq(maskAadhaar(null), '[EMPTY]');
});

test('sanitiseKeys: returns key names only', () => {
  const keys = sanitiseKeys({ email: 'x', password: 'y', deviceId: 'z' });
  assert.deepStrictEqual(keys.sort(), ['deviceId', 'email', 'password']);
});

test('sanitiseKeys: returns [] for non-objects', () => {
  assert.deepStrictEqual(sanitiseKeys(null), []);
  assert.deepStrictEqual(sanitiseKeys('string'), []);
  assert.deepStrictEqual(sanitiseKeys([1, 2]), []);
});

// ─── 2. AES-256-GCM Audit Encryption ─────────────────────────────────────────

console.log('\n── 2. AES-256-GCM Audit Encryption ──────────────────────────');

test('encryptForAudit: returns versioned envelope string', () => {
  const env = encryptForAudit('Priya Sharma');
  ok(env.startsWith('v1:'), 'Expected "v1:" prefix');
  eq(env.split(':').length, 4, 'Expected 4 colon-separated parts');
});

test('encryptForAudit: different ciphertext each call (random IV)', () => {
  const a = encryptForAudit('same value');
  const b = encryptForAudit('same value');
  ok(a !== b, 'Each encryption should produce unique ciphertext (random IV)');
});

test('decryptFromAudit: round-trip restores original value', () => {
  const original  = 'Ravi Kumar — Class 10B';
  const encrypted = encryptForAudit(original);
  const decrypted = decryptFromAudit(encrypted);
  eq(decrypted, original);
});

test('decryptFromAudit: handles unicode / multi-byte chars', () => {
  const original  = 'प्रिया शर्मा'; // Hindi name
  const decrypted = decryptFromAudit(encryptForAudit(original));
  eq(decrypted, original);
});

test('decryptFromAudit: throws on tampered ciphertext', () => {
  const env    = encryptForAudit('sensitive');
  const parts  = env.split(':');
  parts[3]     = 'deadbeef';               // corrupt ciphertext
  const tampered = parts.join(':');
  assert.throws(() => decryptFromAudit(tampered), /error/i);
});

test('decryptFromAudit: throws on unknown version', () => {
  const env     = encryptForAudit('value');
  const bad     = 'v99:' + env.split(':').slice(1).join(':');
  assert.throws(() => decryptFromAudit(bad), /Unknown key version/);
});

test('isEncryptedEnvelope: returns true for valid envelope', () => {
  ok(isEncryptedEnvelope(encryptForAudit('test')));
});

test('isEncryptedEnvelope: returns false for plain text', () => {
  ok(!isEncryptedEnvelope('plain text'));
  ok(!isEncryptedEnvelope(null));
  ok(!isEncryptedEnvelope(''));
});

// ─── 3. Pino Logger Redaction ─────────────────────────────────────────────────

console.log('\n── 3. Pino Logger Redaction ─────────────────────────────────');

/**
 * Captures Pino log output as a string for assertion.
 * Creates a fresh logger writing to an in-memory buffer.
 */
function makeCaptureLogger(extraPaths = []) {
  const lines = [];
  const stream = new Writable({
    write(chunk, _enc, cb) {
      lines.push(chunk.toString().trim());
      cb();
    },
  });

  const REDACT_PATHS = [
    'req.headers.authorization', 'req.headers.cookie',
    'body.password', 'body.confirmPassword', 'body.token',
    'body.refreshToken', 'body.otp', 'body.email', 'body.phone',
    'body.aadhaar', 'body.cardNumber', 'body.cvv',
    '*.password', '*.token', '*.otp', '*.email', '*.phone', '*.aadhaar',
    ...extraPaths,
  ];

  const log = pino({ level: 'trace', redact: { paths: REDACT_PATHS, censor: '[REDACTED]' } }, stream);
  return { log, getLines: () => lines, getOutput: () => lines.join('\n') };
}

test('Pino redacts body.password', () => {
  const { log, getOutput } = makeCaptureLogger();
  log.info({ body: { password: 'MySuperSecret123!' } }, 'Login');
  notContains(getOutput(), 'MySuperSecret123!', 'Password must not appear in logs');
});

test('Pino redacts body.token', () => {
  const { log, getOutput } = makeCaptureLogger();
  log.info({ body: { token: 'eyJhbGciOiJIUzI1NiJ9.payload.sig' } }, 'Token');
  notContains(getOutput(), 'eyJhbGciOiJIUzI1NiJ9', 'JWT must not appear in logs');
});

test('Pino redacts body.email', () => {
  const { log, getOutput } = makeCaptureLogger();
  log.info({ body: { email: 'parent@family.com' } }, 'User');
  notContains(getOutput(), 'parent@family.com', 'Email must not appear in logs');
});

test('Pino redacts body.phone', () => {
  const { log, getOutput } = makeCaptureLogger();
  log.info({ body: { phone: '9876543210' } }, 'Phone');
  notContains(getOutput(), '9876543210', 'Phone must not appear in logs');
});

test('Pino redacts body.aadhaar', () => {
  const { log, getOutput } = makeCaptureLogger();
  log.info({ body: { aadhaar: '123412341234' } }, 'Aadhaar');
  notContains(getOutput(), '123412341234', 'Aadhaar must not appear in logs');
});

test('Pino redacts wildcard *.password (nested objects)', () => {
  const { log, getOutput } = makeCaptureLogger();
  log.info({ user: { password: 'NestedSecret99!' } }, 'Nested');
  notContains(getOutput(), 'NestedSecret99!', 'Nested password must not appear in logs');
});

test('Pino redacts body.cardNumber', () => {
  const { log, getOutput } = makeCaptureLogger();
  log.info({ body: { cardNumber: '4111111111111111' } }, 'Payment');
  notContains(getOutput(), '4111111111111111', 'Card number must not appear in logs');
});

test('Pino: non-sensitive fields are logged normally', () => {
  const { log, getOutput } = makeCaptureLogger();
  log.info({ userId: '6641a3f000000000000000ab', role: 'teacher', statusCode: 200 }, 'OK');
  const out = getOutput();
  ok(out.includes('6641a3f000000000000000ab'), 'userId should appear in log');
  ok(out.includes('teacher'), 'role should appear in log');
});

test('Pino: [REDACTED] appears in place of censored fields', () => {
  const { log, getOutput } = makeCaptureLogger();
  log.info({ body: { password: 'secret' } }, 'Check');
  ok(getOutput().includes('[REDACTED]'), 'Should see [REDACTED] in log output');
});

// ─── 4. Compliance Assertions ────────────────────────────────────────────────

console.log('\n── 4. Compliance Assertions ─────────────────────────────────');

const KNOWN_PII = [
  'jane.doe@school.com',
  '9876543210',
  '123412341234',              // Aadhaar
  'MySuperSecretPassword1!',
  'eyJhbGciOiJIUzI1NiJ9',    // JWT fragment
  '4111111111111111',         // Card number
];

KNOWN_PII.forEach((pii) => {
  test(`Compliance: "${pii.slice(0, 20)}..." never appears in log output`, () => {
    const { log, getOutput } = makeCaptureLogger();

    // Attempt to log PII in every possible way
    log.info({ body: { password: pii, token: pii, email: pii, phone: pii, aadhaar: pii, cardNumber: pii } }, 'PII test 1');
    log.warn({ user: { password: pii } }, 'PII test 2');
    log.error({ password: pii, token: pii }, 'PII test 3');

    notContains(getOutput(), pii, `PII "${pii.slice(0, 20)}..." must not appear in logs`);
  });
});

// ─── Summary ──────────────────────────────────────────────────────────────────

console.log('\n─────────────────────────────────────────────────────────────');
console.log(`  Tests passed: ${passed}`);
console.log(`  Tests failed: ${failed}`);
console.log('─────────────────────────────────────────────────────────────\n');

if (failed > 0) {
  process.exit(1);
}
