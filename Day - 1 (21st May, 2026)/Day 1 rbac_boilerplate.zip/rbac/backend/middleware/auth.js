/**
 * ============================================================
 *  backend/middleware/auth.js
 *  1. authenticate  — verify JWT, attach user to req
 *  2. authorize     — check role has permission on module
 *  3. scopeToSchool — auto-filter queries to user's school
 *  4. scopeToSelf   — enforce object-level ownership (IDOR)
 * ============================================================
 */

const jwt     = require('jsonwebtoken');
const User    = require('../models/User');
const { ROLES, MODULE_PERMISSIONS, can } = require('../config/roles');

const JWT_SECRET = process.env.JWT_SECRET;

// ── Utility: structured error response ───────────────────────
const deny = (res, status, code, message) =>
  res.status(status).json({ success: false, code, message });

// ── Log access denial to DB (fire-and-forget) ────────────────
const logDenial = (userId, endpoint, reason) => {
  // Import inline to avoid circular deps
  const AuditLog = require('../models/AuditLog');
  AuditLog.create({ userId, endpoint, result: 'denied', reason, ts: new Date() })
    .catch(() => {}); // never crash the request over a log failure
};

// ============================================================
//  1. AUTHENTICATE — must run before any authorize/scope check
// ============================================================
const authenticate = async (req, res, next) => {
  try {
    // Accept token from HttpOnly cookie (preferred) or Authorization header
    const token =
      req.cookies?.token ||
      (req.headers.authorization?.startsWith('Bearer ')
        ? req.headers.authorization.split(' ')[1]
        : null);

    if (!token) return deny(res, 401, 'NO_TOKEN', 'Authentication required.');

    // 1a. Verify signature and expiry
    let payload;
    try {
      payload = jwt.verify(token, JWT_SECRET);
    } catch (err) {
      const msg = err.name === 'TokenExpiredError' ? 'Token expired.' : 'Invalid token.';
      return deny(res, 401, 'INVALID_TOKEN', msg);
    }

    // 1b. Load user from DB (also confirms user still exists)
    const user = await User.findById(payload.userId).select('+tokenVersion');
    if (!user || !user.isActive) {
      return deny(res, 401, 'USER_NOT_FOUND', 'Account not found or deactivated.');
    }

    // 1c. Token version check — catches role changes & forced logouts
    if (payload.tokenVersion !== user.tokenVersion) {
      return deny(res, 401, 'TOKEN_INVALIDATED', 'Session expired. Please log in again.');
    }

    // Attach to request for downstream middleware/controllers
    req.user = {
      id:           user._id.toString(),
      role:         user.role,
      schoolId:     user.schoolId?.toString(),
      tokenVersion: user.tokenVersion,
      // Role-specific scoping data
      childIds:              user.childIds,
      assignedClassIds:      user.assignedClassIds,
      assignedHostelBlockIds: user.assignedHostelBlockIds,
      assignedCaseIds:       user.assignedCaseIds,
      assignedExamIds:       user.assignedExamIds,
    };

    next();
  } catch (err) {
    console.error('[authenticate]', err);
    deny(res, 500, 'AUTH_ERROR', 'Authentication failed.');
  }
};

// ============================================================
//  2. AUTHORIZE — role-based permission check per module+action
//  Usage: authorize('examinations', 'write')
// ============================================================
const authorize = (module, action = 'read') => (req, res, next) => {
  const { role } = req.user;

  if (!can(role, module, action)) {
    logDenial(req.user.id, req.originalUrl, `Role ${role} cannot ${action} on ${module}`);
    return deny(res, 403, 'FORBIDDEN',
      `Your role (${role}) does not have ${action} access to ${module}.`);
  }

  next();
};

// ============================================================
//  3. SCOPE TO SCHOOL — auto-appends schoolId filter
//  Attach to any route that should be school-scoped.
//  Controllers read from req.schoolFilter.
// ============================================================
const scopeToSchool = (req, res, next) => {
  if (req.user.role === ROLES.SUPER_ADMIN) {
    // Super admin can optionally pass ?schoolId= to target a specific school
    req.schoolFilter = req.query.schoolId ? { schoolId: req.query.schoolId } : {};
  } else {
    if (!req.user.schoolId) {
      return deny(res, 403, 'NO_SCHOOL', 'User is not associated with a school.');
    }
    req.schoolFilter = { schoolId: req.user.schoolId };
  }
  next();
};

// ============================================================
//  4. SCOPE TO SELF — object-level ownership checks (IDOR)
//  Pass a resolver fn that returns true if access is allowed.
//
//  Usage:
//    router.get('/students/:id', authenticate, scopeToSelf(async (req) => {
//      if (req.user.role === ROLES.STUDENT)
//        return req.user.id === req.params.id;
//      if (req.user.role === ROLES.PARENT)
//        return req.user.childIds.map(String).includes(req.params.id);
//      return true; // teacher/admin — school scope handled separately
//    }))
// ============================================================
const scopeToSelf = (resolverFn) => async (req, res, next) => {
  try {
    const allowed = await resolverFn(req);
    if (!allowed) {
      logDenial(req.user.id, req.originalUrl, 'Object-level ownership check failed (IDOR)');
      // Return 403 NOT 404 — prevents resource enumeration
      return deny(res, 403, 'FORBIDDEN', 'You do not have access to this resource.');
    }
    next();
  } catch (err) {
    console.error('[scopeToSelf]', err);
    deny(res, 500, 'SCOPE_ERROR', 'Authorization check failed.');
  }
};

// ============================================================
//  5. ROLE-SPECIFIC SCOPE MIDDLEWARE (pre-built for new roles)
// ============================================================

// Hostel Warden — can only access their assigned hostel blocks
const scopeHostelWarden = (req, _res, next) => {
  if (req.user.role === ROLES.HOSTEL_WARDEN) {
    req.hostelFilter = {
      ...req.schoolFilter,
      _id: { $in: req.user.assignedHostelBlockIds },
    };
  } else {
    req.hostelFilter = { ...req.schoolFilter };
  }
  next();
};

// Exam Admin — can only manage their assigned exam series
const scopeExamAdmin = (req, _res, next) => {
  if (req.user.role === ROLES.EXAM_ADMIN) {
    req.examFilter = {
      ...req.schoolFilter,
      _id: { $in: req.user.assignedExamIds },
    };
  } else {
    req.examFilter = { ...req.schoolFilter };
  }
  next();
};

// Teacher — can only see their assigned classes
const scopeTeacher = (req, _res, next) => {
  if ([ROLES.TEACHER, ROLES.COORDINATOR].includes(req.user.role)) {
    req.classFilter = {
      ...req.schoolFilter,
      _id: { $in: req.user.assignedClassIds },
    };
  } else {
    req.classFilter = { ...req.schoolFilter };
  }
  next();
};

// ============================================================
//  JWT SIGNING HELPER  (used in auth controller)
// ============================================================
const signToken = (user) =>
  jwt.sign(
    {
      userId:       user._id,
      role:         user.role,
      schoolId:     user.schoolId,
      tokenVersion: user.tokenVersion,
    },
    JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
  );

module.exports = {
  authenticate,
  authorize,
  scopeToSchool,
  scopeToSelf,
  scopeHostelWarden,
  scopeExamAdmin,
  scopeTeacher,
  signToken,
};
