/**
 * ============================================================
 *  backend/models/User.js
 *  MongoDB/Mongoose User model — supports all roles
 * ============================================================
 */

const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');
const { ROLES } = require('../config/roles');

const UserSchema = new mongoose.Schema(
  {
    // ── Core identity ────────────────────────────────────────
    name:  { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, select: false }, // never returned by default

    // ── RBAC fields ──────────────────────────────────────────
    role: {
      type: String,
      enum: Object.values(ROLES),
      required: true,
      index: true,
    },

    // Multi-tenancy: every user belongs to a school (except super_admin)
    schoolId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'School',
      index: true,
      required: function () { return this.role !== ROLES.SUPER_ADMIN; },
    },

    // Token versioning — increment to invalidate all existing JWTs for this user
    // (e.g. on role change, password reset, forced logout)
    tokenVersion: { type: Number, default: 0 },

    isActive: { type: Boolean, default: true },

    // ── Role-specific scoping ────────────────────────────────
    // Teacher / Coordinator: which classes they're assigned to
    assignedClassIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Class' }],

    // Parent: which students are their children
    childIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Student' }],

    // Hostel Warden: which hostel block they manage
    assignedHostelBlockIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'HostelBlock' }],

    // Counsellor: assigned counselling cases
    assignedCaseIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'CounsellingCase' }],

    // Exam Admin: which exam series they manage
    assignedExamIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Exam' }],

    // Sales/Admission: assigned lead pipeline stage or branch
    assignedBranchId: { type: mongoose.Schema.Types.ObjectId, ref: 'Branch' },

    // Profile
    phone:     { type: String },
    avatarUrl: { type: String },

    // Audit
    lastLogin: { type: Date },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,   // createdAt, updatedAt
    toJSON: {
      transform(doc, ret) {
        delete ret.password;
        delete ret.tokenVersion;
        return ret;
      }
    }
  }
);

// ── Indexes ──────────────────────────────────────────────────
UserSchema.index({ schoolId: 1, role: 1 });
UserSchema.index({ email: 1, schoolId: 1 });

// ── Hash password before save ────────────────────────────────
UserSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

// ── Compare password ─────────────────────────────────────────
UserSchema.methods.comparePassword = function (candidate) {
  return bcrypt.compare(candidate, this.password);
};

// ── Invalidate all tokens (role change / forced logout) ──────
UserSchema.methods.invalidateTokens = function () {
  this.tokenVersion += 1;
  return this.save();
};

module.exports = mongoose.model('User', UserSchema);
