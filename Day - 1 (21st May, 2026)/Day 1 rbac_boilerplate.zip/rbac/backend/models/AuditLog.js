/**
 * backend/models/AuditLog.js
 */
const mongoose = require('mongoose');

const AuditLogSchema = new mongoose.Schema({
  userId:   { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true },
  endpoint: { type: String },
  action:   { type: String },
  result:   { type: String, enum: ['allowed', 'denied'] },
  reason:   { type: String },
  ip:       { type: String },
  ts:       { type: Date, default: Date.now, index: true },
});

// Auto-delete logs older than 90 days
AuditLogSchema.index({ ts: 1 }, { expireAfterSeconds: 60 * 60 * 24 * 90 });

module.exports = mongoose.model('AuditLog', AuditLogSchema);
