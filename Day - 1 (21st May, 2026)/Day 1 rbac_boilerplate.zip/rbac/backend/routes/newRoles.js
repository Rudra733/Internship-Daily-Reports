/**
 * ============================================================
 *  backend/routes/newRoles.js
 *  Route examples for all 5 new roles:
 *    - Hostel Warden
 *    - Sales / Admissions
 *    - Marketing
 *    - Exam Admin
 *  (Transport is a separate service — stub provided at bottom)
 * ============================================================
 */

const express    = require('express');
const router     = express.Router();
const {
  authenticate, authorize, scopeToSchool,
  scopeHostelWarden, scopeExamAdmin, scopeToSelf,
} = require('../middleware/auth');
const { ROLES } = require('../config/roles');

// ── Apply authenticate + scopeToSchool to ALL routes below ──
router.use(authenticate, scopeToSchool);


// ============================================================
//  HOSTEL MODULE  /api/hostel
// ============================================================

// GET  /api/hostel/blocks  — list hostel blocks (warden sees only theirs)
router.get('/hostel/blocks', authorize('hostel', 'read'), scopeHostelWarden,
  async (req, res) => {
    const HostelBlock = require('../models/HostelBlock');
    const blocks = await HostelBlock.find(req.hostelFilter);
    res.json({ success: true, data: blocks });
  }
);

// POST /api/hostel/blocks  — create a block (school admin only)
router.post('/hostel/blocks', authorize('hostel', 'write'),
  async (req, res) => {
    const HostelBlock = require('../models/HostelBlock');
    const block = await HostelBlock.create({ ...req.body, ...req.schoolFilter });
    res.status(201).json({ success: true, data: block });
  }
);

// GET  /api/hostel/students  — students in warden's block(s)
router.get('/hostel/students', authorize('hostel', 'read'), scopeHostelWarden,
  async (req, res) => {
    const HostelStudent = require('../models/HostelStudent');
    const students = await HostelStudent.find(req.hostelFilter).populate('studentId');
    res.json({ success: true, data: students });
  }
);

// GET  /api/hostel/students/:id  — single student (parent sees own child only)
router.get('/hostel/students/:id',
  authorize('hostel', 'read'),
  scopeToSelf(async (req) => {
    if (req.user.role === ROLES.STUDENT) return req.user.id === req.params.id;
    if (req.user.role === ROLES.PARENT)
      return req.user.childIds.map(String).includes(req.params.id);
    return true;
  }),
  async (req, res) => {
    const HostelStudent = require('../models/HostelStudent');
    const s = await HostelStudent.findOne({ studentId: req.params.id, ...req.schoolFilter });
    if (!s) return res.status(404).json({ success: false, message: 'Not found.' });
    res.json({ success: true, data: s });
  }
);

// PATCH /api/hostel/students/:id  — update room allotment
router.patch('/hostel/students/:id', authorize('hostel', 'write'),
  async (req, res) => {
    const HostelStudent = require('../models/HostelStudent');
    const s = await HostelStudent.findOneAndUpdate(
      { studentId: req.params.id, ...req.schoolFilter },
      req.body,
      { new: true }
    );
    if (!s) return res.status(404).json({ success: false, message: 'Not found.' });
    res.json({ success: true, data: s });
  }
);


// ============================================================
//  ADMISSIONS MODULE  /api/admissions
// ============================================================

// GET  /api/admissions/enquiries
router.get('/admissions/enquiries', authorize('admissions', 'read'),
  async (req, res) => {
    const Enquiry = require('../models/Enquiry');
    // Sales staff see all enquiries in their school
    const enquiries = await Enquiry.find(req.schoolFilter).sort({ createdAt: -1 });
    res.json({ success: true, data: enquiries });
  }
);

// POST /api/admissions/enquiries  — log new lead
router.post('/admissions/enquiries', authorize('admissions', 'write'),
  async (req, res) => {
    const Enquiry = require('../models/Enquiry');
    const enquiry = await Enquiry.create({
      ...req.body,
      ...req.schoolFilter,
      createdBy: req.user.id,
      stage: 'new',
    });
    res.status(201).json({ success: true, data: enquiry });
  }
);

// PATCH /api/admissions/enquiries/:id  — update lead stage
router.patch('/admissions/enquiries/:id', authorize('admissions', 'write'),
  async (req, res) => {
    const Enquiry = require('../models/Enquiry');
    const enquiry = await Enquiry.findOneAndUpdate(
      { _id: req.params.id, ...req.schoolFilter },
      req.body,
      { new: true }
    );
    if (!enquiry) return res.status(404).json({ success: false, message: 'Not found.' });
    res.json({ success: true, data: enquiry });
  }
);

// POST /api/admissions/enroll  — convert lead to student
router.post('/admissions/enroll', authorize('admissions', 'write'),
  async (req, res) => {
    const Enquiry = require('../models/Enquiry');
    const Student = require('../models/Student');
    const { enquiryId, ...studentData } = req.body;

    const enquiry = await Enquiry.findOneAndUpdate(
      { _id: enquiryId, ...req.schoolFilter },
      { stage: 'enrolled' },
      { new: true }
    );
    if (!enquiry) return res.status(404).json({ success: false, message: 'Enquiry not found.' });

    const student = await Student.create({ ...studentData, ...req.schoolFilter });
    res.status(201).json({ success: true, data: student });
  }
);


// ============================================================
//  MARKETING MODULE  /api/marketing
// ============================================================

// GET  /api/marketing/campaigns
router.get('/marketing/campaigns', authorize('marketing', 'read'),
  async (req, res) => {
    const Campaign = require('../models/Campaign');
    const campaigns = await Campaign.find(req.schoolFilter);
    res.json({ success: true, data: campaigns });
  }
);

// POST /api/marketing/campaigns
router.post('/marketing/campaigns', authorize('marketing', 'write'),
  async (req, res) => {
    const Campaign = require('../models/Campaign');
    const campaign = await Campaign.create({
      ...req.body,
      ...req.schoolFilter,
      createdBy: req.user.id,
    });
    res.status(201).json({ success: true, data: campaign });
  }
);

// GET  /api/marketing/analytics  — read-only funnel/campaign stats
router.get('/marketing/analytics', authorize('analytics', 'read'),
  async (req, res) => {
    const Campaign = require('../models/Campaign');
    const Enquiry  = require('../models/Enquiry');

    const [campaigns, leads] = await Promise.all([
      Campaign.countDocuments(req.schoolFilter),
      Enquiry.aggregate([
        { $match: req.schoolFilter },
        { $group: { _id: '$stage', count: { $sum: 1 } } },
      ]),
    ]);
    res.json({ success: true, data: { campaigns, leadsByStage: leads } });
  }
);


// ============================================================
//  EXAMINATIONS MODULE  /api/examinations
// ============================================================

// GET  /api/examinations  — list exams (students/parents see published only)
router.get('/examinations', authorize('examinations', 'read'), scopeExamAdmin,
  async (req, res) => {
    const Exam = require('../models/Exam');
    const isLimitedRole = [ROLES.STUDENT, ROLES.PARENT].includes(req.user.role);
    const filter = {
      ...req.examFilter,
      ...(isLimitedRole ? { status: 'published' } : {}),
    };
    const exams = await Exam.find(filter);
    res.json({ success: true, data: exams });
  }
);

// POST /api/examinations  — create exam (exam_admin + school_admin only)
router.post('/examinations', authorize('examinations', 'write'),
  async (req, res) => {
    const Exam = require('../models/Exam');
    const exam = await Exam.create({
      ...req.body,
      ...req.schoolFilter,
      createdBy: req.user.id,
      status: 'draft',
    });
    res.status(201).json({ success: true, data: exam });
  }
);

// PATCH /api/examinations/:id/publish  — publish exam
router.patch('/examinations/:id/publish', authorize('examinations', 'write'), scopeExamAdmin,
  async (req, res) => {
    const Exam = require('../models/Exam');
    const exam = await Exam.findOneAndUpdate(
      { _id: req.params.id, ...req.examFilter },
      { status: 'published' },
      { new: true }
    );
    if (!exam) return res.status(404).json({ success: false, message: 'Exam not found.' });
    res.json({ success: true, data: exam });
  }
);

// POST /api/examinations/:id/results  — enter results
router.post('/examinations/:id/results', authorize('examinations', 'write'),
  async (req, res) => {
    const ExamResult = require('../models/ExamResult');
    const results = await ExamResult.insertMany(
      req.body.results.map(r => ({
        ...r,
        examId: req.params.id,
        ...req.schoolFilter,
        enteredBy: req.user.id,
      }))
    );
    res.status(201).json({ success: true, data: results });
  }
);

// GET  /api/examinations/:examId/results/:studentId  — student sees own results only
router.get('/examinations/:examId/results/:studentId',
  authorize('examinations', 'read'),
  scopeToSelf(async (req) => {
    if (req.user.role === ROLES.STUDENT) return req.user.id === req.params.studentId;
    if (req.user.role === ROLES.PARENT)
      return req.user.childIds.map(String).includes(req.params.studentId);
    return true;
  }),
  async (req, res) => {
    const ExamResult = require('../models/ExamResult');
    const result = await ExamResult.findOne({
      examId: req.params.examId,
      studentId: req.params.studentId,
      ...req.schoolFilter,
    });
    if (!result) return res.status(404).json({ success: false, message: 'Result not found.' });
    res.json({ success: true, data: result });
  }
);


// ============================================================
//  TRANSPORT — separate microservice stub
//  Register this in your API gateway / reverse-proxy.
//  The transport service validates the JWT itself and checks
//  req.user.role against its own TRANSPORT_ROLES allowlist.
// ============================================================
/*
  TRANSPORT SERVICE  (separate Node/Express app on e.g. port 4001)
  ─────────────────────────────────────────────────────────────
  Allowed roles:  school_admin, principal, transport_manager (future role)
  Students/parents: read-only (view own bus route & ETA)

  Endpoints (examples):
    GET  /api/transport/routes
    POST /api/transport/routes
    GET  /api/transport/routes/:id/students
    GET  /api/transport/track/:vehicleId      ← GPS live feed
    GET  /api/transport/students/:id/route    ← student/parent: own route only

  Auth: forward the same JWT; transport service calls shared verifyToken()
  from a shared npm package or copies backend/middleware/auth.js.
*/

module.exports = router;
