/**
 * ============================================================
 *  backend/scripts/seedRoles.js
 *  Run once: node backend/scripts/seedRoles.js
 *  Creates one test user per role in your MongoDB.
 * ============================================================
 */

require('dotenv').config();
const mongoose = require('mongoose');
const User     = require('../models/User');
const { ROLES } = require('../config/roles');

const SCHOOL_ID = new mongoose.Types.ObjectId(); // replace with a real school _id

const SEED_USERS = [
  { name: 'Super Admin',       email: 'superadmin@school.com',   role: ROLES.SUPER_ADMIN,      schoolId: null },
  { name: 'School Admin',      email: 'schooladmin@school.com',  role: ROLES.SCHOOL_ADMIN,     schoolId: SCHOOL_ID },
  { name: 'Principal',         email: 'principal@school.com',    role: ROLES.PRINCIPAL,        schoolId: SCHOOL_ID },
  { name: 'Teacher One',       email: 'teacher@school.com',      role: ROLES.TEACHER,          schoolId: SCHOOL_ID },
  { name: 'Coordinator One',   email: 'coord@school.com',        role: ROLES.COORDINATOR,      schoolId: SCHOOL_ID },
  { name: 'Counsellor',        email: 'counsellor@school.com',   role: ROLES.COUNSELLOR,       schoolId: SCHOOL_ID },
  { name: 'Accountant',        email: 'accountant@school.com',   role: ROLES.ACCOUNTANT,       schoolId: SCHOOL_ID },
  { name: 'Librarian',         email: 'librarian@school.com',    role: ROLES.LIBRARIAN,        schoolId: SCHOOL_ID },
  { name: 'Sports Coach',      email: 'sports@school.com',       role: ROLES.SPORTS,           schoolId: SCHOOL_ID },
  { name: 'Activities Head',   email: 'extra@school.com',        role: ROLES.EXTRA_CURRICULAR, schoolId: SCHOOL_ID },
  { name: 'Analytics User',    email: 'analytics@school.com',    role: ROLES.ANALYTICS,        schoolId: SCHOOL_ID },
  // ── NEW ROLES ──────────────────────────────────────────────
  { name: 'Hostel Warden',     email: 'warden@school.com',       role: ROLES.HOSTEL_WARDEN,    schoolId: SCHOOL_ID },
  { name: 'Admissions Officer',email: 'admissions@school.com',   role: ROLES.SALES_ADMISSION,  schoolId: SCHOOL_ID },
  { name: 'Marketing Manager', email: 'marketing@school.com',    role: ROLES.MARKETING,        schoolId: SCHOOL_ID },
  { name: 'Exam Controller',   email: 'examadmin@school.com',    role: ROLES.EXAM_ADMIN,       schoolId: SCHOOL_ID },
  // ── PORTAL USERS ───────────────────────────────────────────
  { name: 'Parent User',       email: 'parent@school.com',       role: ROLES.PARENT,           schoolId: SCHOOL_ID },
  { name: 'Student User',      email: 'student@school.com',      role: ROLES.STUDENT,          schoolId: SCHOOL_ID },
];

const DEFAULT_PASSWORD = 'Test@1234'; // change immediately after seeding

async function seed() {
  await mongoose.connect(process.env.MONGODB_URI);
  console.log('Connected to MongoDB');

  for (const userData of SEED_USERS) {
    const existing = await User.findOne({ email: userData.email });
    if (existing) {
      console.log(`  skip  ${userData.email} (already exists)`);
      continue;
    }
    await User.create({ ...userData, password: DEFAULT_PASSWORD });
    console.log(`  created  ${userData.role.padEnd(20)} → ${userData.email}`);
  }

  console.log('\nSeeding complete. Change all passwords before going to production!');
  await mongoose.disconnect();
}

seed().catch(err => { console.error(err); process.exit(1); });
