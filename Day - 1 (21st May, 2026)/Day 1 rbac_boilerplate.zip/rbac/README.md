# RBAC Implementation Guide
## New Roles: Hostel Warden · Sales/Admissions · Marketing · Exam Admin
## Stack: Next.js (Pages Router) + Express.js + MongoDB + JWT

---

## File Structure

```
shared/
  roles.js                    ← SINGLE SOURCE OF TRUTH — copy to both projects

backend/
  config/
    roles.js                  ← copy of shared/roles.js
  models/
    User.js                   ← Mongoose User model (all roles)
    AuditLog.js               ← Access denial logging
  middleware/
    auth.js                   ← authenticate · authorize · scopeToSchool · scopeToSelf
  routes/
    newRoles.js               ← All API routes for 5 new roles
  scripts/
    seedRoles.js              ← Seed one test user per role

frontend/
  lib/
    roles.js                  ← copy of shared/roles.js
  hooks/
    useAuth.js                ← useAuth() hook + AuthProvider
  components/auth/
    withAuth.js               ← withAuth() HOC + <PermissionGate>
  pages/dashboard/
    hostel.js                 ← Example page (Hostel Warden)
    admissions.js             ← Example page (Sales/Admissions)
    marketing.js              ← Example page (Marketing)
    examinations.js           ← Example page (Exam Admin)
```

---

## Step 1 — Shared Roles Config

Copy `shared/roles.js` to:
- `backend/config/roles.js`
- `frontend/lib/roles.js`

This is the **single source of truth** for all roles, module permissions,
route permissions, and role home pages. Change it in one place.

---

## Step 2 — Backend Setup

### 2a. Install dependencies
```bash
cd backend
npm install jsonwebtoken bcryptjs mongoose cookie-parser dotenv
```

### 2b. Environment variables (.env)
```env
MONGODB_URI=mongodb://localhost:27017/schooldb
JWT_SECRET=your-very-long-random-secret-min-32-chars
JWT_EXPIRES_IN=8h
PORT=4000
```

### 2c. Register middleware in Express app
```js
// backend/app.js
const express    = require('express');
const cookieParser = require('cookie-parser');
const newRolesRouter = require('./routes/newRoles');

const app = express();
app.use(express.json());
app.use(cookieParser());
app.use('/api', newRolesRouter);
```

### 2d. User model
The `User.js` model includes these new fields for the 5 new roles:
- `assignedHostelBlockIds` — Hostel Warden: which blocks they manage
- `assignedExamIds`        — Exam Admin: which exam series they manage
- `assignedBranchId`       — Sales/Admissions: which branch they belong to
- `tokenVersion`           — increment to invalidate JWTs on role change

### 2e. Seed test users
```bash
node backend/scripts/seedRoles.js
```
Creates one user per role with password `Test@1234`.
**Change all passwords before production.**

---

## Step 3 — Frontend Setup

### 3a. Wrap _app.js with AuthProvider
```jsx
// pages/_app.js
import { AuthProvider } from '../hooks/useAuth';

export default function App({ Component, pageProps }) {
  return (
    <AuthProvider>
      <Component {...pageProps} />
    </AuthProvider>
  );
}
```

### 3b. Protect a page with withAuth
```jsx
// pages/dashboard/examinations.js
import { withAuth } from '../../components/auth/withAuth';

function ExaminationsPage() {
  return <div>Examinations Dashboard</div>;
}

export default withAuth(ExaminationsPage, {
  allowedRoles: ['exam_admin', 'school_admin', 'principal', 'super_admin'],
});
```

### 3c. Show/hide UI elements with PermissionGate
```jsx
import { PermissionGate } from '../../components/auth/withAuth';

// By module permission:
<PermissionGate module="examinations" action="write">
  <button>Publish Exam</button>
</PermissionGate>

// By role:
<PermissionGate roles={['school_admin', 'super_admin']}>
  <button>Delete School</button>
</PermissionGate>
```

### 3d. Use the useAuth hook in any component
```jsx
const { user, role, is, can, logout } = useAuth();

if (can('hostel', 'write')) { /* show edit button */ }
if (is('marketing'))        { /* show campaign tools */ }
```

---

## Step 4 — How Each New Role Works

### Hostel Warden
- Assigned `assignedHostelBlockIds[]` in their User document
- `scopeHostelWarden` middleware filters all hostel queries to their blocks
- Cannot see academic grades, fees, or other modules
- Parents/students can view their own hostel info (IDOR check via `scopeToSelf`)

### Sales / Admissions
- Full access to the `admissions` module (enquiries, leads, enrollment)
- Can read `analytics` (to track conversion rates)
- Can create Student records when enrolling a lead
- Cannot access academic data, financials, or hostel

### Marketing
- Full access to `marketing` module (campaigns, content)
- Read-only access to `analytics` (funnel/campaign stats)
- Cannot access student data, fees, or academic records

### Exam Admin
- Assigned `assignedExamIds[]` in their User document
- `scopeExamAdmin` middleware filters exam queries to their series
- Can create, edit, publish exams and enter results
- Students/parents see only published exams, own results only (IDOR)
- Cannot access fee, hostel, or marketing modules

### Transport (separate service)
- Runs as a separate Express service (e.g. port 4001)
- Validates the same JWT (shared JWT_SECRET)
- Roles: `school_admin`, `principal`, future `transport_manager`
- Students/parents: read-only own bus route + GPS ETA
- No access to any other school data

---

## Step 5 — Security Checklist

- [ ] `JWT_SECRET` is at least 32 random characters, stored in `.env`
- [ ] JWT stored in `HttpOnly; Secure; SameSite=Strict` cookie (not localStorage)
- [ ] `tokenVersion` incremented whenever a user's role changes
- [ ] All API routes go through `authenticate` then `authorize`
- [ ] `scopeToSchool` applied on every data-fetching route
- [ ] `scopeToSelf` applied on all single-resource endpoints
- [ ] `AuditLog` recording all 401/403 events
- [ ] `withAuth` HOC applied on every protected Next.js page
- [ ] `PermissionGate` used to hide write actions from read-only roles
- [ ] Seed passwords changed before production

---

## Transport Service — Quick Start

```bash
mkdir transport-service && cd transport-service
npm init -y
npm install express jsonwebtoken mongoose cookie-parser dotenv

# Copy backend/config/roles.js and backend/middleware/auth.js
# Create your routes with:
#   authenticate → authorize(['school_admin','principal','transport_manager'], ...)
#   scopeToSelf for student/parent bus route queries
```
