/**
 * ============================================================
 *  frontend/hooks/useAuth.js
 *  Central auth hook — provides user, role helpers, and
 *  permission checks throughout the Next.js app
 * ============================================================
 */

import { useContext, createContext, useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/router';
import { ROLES, ROLE_HOME, can, ROUTE_PERMISSIONS } from '../lib/roles';

// ── Context ───────────────────────────────────────────────────
const AuthContext = createContext(null);

// ── Provider (wrap _app.js with this) ───────────────────────
export function AuthProvider({ children }) {
  const [user, setUser]       = useState(null);   // { id, name, role, schoolId, ... }
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  // Fetch current user from /api/auth/me on mount
  useEffect(() => {
    fetch('/api/auth/me', { credentials: 'include' })
      .then(r => r.ok ? r.json() : null)
      .then(data => { setUser(data?.user ?? null); setLoading(false); })
      .catch(() => { setUser(null); setLoading(false); });
  }, []);

  const login = useCallback(async (email, password) => {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Login failed');
    setUser(data.user);
    // Redirect to role home page
    router.push(ROLE_HOME[data.user.role] || '/dashboard');
  }, [router]);

  const logout = useCallback(async () => {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
    setUser(null);
    router.push('/login');
  }, [router]);

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

// ── Main hook ────────────────────────────────────────────────
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  const { user, loading, login, logout } = ctx;

  return {
    user,
    loading,
    login,
    logout,
    isAuthenticated: !!user,

    // Role checks
    role: user?.role,
    is: (roleOrRoles) => {
      if (!user) return false;
      const roles = Array.isArray(roleOrRoles) ? roleOrRoles : [roleOrRoles];
      return roles.includes(user.role);
    },

    // Permission check (mirrors backend can())
    can: (module, action = 'read') => {
      if (!user) return false;
      return can(user.role, module, action);
    },

    // Is this user a super admin?
    isSuperAdmin: user?.role === ROLES.SUPER_ADMIN,
  };
}

export { ROLES };
