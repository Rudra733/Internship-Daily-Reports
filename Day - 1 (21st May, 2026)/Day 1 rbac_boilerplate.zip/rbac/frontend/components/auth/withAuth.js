/**
 * ============================================================
 *  frontend/components/auth/withAuth.js
 *  Higher-Order Component — wraps any page/component
 *  to enforce role-based access on the frontend
 *
 *  Usage:
 *    export default withAuth(MyPage, {
 *      allowedRoles: ['exam_admin', 'school_admin'],
 *    });
 *
 *    // or use the module-based check:
 *    export default withAuth(MyPage, {
 *      module: 'examinations',
 *      action: 'write',
 *    });
 * ============================================================
 */

import { useEffect } from 'react';
import { useRouter } from 'next/router';
import { useAuth } from '../../hooks/useAuth';

export function withAuth(WrappedComponent, options = {}) {
  const { allowedRoles = [], module, action = 'read', redirectTo = '/unauthorized' } = options;

  function ProtectedPage(props) {
    const { user, loading, isAuthenticated, can, is } = useAuth();
    const router = useRouter();

    useEffect(() => {
      if (loading) return;

      if (!isAuthenticated) {
        router.replace(`/login?returnTo=${encodeURIComponent(router.asPath)}`);
        return;
      }

      // Check by explicit role list
      if (allowedRoles.length > 0 && !is(allowedRoles)) {
        router.replace(redirectTo);
        return;
      }

      // Check by module permission
      if (module && !can(module, action)) {
        router.replace(redirectTo);
      }
    }, [loading, isAuthenticated, user]);

    if (loading) return <LoadingScreen />;
    if (!isAuthenticated) return null;
    if (allowedRoles.length > 0 && !is(allowedRoles)) return null;
    if (module && !can(module, action)) return null;

    return <WrappedComponent {...props} />;
  }

  ProtectedPage.displayName = `withAuth(${WrappedComponent.displayName || WrappedComponent.name})`;
  return ProtectedPage;
}

// ── PermissionGate — conditionally render UI elements ────────
/**
 * Usage:
 *   <PermissionGate module="examinations" action="write">
 *     <button>Publish Exam</button>
 *   </PermissionGate>
 *
 *   <PermissionGate roles={['school_admin', 'super_admin']}>
 *     <AdminMenu />
 *   </PermissionGate>
 */
export function PermissionGate({ children, module, action = 'read', roles = [], fallback = null }) {
  const { can, is } = useAuth();

  if (module && !can(module, action)) return fallback;
  if (roles.length > 0 && !is(roles)) return fallback;

  return children;
}

// ── Simple loading screen ─────────────────────────────────────
function LoadingScreen() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh' }}>
      <p style={{ color: '#666', fontSize: 16 }}>Loading...</p>
    </div>
  );
}
