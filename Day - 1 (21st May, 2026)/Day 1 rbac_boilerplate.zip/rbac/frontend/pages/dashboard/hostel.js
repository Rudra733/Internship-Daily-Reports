/**
 * ============================================================
 *  frontend/pages/dashboard/hostel.js
 * ============================================================
 */
import { withAuth, PermissionGate } from '../../components/auth/withAuth';
import { useAuth } from '../../hooks/useAuth';

function HostelDashboard() {
  const { user, can } = useAuth();
  return (
    <div>
      <h1>Hostel Dashboard</h1>
      <p>Welcome, {user?.name}</p>

      {/* All hostel roles can see rooms */}
      <section>
        <h2>Room Allotments</h2>
        {/* fetch from GET /api/hostel/students */}
      </section>

      {/* Only school_admin can create new blocks */}
      <PermissionGate roles={['school_admin', 'super_admin']}>
        <button>+ Add Hostel Block</button>
      </PermissionGate>
    </div>
  );
}

export default withAuth(HostelDashboard, {
  allowedRoles: ['hostel_warden', 'school_admin', 'principal', 'super_admin'],
});


/**
 * ============================================================
 *  frontend/pages/dashboard/admissions.js
 * ============================================================
 */
// import { withAuth, PermissionGate } from '../../components/auth/withAuth';
// import { useAuth } from '../../hooks/useAuth';
//
// function AdmissionsDashboard() {
//   return (
//     <div>
//       <h1>Admissions & Sales</h1>
//       <section>
//         <h2>Enquiry Pipeline</h2>
//         {/* fetch from GET /api/admissions/enquiries */}
//         {/* Kanban: New → Contacted → Visit Scheduled → Enrolled → Lost */}
//       </section>
//       <PermissionGate module="admissions" action="write">
//         <button>+ Log New Enquiry</button>
//         <button>Enroll Student</button>
//       </PermissionGate>
//     </div>
//   );
// }
// export default withAuth(AdmissionsDashboard, {
//   allowedRoles: ['sales_admission', 'school_admin', 'principal', 'super_admin'],
// });


/**
 * ============================================================
 *  frontend/pages/dashboard/marketing.js
 * ============================================================
 */
// function MarketingDashboard() {
//   return (
//     <div>
//       <h1>Marketing</h1>
//       <section>
//         <h2>Campaigns</h2>
//         {/* fetch from GET /api/marketing/campaigns */}
//       </section>
//       <section>
//         <h2>Lead Funnel Analytics</h2>
//         {/* fetch from GET /api/marketing/analytics */}
//       </section>
//       <PermissionGate module="marketing" action="write">
//         <button>+ New Campaign</button>
//       </PermissionGate>
//     </div>
//   );
// }
// export default withAuth(MarketingDashboard, {
//   allowedRoles: ['marketing', 'school_admin', 'super_admin'],
// });


/**
 * ============================================================
 *  frontend/pages/dashboard/examinations.js
 * ============================================================
 */
// function ExaminationsDashboard() {
//   const { can } = useAuth();
//   return (
//     <div>
//       <h1>Examinations</h1>
//
//       {/* Everyone with access sees published exams */}
//       <section><h2>Upcoming Exams</h2></section>
//
//       {/* Only exam_admin/school_admin can create or publish */}
//       <PermissionGate module="examinations" action="write">
//         <button>+ Create Exam</button>
//         <button>Enter Results</button>
//       </PermissionGate>
//     </div>
//   );
// }
// export default withAuth(ExaminationsDashboard, {
//   module: 'examinations',
//   action: 'read',
// });
