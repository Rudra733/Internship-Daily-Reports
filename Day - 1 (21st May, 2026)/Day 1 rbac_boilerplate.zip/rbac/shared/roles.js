/**
 * ============================================================
 *  CENTRAL ROLES & PERMISSIONS CONFIG
 *  shared/roles.js  — used by BOTH backend and frontend
 * ============================================================
 *  Copy this file into:
 *    - backend/config/roles.js
 *    - frontend/lib/roles.js
 *  (or publish as a shared internal package)
 * ============================================================
 */

// ── 1. ALL ROLES ────────────────────────────────────────────
const ROLES = {
  SUPER_ADMIN:      'super_admin',
  SCHOOL_ADMIN:     'school_admin',
  PRINCIPAL:        'principal',
  TEACHER:          'teacher',
  COORDINATOR:      'coordinator',
  COUNSELLOR:       'counsellor',
  ACCOUNTANT:       'accountant',
  LIBRARIAN:        'librarian',
  SPORTS:           'sports',
  EXTRA_CURRICULAR: 'extra_curricular',
  ANALYTICS:        'analytics',
  HOSTEL_WARDEN:    'hostel_warden',      // NEW
  SALES_ADMISSION:  'sales_admission',    // NEW
  MARKETING:        'marketing',          // NEW
  EXAM_ADMIN:       'exam_admin',         // NEW
  PARENT:           'parent',
  STUDENT:          'student',
};

// ── 2. MODULE → ALLOWED ROLES ────────────────────────────────
//  Format: { [module]: { read: [...roles], write: [...roles], delete: [...roles] } }
//  'super_admin' always has full access — enforced in middleware, not repeated here.

const MODULE_PERMISSIONS = {

  students: {
    read:   [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.TEACHER, ROLES.COORDINATOR,
             ROLES.COUNSELLOR, ROLES.ACCOUNTANT, ROLES.EXAM_ADMIN, ROLES.PARENT, ROLES.STUDENT],
    write:  [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.TEACHER, ROLES.COORDINATOR,
             ROLES.SALES_ADMISSION],
    delete: [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL],
  },

  parents: {
    read:   [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.TEACHER, ROLES.COORDINATOR, ROLES.PARENT],
    write:  [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.SALES_ADMISSION],
    delete: [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL],
  },

  coordinator: {
    read:   [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.COORDINATOR, ROLES.TEACHER],
    write:  [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.COORDINATOR],
    delete: [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL],
  },

  accountant: {
    read:   [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.ACCOUNTANT],
    write:  [ROLES.ACCOUNTANT],
    delete: [ROLES.SCHOOL_ADMIN],
  },

  librarian: {
    read:   [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.LIBRARIAN, ROLES.STUDENT],
    write:  [ROLES.LIBRARIAN],
    delete: [ROLES.SCHOOL_ADMIN, ROLES.LIBRARIAN],
  },

  sports: {
    read:   [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.SPORTS, ROLES.STUDENT],
    write:  [ROLES.SPORTS],
    delete: [ROLES.SCHOOL_ADMIN, ROLES.SPORTS],
  },

  extra_curricular: {
    read:   [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.EXTRA_CURRICULAR, ROLES.STUDENT],
    write:  [ROLES.EXTRA_CURRICULAR],
    delete: [ROLES.SCHOOL_ADMIN, ROLES.EXTRA_CURRICULAR],
  },

  analytics: {
    read:   [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.ANALYTICS, ROLES.MARKETING],
    write:  [],   // read-only for everyone
    delete: [],
  },

  management: {
    read:   [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.COUNSELLOR],
    write:  [ROLES.COUNSELLOR],
    delete: [ROLES.SCHOOL_ADMIN],
  },

  schools: {
    read:   [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL],
    write:  [ROLES.SCHOOL_ADMIN],
    delete: [ROLES.SCHOOL_ADMIN],
  },

  admin: {
    read:   [],   // super_admin only — handled in middleware
    write:  [],
    delete: [],
  },

  // ── NEW MODULES ─────────────────────────────────────────

  hostel: {
    read:   [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.HOSTEL_WARDEN, ROLES.PARENT, ROLES.STUDENT],
    write:  [ROLES.HOSTEL_WARDEN, ROLES.SCHOOL_ADMIN],
    delete: [ROLES.SCHOOL_ADMIN, ROLES.HOSTEL_WARDEN],
  },

  admissions: {
    read:   [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.SALES_ADMISSION, ROLES.MARKETING],
    write:  [ROLES.SALES_ADMISSION, ROLES.SCHOOL_ADMIN],
    delete: [ROLES.SCHOOL_ADMIN],
  },

  marketing: {
    read:   [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.MARKETING, ROLES.ANALYTICS],
    write:  [ROLES.MARKETING],
    delete: [ROLES.SCHOOL_ADMIN, ROLES.MARKETING],
  },

  examinations: {
    read:   [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL, ROLES.EXAM_ADMIN, ROLES.TEACHER,
             ROLES.COORDINATOR, ROLES.STUDENT, ROLES.PARENT],
    write:  [ROLES.EXAM_ADMIN, ROLES.SCHOOL_ADMIN],
    delete: [ROLES.SCHOOL_ADMIN, ROLES.EXAM_ADMIN],
  },
};

// ── 3. FRONTEND ROUTE → ALLOWED ROLES ───────────────────────
//  Used by Next.js middleware / route guards

const ROUTE_PERMISSIONS = {
  '/dashboard/admin':            [ROLES.SUPER_ADMIN],
  '/dashboard/school':           [ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL],
  '/dashboard/teacher':          [ROLES.TEACHER, ROLES.COORDINATOR],
  '/dashboard/student':          [ROLES.STUDENT],
  '/dashboard/parent':           [ROLES.PARENT],
  '/dashboard/accountant':       [ROLES.ACCOUNTANT],
  '/dashboard/librarian':        [ROLES.LIBRARIAN],
  '/dashboard/sports':           [ROLES.SPORTS],
  '/dashboard/extra-curricular': [ROLES.EXTRA_CURRICULAR],
  '/dashboard/analytics':        [ROLES.ANALYTICS, ROLES.MARKETING],
  '/dashboard/counsellor':       [ROLES.COUNSELLOR],
  // NEW
  '/dashboard/hostel':           [ROLES.HOSTEL_WARDEN, ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL],
  '/dashboard/admissions':       [ROLES.SALES_ADMISSION, ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL],
  '/dashboard/marketing':        [ROLES.MARKETING, ROLES.SCHOOL_ADMIN],
  '/dashboard/examinations':     [ROLES.EXAM_ADMIN, ROLES.SCHOOL_ADMIN, ROLES.PRINCIPAL],
};

// ── 4. ROLE DEFAULT REDIRECT AFTER LOGIN ────────────────────
const ROLE_HOME = {
  [ROLES.SUPER_ADMIN]:      '/dashboard/admin',
  [ROLES.SCHOOL_ADMIN]:     '/dashboard/school',
  [ROLES.PRINCIPAL]:        '/dashboard/school',
  [ROLES.TEACHER]:          '/dashboard/teacher',
  [ROLES.COORDINATOR]:      '/dashboard/teacher',
  [ROLES.COUNSELLOR]:       '/dashboard/counsellor',
  [ROLES.ACCOUNTANT]:       '/dashboard/accountant',
  [ROLES.LIBRARIAN]:        '/dashboard/librarian',
  [ROLES.SPORTS]:           '/dashboard/sports',
  [ROLES.EXTRA_CURRICULAR]: '/dashboard/extra-curricular',
  [ROLES.ANALYTICS]:        '/dashboard/analytics',
  [ROLES.HOSTEL_WARDEN]:    '/dashboard/hostel',       // NEW
  [ROLES.SALES_ADMISSION]:  '/dashboard/admissions',   // NEW
  [ROLES.MARKETING]:        '/dashboard/marketing',    // NEW
  [ROLES.EXAM_ADMIN]:       '/dashboard/examinations', // NEW
  [ROLES.PARENT]:           '/dashboard/parent',
  [ROLES.STUDENT]:          '/dashboard/student',
};

// Helper: check if a role can perform an action on a module
function can(role, module, action = 'read') {
  if (role === ROLES.SUPER_ADMIN) return true;
  const perms = MODULE_PERMISSIONS[module];
  if (!perms) return false;
  return perms[action]?.includes(role) ?? false;
}

module.exports = { ROLES, MODULE_PERMISSIONS, ROUTE_PERMISSIONS, ROLE_HOME, can };
