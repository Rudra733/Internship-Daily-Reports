# SproutSong — Part H: Logging & Monitoring Sample

> **DPDP Act 2023 compliant logging, audit trail, and security monitoring**
> Reference: `SproutSong_File_Upload_Security_Guide.docx — Part H`

---

## Project Structure

```
sproutsong-logging/
├── src/
│   ├── app.js                         # Entry point — wires all middleware + starts monitor
│   ├── middleware/
│   │   ├── auth.js                    # JWT auth + role guard
│   │   └── auditMiddleware.js         # ★ requestAuditMiddleware, sensitiveRouteAudit()
│   ├── models/
│   │   └── AuditLog.js                # ★ Append-only MongoDB schema, TTL, enums
│   ├── routes/
│   │   ├── auth.routes.js             # ★ Login/logout/reset with audit events
│   │   └── audit.routes.js            # Admin API to query audit logs
│   ├── services/
│   │   ├── auditLogger.js             # ★ Central audit writer — all event helpers
│   │   ├── alertService.js            # ★ Slack + PagerDuty alerts, brute-force tracker
│   │   └── securityMonitor.js         # ★ Cron-based anomaly detection
│   └── utils/
│       └── logger.js                  # ★ Winston logger with automatic PII masking
├── tests/
│   └── logging.test.js               # 40+ tests for masking, enums, brute-force, append-only
├── .env.example
└── package.json
```

---

## What Should Be Logged (Part H)

| Event | Category | Why | Helper |
|-------|----------|-----|--------|
| Login success | `AUTH` | Security monitoring | `logLoginSuccess()` |
| Login failure | `AUTH` | Security monitoring + brute-force | `logLoginFailure()` |
| Password reset request | `AUTH` | Account protection | `logPasswordResetRequest()` |
| Student report viewed | `DATA_ACCESS` | Sensitive data audit | `logStudentReportViewed()` |
| Document downloaded | `DATA_ACCESS` | Data access trail | `logDocumentDownloaded()` |
| Admin changed user role | `PRIVILEGE` | Privilege monitoring | `logRoleChanged()` |
| Bulk export | `DATA_EXPORT` | Data leakage risk | `logBulkExport()` |
| Failed access attempts | `SECURITY` | Attack detection | `logFailedAccessAttempt()` |
| Consent submitted/withdrawn | `CONSENT` | DPDP compliance | `logConsentSubmitted/Withdrawn()` |

## What Should NOT Be Logged (Part H)

| Field | How enforced |
|-------|-------------|
| Passwords | Stripped → `[REDACTED]` by `sanitiseLogMeta()` |
| OTPs | Stripped → `[REDACTED]` |
| Full tokens (JWT, reset) | Stripped → `[REDACTED]` / `[TOKEN]` |
| Full Aadhaar / Govt ID | Masked → `XXXX-XXXX-{last4}` |
| Full student counselling notes | Stripped → `[REDACTED]` |
| Payment card details | Stripped → `[REDACTED]` |
| Private document URLs / S3 keys | Stripped → `[REDACTED]` |

---

## Architecture

```
Route handler
     │
     ├──→ logLoginFailure() / logDocumentDownloaded() / etc.
     │         │
     │         ▼
     │    auditLogger.js  ←── sanitiseLogMeta() (PII stripped)
     │         │
     │         ├──→ AuditLog.create()        (MongoDB — append-only)
     │         ├──→ logger.info/warn()        (Winston → file / CloudWatch)
     │         └──→ triggerAlert()            (Slack / PagerDuty)
     │
     └──→ securityMonitor.js  (cron every 5 min)
               ├── checkBruteForce()          → aggregate LOGIN_FAILURE by IP
               ├── checkBulkDownloads()       → aggregate DOCUMENT_DOWNLOADED by userId
               ├── checkIdorProbing()         → aggregate IDOR_ATTEMPT by IP
               └── checkOffHoursAdminActivity()
```

---

## Quick Start

```bash
# 1. Install
npm install

# 2. Configure
cp .env.example .env
# Fill in: MONGO_URI, JWT_SECRET, SLACK_WEBHOOK_URL (optional), PAGERDUTY_ROUTING_KEY (optional)

# 3. Run tests
npm test

# 4. Start
npm run dev
```

---

## Key Design Decisions

**Append-only audit log:** The `AuditLog` Mongoose model intercepts all `updateOne`, `updateMany`, `deleteOne`, `deleteMany` operations at the pre-hook level and throws an error. Application code can only call `AuditLog.create()`.

**TTL auto-deletion:** Audit logs are retained for 365 days (configurable via `AUDIT_LOG_RETENTION_DAYS`), then auto-deleted by MongoDB's TTL index. This satisfies DPDP's data retention policy without manual cleanup.

**PII masking is defensive:** `sanitiseLogMeta()` recurses through the entire metadata object regardless of nesting depth (up to 6 levels). Even if a developer accidentally passes `{ actor: { email: '...' } }`, the email is masked before it reaches any log transport or DB insert.

**Brute-force tracking is in-memory by default.** Replace the `failedLoginMap` in `alertService.js` with a Redis client for production multi-instance deployments.

**Alerts are non-blocking.** `triggerAlert()` is always called with `.catch(() => {})` — a Slack/PagerDuty outage never blocks the main request flow.

---

*SproutSong Engineering & Compliance Team — DPDP Act 2023*
