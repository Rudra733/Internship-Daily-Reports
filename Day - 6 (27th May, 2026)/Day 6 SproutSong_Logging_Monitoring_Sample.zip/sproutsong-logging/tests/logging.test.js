/**
 * tests/logging.test.js — Tests for Part H: Logging & Monitoring
 *
 * Tests cover:
 *   1.  PII masking — sensitive fields stripped/masked before logging
 *   2.  "Do Not Log" fields — passwords, OTPs, tokens, Aadhaar stripped entirely
 *   3.  JWT token masking in log output
 *   4.  Aadhaar number masking (12-digit numbers)
 *   5.  Brute-force tracking — counter increments, threshold detection
 *   6.  Failed login counter resets on success
 *   7.  Audit log schema — append-only (update/delete blocked)
 *   8.  All AUDIT_CATEGORY values are valid strings
 *   9.  All AUDIT_ACTION values are valid strings
 *   10. auditLogger exports all required event helpers
 *   11. sanitiseLogMeta — nested object sanitisation
 *   12. sanitiseLogMeta — array sanitisation
 *   13. Alert severity levels defined correctly
 *   14. Security monitor exports required functions
 */

import { jest } from '@jest/globals';

// ── 1–4. PII masking (sanitiseLogMeta) ───────────────────────────────────────
describe('Logger PII masking — sanitiseLogMeta', () => {
  let sanitiseLogMeta;

  beforeAll(async () => {
    ({ sanitiseLogMeta } = await import('../src/utils/logger.js'));
  });

  test('masks email field to first 3 chars + ***', () => {
    const result = sanitiseLogMeta({ email: 'john.doe@example.com' });
    expect(result.email).toBe('joh***');
    expect(result.email).not.toContain('@');
    expect(result.email).not.toContain('example.com');
  });

  test('masks phone/mobile fields', () => {
    const result = sanitiseLogMeta({ mobile: '9876543210', schoolPhone: '9123456789' });
    expect(result.mobile).toBe('987***');
    expect(result.schoolPhone).toBe('912***');
  });

  test('masks contactPerson name', () => {
    const result = sanitiseLogMeta({ contactPerson: 'Rohan Shah' });
    expect(result.contactPerson).toBe('Roh***');
  });

  test('strips password entirely — replaces with [REDACTED]', () => {
    const result = sanitiseLogMeta({ password: 'MySecret123!' });
    expect(result.password).toBe('[REDACTED]');
    expect(result.password).not.toContain('MySecret');
  });

  test('strips OTP entirely', () => {
    const result = sanitiseLogMeta({ otp: '482910', otpCode: '123456' });
    expect(result.otp).toBe('[REDACTED]');
    expect(result.otpCode).toBe('[REDACTED]');
  });

  test('strips full token fields', () => {
    const result = sanitiseLogMeta({ token: 'abc123xyz', accessToken: 'longtoken', refreshToken: 'rt' });
    expect(result.token).toBe('[REDACTED]');
    expect(result.accessToken).toBe('[REDACTED]');
    expect(result.refreshToken).toBe('[REDACTED]');
  });

  test('strips counselling notes from logs', () => {
    const result = sanitiseLogMeta({ counsellingNotes: 'Student struggling with anxiety, parents divorced.' });
    expect(result.counsellingNotes).toBe('[REDACTED]');
    expect(result.counsellingNotes).not.toContain('anxiety');
  });

  test('strips payment card details', () => {
    const result = sanitiseLogMeta({ cardNumber: '4111111111111111', cvv: '123' });
    expect(result.cardNumber).toBe('[REDACTED]');
    expect(result.cvv).toBe('[REDACTED]');
  });

  test('strips private file paths (S3 keys)', () => {
    const result = sanitiseLogMeta({ std10FilePath: 'private/schools/s1/students/u1/marksheets/uuid.pdf' });
    expect(result.std10FilePath).toBe('[REDACTED]');
  });

  test('strips financial data fields', () => {
    const result = sanitiseLogMeta({ fatherIncome: '500000', motherIncome: '300000' });
    expect(result.fatherIncome).toBe('[REDACTED]');
    expect(result.motherIncome).toBe('[REDACTED]');
  });

  test('masks JWT token string (three-segment base64)', () => {
    const fakeJwt = 'eyJhbGciOiJIUzI1NiJ9.eyJ1c2VySWQiOiJ1LTAwMSJ9.signature123abc';
    const result  = sanitiseLogMeta({ authHeader: fakeJwt });
    expect(result.authHeader).toContain('[TOKEN]');
    expect(result.authHeader).not.toBe(fakeJwt);
  });

  test('masks Aadhaar-like 12-digit number', () => {
    const result = sanitiseLogMeta({ govtId: '123456789012' });
    expect(result.govtId).toBe('XXXX-XXXX-9012');
    expect(result.govtId).not.toContain('12345678');
  });

  test('passes through safe non-PII fields unchanged', () => {
    const result = sanitiseLogMeta({ referenceId: 'ref-abc', schoolId: 's-001', status: 'submitted', count: 5 });
    expect(result.referenceId).toBe('ref-abc');
    expect(result.schoolId).toBe('s-001');
    expect(result.status).toBe('submitted');
    expect(result.count).toBe(5);
  });

  test('handles nested objects recursively', () => {
    const result = sanitiseLogMeta({ actor: { email: 'admin@sproutsong.com', userId: 'u-001' } });
    expect(result.actor.email).toBe('adm***');
    expect(result.actor.userId).toBe('u-001');
  });

  test('handles arrays of objects', () => {
    const result = sanitiseLogMeta({ users: [{ email: 'a@b.com', name: 'Alice' }, { email: 'c@d.com', name: 'Bob' }] });
    expect(result.users[0].email).toBe('a@b***');
    expect(result.users[1].email).toBe('c@d***');
  });

  test('handles null and undefined gracefully', () => {
    const result = sanitiseLogMeta({ email: null, phone: undefined, name: '' });
    expect(result.email).toBeNull();
    expect(result.name).toBe('');
  });

  test('does not crash on deeply nested objects', () => {
    const deep = { a: { b: { c: { d: { e: { password: 'deep_secret' } } } } } };
    expect(() => sanitiseLogMeta(deep)).not.toThrow();
  });
});

// ── 5–6. Brute-force tracking ─────────────────────────────────────────────────
describe('Brute-force login tracking — alertService', () => {
  let trackFailedLogin, resetFailedLoginCount;

  beforeAll(async () => {
    ({ trackFailedLogin, resetFailedLoginCount } = await import('../src/services/alertService.js'));
  });

  const TEST_IP = '192.168.99.99';
  const THRESHOLD = parseInt(process.env.FAILED_LOGIN_THRESHOLD || '5', 10);

  beforeEach(() => {
    resetFailedLoginCount(TEST_IP); // Start fresh
  });

  test('returns false before threshold is reached', () => {
    for (let i = 0; i < THRESHOLD - 1; i++) {
      const result = trackFailedLogin(TEST_IP);
      expect(result).toBe(false);
    }
  });

  test('returns true when threshold is exactly reached', () => {
    for (let i = 0; i < THRESHOLD - 1; i++) trackFailedLogin(TEST_IP);
    const result = trackFailedLogin(TEST_IP); // Nth attempt
    expect(result).toBe(true);
  });

  test('returns true on every attempt after threshold', () => {
    for (let i = 0; i < THRESHOLD; i++) trackFailedLogin(TEST_IP);
    expect(trackFailedLogin(TEST_IP)).toBe(true);
    expect(trackFailedLogin(TEST_IP)).toBe(true);
  });

  test('resets counter on successful login', () => {
    for (let i = 0; i < THRESHOLD; i++) trackFailedLogin(TEST_IP);
    resetFailedLoginCount(TEST_IP);
    // After reset, first failure should return false
    expect(trackFailedLogin(TEST_IP)).toBe(false);
  });

  test('different IPs have independent counters', () => {
    const ip2 = '10.0.0.5';
    resetFailedLoginCount(ip2);
    for (let i = 0; i < THRESHOLD; i++) trackFailedLogin(TEST_IP);
    // ip2 should still be at zero
    expect(trackFailedLogin(ip2)).toBe(false);
  });
});

// ── 7. Audit log append-only enforcement ──────────────────────────────────────
describe('AuditLog model — append-only enforcement', () => {
  let AuditLog;

  beforeAll(async () => {
    ({ default: AuditLog } = await import('../src/models/AuditLog.js'));
  });

  test('updateOne throws "append-only" error', async () => {
    await expect(
      AuditLog.updateOne({ eventId: 'fake' }, { $set: { outcome: 'SUCCESS' } })
    ).rejects.toThrow(/append-only/i);
  });

  test('deleteOne throws "append-only" error', async () => {
    await expect(
      AuditLog.deleteOne({ eventId: 'fake' })
    ).rejects.toThrow(/append-only/i);
  });

  test('deleteMany throws "append-only" error', async () => {
    await expect(
      AuditLog.deleteMany({})
    ).rejects.toThrow(/append-only/i);
  });
});

// ── 8–9. Enum completeness ────────────────────────────────────────────────────
describe('Audit enums — AUDIT_CATEGORY and AUDIT_ACTION', () => {
  let AUDIT_CATEGORY, AUDIT_ACTION;

  beforeAll(async () => {
    ({ AUDIT_CATEGORY, AUDIT_ACTION } = await import('../src/models/AuditLog.js'));
  });

  const requiredCategories = ['AUTH', 'DATA_ACCESS', 'PRIVILEGE', 'DATA_EXPORT', 'SECURITY', 'CONSENT', 'ERASURE'];
  const requiredActions    = [
    'LOGIN_SUCCESS', 'LOGIN_FAILURE', 'PASSWORD_RESET_REQUEST',
    'STUDENT_REPORT_VIEWED', 'DOCUMENT_DOWNLOADED',
    'ROLE_CHANGED',
    'BULK_EXPORT',
    'FAILED_ACCESS_ATTEMPT', 'IDOR_ATTEMPT',
    'CONSENT_SUBMITTED', 'CONSENT_WITHDRAWN',
    'ERASURE_COMPLETED',
  ];

  test.each(requiredCategories)('AUDIT_CATEGORY includes %s', (cat) => {
    expect(AUDIT_CATEGORY[cat]).toBe(cat);
  });

  test.each(requiredActions)('AUDIT_ACTION includes %s', (action) => {
    expect(AUDIT_ACTION[action]).toBe(action);
  });
});

// ── 10. auditLogger exports all helpers ───────────────────────────────────────
describe('auditLogger service exports', () => {
  let auditLogger;

  beforeAll(async () => {
    auditLogger = await import('../src/services/auditLogger.js');
  });

  const requiredExports = [
    'writeAuditLog',
    'logLoginSuccess',
    'logLoginFailure',
    'logPasswordResetRequest',
    'logStudentReportViewed',
    'logDocumentDownloaded',
    'logRoleChanged',
    'logBulkExport',
    'logFailedAccessAttempt',
    'logIdorAttempt',
    'logConsentSubmitted',
    'logConsentWithdrawn',
    'logErasureCompleted',
  ];

  test.each(requiredExports)('exports %s function', (fnName) => {
    expect(typeof auditLogger[fnName]).toBe('function');
  });
});

// ── 11. Alert severity levels ─────────────────────────────────────────────────
describe('Alert severity levels', () => {
  let ALERT_SEVERITY;

  beforeAll(async () => {
    ({ ALERT_SEVERITY } = await import('../src/services/alertService.js'));
  });

  test('defines LOW, MEDIUM, HIGH, CRITICAL', () => {
    expect(ALERT_SEVERITY.LOW).toBe('LOW');
    expect(ALERT_SEVERITY.MEDIUM).toBe('MEDIUM');
    expect(ALERT_SEVERITY.HIGH).toBe('HIGH');
    expect(ALERT_SEVERITY.CRITICAL).toBe('CRITICAL');
  });
});

// ── 12. Security monitor exports ──────────────────────────────────────────────
describe('Security monitor exports', () => {
  let securityMonitor;

  beforeAll(async () => {
    securityMonitor = await import('../src/services/securityMonitor.js');
  });

  test('exports startSecurityMonitor function', () => {
    expect(typeof securityMonitor.startSecurityMonitor).toBe('function');
  });

  test('exports getAuditSummary function', () => {
    expect(typeof securityMonitor.getAuditSummary).toBe('function');
  });

  test('exports getRecentEventsForUser function', () => {
    expect(typeof securityMonitor.getRecentEventsForUser).toBe('function');
  });

  test('exports getFailedAttemptsForIp function', () => {
    expect(typeof securityMonitor.getFailedAttemptsForIp).toBe('function');
  });
});
