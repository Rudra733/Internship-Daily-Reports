/**
 * docs/usage-examples.js
 *
 * Copy-paste examples for integrating audit logging into
 * any SproutSong Express route.
 *
 * For each event from Part H, this file shows:
 *   - The import
 *   - The exact call
 *   - Where it goes in the route handler
 *   - What gets stored vs what is masked/stripped
 */

// ─────────────────────────────────────────────────────────────────────────────
// IMPORT — add to the top of any route file
// ─────────────────────────────────────────────────────────────────────────────
import {
  logLoginSuccess,
  logLoginFailure,
  logPasswordResetRequest,
  logStudentReportViewed,
  logDocumentDownloaded,
  logRoleChanged,
  logBulkExport,
  logFailedAccessAttempt,
  logIdorAttempt,
  logConsentSubmitted,
  logConsentWithdrawn,
  logErasureCompleted,
  writeAuditLog,
  AUDIT_CATEGORY,
  AUDIT_ACTION,
} from '../services/auditLogger.js';

import { sensitiveRouteAudit, adminActionAudit } from '../middleware/auditMiddleware.js';


// ─────────────────────────────────────────────────────────────────────────────
// 1. LOGIN SUCCESS
// ─────────────────────────────────────────────────────────────────────────────
// Call after verifying credentials — NEVER before.
// email is masked automatically (joh*** stored in DB).
// Password is NEVER passed to this function.

await logLoginSuccess({
  userId:    user.userId,         // stored as-is
  role:      user.role,           // stored as-is
  email:     user.email,          // → masked to "joh***" before DB write
  ip:        req.ip,              // stored as-is
  userAgent: req.headers['user-agent'], // stored, truncated to 300 chars
});

// What is stored in audit_logs:
// { action: "LOGIN_SUCCESS", outcome: "SUCCESS",
//   actor: { userId: "u-001", role: "admin", emailMasked: "adm***" },
//   request: { ip: "1.2.3.4", userAgent: "Mozilla/..." } }


// ─────────────────────────────────────────────────────────────────────────────
// 2. LOGIN FAILURE
// ─────────────────────────────────────────────────────────────────────────────
// Call on bad credentials, locked account, or rate limit hit.
// Also feeds the brute-force tracker.

await logLoginFailure({
  email:     req.body.email,      // → masked to "joh***"
  ip:        req.ip,
  userAgent: req.headers['user-agent'],
  reason:    'invalid_credentials', // 'invalid_credentials' | 'account_locked' | 'validation_failed'
  // NEVER pass: password, token, OTP
});


// ─────────────────────────────────────────────────────────────────────────────
// 3. PASSWORD RESET REQUEST
// ─────────────────────────────────────────────────────────────────────────────
// Log the request — NEVER the reset token itself.

await logPasswordResetRequest({
  userId: user?.userId || null,   // null if email not found (don't reveal)
  email:  req.body.email,         // masked
  ip:     req.ip,
  // NEVER pass: resetToken, newPassword, oldPassword
});


// ─────────────────────────────────────────────────────────────────────────────
// 4. STUDENT REPORT VIEWED (sensitive data audit)
// ─────────────────────────────────────────────────────────────────────────────
// Option A — call directly in the route handler:

await logStudentReportViewed({
  userId:      req.user.userId,
  role:        req.user.role,
  referenceId: req.params.referenceId,
  schoolId:    record.schoolId,
  ip:          req.ip,
  path:        req.path,
});

// Option B — use sensitiveRouteAudit middleware (cleaner, less code):
// router.get('/report/:referenceId',
//   authMiddleware,
//   sensitiveRouteAudit('student_report'),   // ← fires automatically
//   reportHandler
// );


// ─────────────────────────────────────────────────────────────────────────────
// 5. DOCUMENT DOWNLOADED (data access trail)
// ─────────────────────────────────────────────────────────────────────────────
// Call when a signed URL is generated (the download event).
// fieldName tells us WHICH document (e.g. std10FilePath) — NOT the S3 key.

await logDocumentDownloaded({
  userId:      req.user.userId,
  role:        req.user.role,
  referenceId: record.referenceId,
  fieldName:   req.params.fieldName,   // e.g. "std10FilePath" — NOT the S3 key
  schoolId:    record.schoolId,
  ip:          req.ip,
  // NEVER pass: s3Key, signedUrl, photoPath value
});


// ─────────────────────────────────────────────────────────────────────────────
// 6. ADMIN CHANGED USER ROLE (privilege monitoring)
// ─────────────────────────────────────────────────────────────────────────────
// ALWAYS triggers a Slack alert (HIGH severity).
// Record both old and new role for the audit trail.

await logRoleChanged({
  adminUserId:  req.user.userId,
  targetUserId: req.params.userId,
  previousRole: existingUser.role,   // e.g. "counsellor"
  newRole:      req.body.role,       // e.g. "admin"
  ip:           req.ip,
});

// Or use the adminActionAudit middleware:
// router.patch('/users/:userId/role',
//   authMiddleware,
//   requireRole('admin'),
//   adminActionAudit(AUDIT_ACTION.ROLE_CHANGED),
//   roleChangeHandler
// );


// ─────────────────────────────────────────────────────────────────────────────
// 7. BULK EXPORT (data leakage risk)
// ─────────────────────────────────────────────────────────────────────────────
// Triggers HIGH alert if rowCount > BULK_EXPORT_ALERT_ROWS (default 100).
// Never include PII in metadata — only structural info (count, type).

await logBulkExport({
  userId:     req.user.userId,
  role:       req.user.role,
  exportType: 'counselling_requests_csv',
  rowCount:   results.length,
  filters:    { status: 'submitted', dateRange: '2024-01-01/2024-12-31' }, // non-PII
  ip:         req.ip,
  // NEVER include: the actual data being exported
});


// ─────────────────────────────────────────────────────────────────────────────
// 8. FAILED ACCESS ATTEMPT (attack detection)
// ─────────────────────────────────────────────────────────────────────────────
// Call when a user attempts to access a resource they are not authorised for.
// Triggers HIGH alert.

await logFailedAccessAttempt({
  userId:    req.user?.userId || null,
  ip:        req.ip,
  path:      req.path,
  method:    req.method,
  reason:    'role_insufficient',   // or 'idor_check_failed', 'school_mismatch'
  userAgent: req.headers['user-agent'],
});

// For IDOR specifically (higher severity — CRITICAL):
await logIdorAttempt({
  userId:      req.user.userId,
  role:        req.user.role,
  referenceId: req.params.referenceId,
  ip:          req.ip,
  path:        req.path,
});


// ─────────────────────────────────────────────────────────────────────────────
// 9. CONSENT SUBMITTED (DPDP compliance)
// ─────────────────────────────────────────────────────────────────────────────
// Call after saving the record with consentGiven: true.
// consentType identifies which consent was given.

await logConsentSubmitted({
  userId:      null,               // null for unauthenticated form submissions
  referenceId: record.referenceId,
  consentType: 'counselling',      // 'counselling' | 'document' | 'parent' | 'workshop'
  ip:          req.ip,
  userAgent:   req.headers['user-agent'],
});


// ─────────────────────────────────────────────────────────────────────────────
// 10. CONSENT WITHDRAWN (DPDP compliance)
// ─────────────────────────────────────────────────────────────────────────────
// Call when a user withdraws consent (triggers MEDIUM alert + potential erasure).

await logConsentWithdrawn({
  userId:      req.user?.userId || null,
  referenceId: req.params.referenceId,
  consentType: 'counselling',
  ip:          req.ip,
});


// ─────────────────────────────────────────────────────────────────────────────
// 11. DPDP ERASURE COMPLETED
// ─────────────────────────────────────────────────────────────────────────────
// Call AFTER both S3 files and MongoDB record are deleted.
// This creates the compliance audit trail for the erasure.

await logErasureCompleted({
  adminUserId:  req.user.userId,
  referenceId:  req.params.referenceId,
  filesDeleted: cascadeResult.filesDeleted,   // number only — no file names/paths
  ip:           req.ip,
});


// ─────────────────────────────────────────────────────────────────────────────
// 12. CUSTOM EVENT — using writeAuditLog directly
// ─────────────────────────────────────────────────────────────────────────────
// For any event not covered by the helpers above.

await writeAuditLog({
  category:  AUDIT_CATEGORY.ADMIN,
  action:    AUDIT_ACTION.SETTINGS_CHANGED,
  outcome:   'SUCCESS',
  actor:     { userId: req.user.userId, role: req.user.role },
  target:    { resourceType: 'platform_settings', resourceId: 'global' },
  request:   { ip: req.ip, method: req.method, path: req.path },
  metadata:  { setting: 'max_upload_size', previousValue: '5MB', newValue: '10MB' },
  // metadata is sanitised automatically — no need to pre-sanitise
  alert:     true,
  alertSeverity: 'HIGH',
});


// ─────────────────────────────────────────────────────────────────────────────
// WHAT NOT TO DO — common mistakes
// ─────────────────────────────────────────────────────────────────────────────

// ❌ WRONG — logging the raw request body (contains passwords, tokens, PII)
logger.info('Form submitted', { body: req.body });

// ✅ CORRECT — log only safe identifiers
logger.info('Form submitted', { referenceId, ip: req.ip, status: 'submitted' });

// ❌ WRONG — logging the JWT token
logger.info('User logged in', { token: generatedToken });

// ✅ CORRECT — log the event, not the credential
await logLoginSuccess({ userId, role, email, ip: req.ip, userAgent });

// ❌ WRONG — logging an S3 signed URL or key
logger.info('File served', { url: signedUrl, key: s3Key });

// ✅ CORRECT — log the structural reference only
logger.info('File served', { referenceId, fieldName, userId: req.user.userId });

// ❌ WRONG — logging counselling notes in an error
logger.error('Save failed', { error: err.message, counsellingNotes: req.body.notes });

// ✅ CORRECT — sanitiseLogMeta handles this, but be explicit
logger.error('Save failed', { error: err.message, referenceId });
