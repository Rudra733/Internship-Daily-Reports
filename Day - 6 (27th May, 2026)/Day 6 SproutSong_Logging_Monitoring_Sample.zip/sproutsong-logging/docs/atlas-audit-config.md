# SproutSong — MongoDB Atlas Audit Log Configuration
# docs/atlas-audit-config.md
#
# This documents how to enable MongoDB Atlas audit logging
# to supplement the application-level audit trail.
#
# Atlas audit logs capture DB-level operations:
#   - authenticate (login to MongoDB)
#   - insert / find / update / delete on audit_logs collection
#   - createCollection, dropCollection
#   - createIndex
#
# This is a second layer of audit — even if application code is
# compromised, Atlas audit logs cannot be tampered with by the app.
#
# ─────────────────────────────────────────────────────────────────
# SETUP STEPS (Atlas console → Project → Security → Advanced)
# ─────────────────────────────────────────────────────────────────
#
# 1. Enable Database Auditing in Atlas:
#    Project → Security → Advanced → Database Auditing → ON
#
# 2. Configure the audit filter JSON below:
#    (Paste into the "Custom Filter" field in Atlas)
#
# ─────────────────────────────────────────────────────────────────
# Audit filter: captures all write operations + authentications
# on the sproutsong database, and ALL operations on audit_logs
# ─────────────────────────────────────────────────────────────────

ATLAS_AUDIT_FILTER='{
  "atype": {
    "$in": [
      "authenticate",
      "authCheck",
      "insert",
      "update",
      "delete",
      "find",
      "createCollection",
      "dropCollection",
      "createIndex",
      "dropDatabase",
      "logout",
      "createUser",
      "dropUser",
      "updateUser",
      "grantRolesToUser",
      "revokeRolesFromUser"
    ]
  },
  "$or": [
    {
      "param.ns": { "$regex": "^sproutsong\\.audit_logs$" }
    },
    {
      "param.ns": { "$regex": "^sproutsong\\." },
      "atype": { "$in": ["authenticate", "createUser", "dropUser", "updateUser", "grantRolesToUser", "revokeRolesFromUser", "dropDatabase", "dropCollection"] }
    }
  ]
}'

# ─────────────────────────────────────────────────────────────────
# KEY RULES TO ENFORCE IN ATLAS:
# ─────────────────────────────────────────────────────────────────
#
# 1. IP Allowlist — only allow connections from your app server IPs:
#    Project → Security → Network Access → Add IP Address
#    Never add 0.0.0.0/0
#
# 2. Database users — least privilege:
#    sproutsong_app → readWrite on sproutsong database ONLY
#    sproutsong_readonly → read on sproutsong database (for reports)
#    Never use atlas-admin user in app connection strings
#
# 3. Encryption at rest:
#    Project → Security → Advanced → Encryption at Rest → Enable
#    Use AWS KMS (ap-south-1) with your CMK
#
# 4. TLS:
#    Atlas enforces TLS 1.2+ on all connections by default.
#    Ensure your MONGO_URI uses mongodb+srv:// (not mongodb://)
#
# 5. Backup:
#    Project → Clusters → ... → Backup → Enable Continuous Backup
#    Point-in-time recovery window: 7 days minimum
#
# ─────────────────────────────────────────────────────────────────
# ATLAS AUDIT LOG RETENTION:
# ─────────────────────────────────────────────────────────────────
#
# Atlas stores audit logs for 30 days by default.
# For DPDP compliance (1 year retention):
#   → Enable Atlas Continuous Backup → Export logs to S3 daily
#   → Store in a separate, write-once S3 bucket (Object Lock enabled)
#   → Set S3 bucket lifecycle: retain for 365 days, then Glacier for 2 more years
#
# S3 bucket for audit logs (separate from private documents bucket):
#   Bucket name: sproutsong-audit-logs
#   Object Lock: enabled (WORM — Write Once Read Many)
#   Versioning: enabled
#   Block all public access: ON
#   No delete permissions for the app IAM role
