/**
 * services/securityMonitor.js — Real-time security monitoring & anomaly detection
 *
 * Runs scheduled jobs to detect:
 *   1. Brute-force login attempts (many failures from same IP in a window)
 *   2. Unusual bulk downloads (same user downloading many documents quickly)
 *   3. Off-hours admin activity (admin actions outside business hours)
 *   4. Privilege escalation patterns (rapid role changes)
 *   5. Repeated IDOR attempts (same user probing multiple resource IDs)
 *
 * Uses node-cron to run checks every 5 minutes against the audit log DB.
 *
 * In production, consider replacing cron jobs with:
 *   - AWS CloudWatch Metric Filters + Alarms
 *   - Elasticsearch + Kibana alerts
 *   - Datadog Security Monitoring
 */

import cron    from 'node-cron';
import AuditLog, { AUDIT_CATEGORY, AUDIT_ACTION } from '../models/AuditLog.js';
import { triggerAlert, ALERT_SEVERITY }            from './alertService.js';
import { logger }                                  from '../utils/logger.js';

// ── Configuration ─────────────────────────────────────────────────────────────
const MONITOR_CONFIG = {
  // Brute force: N failed logins from one IP within window
  bruteForce: {
    threshold:  parseInt(process.env.FAILED_LOGIN_THRESHOLD || '5', 10),
    windowMins: parseInt(process.env.FAILED_LOGIN_WINDOW_MINUTES || '15', 10),
  },
  // Bulk download: N documents downloaded by one user within 10 minutes
  bulkDownload: {
    threshold:  20,
    windowMins: 10,
  },
  // IDOR probing: N IDOR attempts from one IP within 5 minutes
  idorProbing: {
    threshold:  3,
    windowMins: 5,
  },
  // Off-hours: alert admin actions outside 08:00–20:00 IST
  offHours: {
    startHour: 8,
    endHour:   20,
  },
};

// ── Anomaly detection queries ──────────────────────────────────────────────────

/**
 * Check for brute-force login attempts.
 * Looks at audit logs from the last N minutes for LOGIN_FAILURE events.
 */
async function checkBruteForce() {
  const since = new Date(Date.now() - MONITOR_CONFIG.bruteForce.windowMins * 60 * 1000);

  const results = await AuditLog.aggregate([
    {
      $match: {
        action:    AUDIT_ACTION.LOGIN_FAILURE,
        timestamp: { $gte: since },
      },
    },
    {
      $group: {
        _id:   '$request.ip',
        count: { $sum: 1 },
        firstSeen: { $min: '$timestamp' },
        lastSeen:  { $max: '$timestamp' },
      },
    },
    {
      $match: { count: { $gte: MONITOR_CONFIG.bruteForce.threshold } },
    },
  ]);

  for (const result of results) {
    logger.warn('MONITOR: Brute-force login attempt detected', {
      ip:        result._id,
      attempts:  result.count,
      window:    `${MONITOR_CONFIG.bruteForce.windowMins} minutes`,
    });

    await triggerAlert({
      category:  AUDIT_CATEGORY.SECURITY,
      action:    AUDIT_ACTION.LOGIN_FAILURE,
      outcome:   'BLOCKED',
      severity:  ALERT_SEVERITY.CRITICAL,
      entry: {
        actor:   { userId: null, role: null },
        target:  { resourceId: null },
        request: { ip: result._id, path: '/auth/login' },
        metadata: { attempts: result.count, windowMins: MONITOR_CONFIG.bruteForce.windowMins },
        timestamp: new Date(),
      },
    });
  }
}

/**
 * Check for bulk document downloads by a single user.
 * A counsellor downloading >20 documents in 10 minutes is suspicious.
 */
async function checkBulkDownloads() {
  const since = new Date(Date.now() - MONITOR_CONFIG.bulkDownload.windowMins * 60 * 1000);

  const results = await AuditLog.aggregate([
    {
      $match: {
        action:    AUDIT_ACTION.DOCUMENT_DOWNLOADED,
        timestamp: { $gte: since },
        'actor.userId': { $ne: null },
      },
    },
    {
      $group: {
        _id:    '$actor.userId',
        role:   { $first: '$actor.role' },
        count:  { $sum: 1 },
        ips:    { $addToSet: '$request.ip' },
      },
    },
    {
      $match: { count: { $gte: MONITOR_CONFIG.bulkDownload.threshold } },
    },
  ]);

  for (const result of results) {
    logger.warn('MONITOR: Unusual bulk document download detected', {
      userId:    result._id,
      role:      result.role,
      downloads: result.count,
      uniqueIps: result.ips.length,
    });

    await triggerAlert({
      category: AUDIT_CATEGORY.DATA_EXPORT,
      action:   AUDIT_ACTION.DOCUMENT_DOWNLOADED,
      outcome:  'SUCCESS',
      severity: ALERT_SEVERITY.HIGH,
      entry: {
        actor:    { userId: result._id, role: result.role },
        target:   {},
        request:  { ip: result.ips[0] || 'multiple' },
        metadata: { downloadCount: result.count, windowMins: MONITOR_CONFIG.bulkDownload.windowMins },
        timestamp: new Date(),
      },
    });
  }
}

/**
 * Check for IDOR probing — repeated attempts to access unauthorised resources.
 */
async function checkIdorProbing() {
  const since = new Date(Date.now() - MONITOR_CONFIG.idorProbing.windowMins * 60 * 1000);

  const results = await AuditLog.aggregate([
    {
      $match: {
        action:    AUDIT_ACTION.IDOR_ATTEMPT,
        timestamp: { $gte: since },
      },
    },
    {
      $group: {
        _id:   '$request.ip',
        count: { $sum: 1 },
        userIds: { $addToSet: '$actor.userId' },
      },
    },
    {
      $match: { count: { $gte: MONITOR_CONFIG.idorProbing.threshold } },
    },
  ]);

  for (const result of results) {
    logger.error('MONITOR: IDOR probing pattern detected', {
      ip:       result._id,
      attempts: result.count,
      userIds:  result.userIds,
    });

    await triggerAlert({
      category: AUDIT_CATEGORY.SECURITY,
      action:   AUDIT_ACTION.IDOR_ATTEMPT,
      outcome:  'BLOCKED',
      severity: ALERT_SEVERITY.CRITICAL,
      entry: {
        actor:    { userId: result.userIds[0] || null },
        target:   {},
        request:  { ip: result._id },
        metadata: { probeCount: result.count },
        timestamp: new Date(),
      },
    });
  }
}

/**
 * Check for off-hours admin activity.
 * Admin role changes or bulk exports outside business hours (08:00–20:00 IST) are flagged.
 */
async function checkOffHoursAdminActivity() {
  const since = new Date(Date.now() - 5 * 60 * 1000); // Last 5 minutes
  const currentHour = new Date().getUTCHours() + 5; // UTC+5:30 IST (approx)

  if (currentHour >= MONITOR_CONFIG.offHours.startHour &&
      currentHour < MONITOR_CONFIG.offHours.endHour) {
    return; // Business hours — no alert
  }

  const results = await AuditLog.find({
    action:    { $in: [AUDIT_ACTION.ROLE_CHANGED, AUDIT_ACTION.BULK_EXPORT, AUDIT_ACTION.USER_DEACTIVATED] },
    timestamp: { $gte: since },
  }).limit(10);

  for (const event of results) {
    logger.warn('MONITOR: Off-hours admin activity detected', {
      action:   event.action,
      userId:   event.actor?.userId,
      hour:     currentHour,
    });

    await triggerAlert({
      category: AUDIT_CATEGORY.ADMIN,
      action:   event.action,
      outcome:  'SUCCESS',
      severity: ALERT_SEVERITY.HIGH,
      entry: {
        actor:    event.actor,
        target:   event.target,
        request:  event.request,
        metadata: { reason: 'off_hours_activity', localHour: currentHour },
        timestamp: new Date(),
      },
    });
  }
}

// ── Scheduler ─────────────────────────────────────────────────────────────────

let isRunning = false;

/**
 * Starts all security monitoring cron jobs.
 * Call once at application startup.
 */
export function startSecurityMonitor() {
  logger.info('Security monitor starting...');

  // Run all checks every 5 minutes
  cron.schedule('*/5 * * * *', async () => {
    if (isRunning) return; // Prevent overlapping runs
    isRunning = true;
    try {
      await Promise.allSettled([
        checkBruteForce(),
        checkBulkDownloads(),
        checkIdorProbing(),
        checkOffHoursAdminActivity(),
      ]);
    } catch (err) {
      logger.error('Security monitor run failed', { error: err.message });
    } finally {
      isRunning = false;
    }
  });

  logger.info('Security monitor active — running checks every 5 minutes');
}

// ── Manual query helpers (for admin dashboard) ─────────────────────────────────

/**
 * Returns recent audit events for a specific user (for admin review).
 * Useful for investigating suspicious activity.
 */
export async function getRecentEventsForUser(userId, limit = 50) {
  return AuditLog.find({ 'actor.userId': userId })
    .sort({ timestamp: -1 })
    .limit(limit)
    .lean();
}

/**
 * Returns recent failed access attempts for an IP address.
 */
export async function getFailedAttemptsForIp(ip, windowMins = 60) {
  const since = new Date(Date.now() - windowMins * 60 * 1000);
  return AuditLog.find({
    'request.ip': ip,
    outcome:      { $in: ['FAILURE', 'BLOCKED'] },
    timestamp:    { $gte: since },
  }).sort({ timestamp: -1 }).lean();
}

/**
 * Returns a summary of audit events by category for a time window.
 * Used on the admin security dashboard.
 */
export async function getAuditSummary(windowHours = 24) {
  const since = new Date(Date.now() - windowHours * 60 * 60 * 1000);
  return AuditLog.aggregate([
    { $match: { timestamp: { $gte: since } } },
    {
      $group: {
        _id:     { category: '$category', action: '$action', outcome: '$outcome' },
        count:   { $sum: 1 },
        lastSeen:{ $max: '$timestamp' },
      },
    },
    { $sort: { count: -1 } },
  ]);
}
