/**
 * services/auditLogger.js — Central audit event writer
 *
 * This is the ONLY place where audit log records are created.
 * All routes and services call functions from this module — never AuditLog.create() directly.
 *
 * Responsibilities:
 *   1. Sanitise metadata to remove PII before persisting to DB (DPDP rule)
 *   2. Write to MongoDB audit collection (persistent, queryable)
 *   3. Write to application logger (for log aggregators like CloudWatch / ELK)
 *   4. Trigger alerts for high-severity events (see alertService.js)
 *
 * What Should Be Logged (Part H):
 *   ✓ Login success / failure
 *   ✓ Password reset request
 *   ✓ Student report viewed
 *   ✓ Document downloaded
 *   ✓ Admin changed user role
 *   ✓ Bulk export
 *   ✓ Failed access attempts
 *   ✓ Consent submitted / withdrawn
 *
 * What Should NOT Be Logged:
 *   ✗ Passwords, OTPs, full tokens
 *   ✗ Full Aadhaar / Govt ID
 *   ✗ Full student counselling notes
 *   ✗ Payment card details
 *   ✗ Private document URLs / S3 keys
 */

import { v4 as uuidv4 } from 'uuid';
import AuditLog, { AUDIT_CATEGORY, AUDIT_ACTION } from '../models/AuditLog.js';
import { logger, sanitiseLogMeta }                from '../utils/logger.js';
import { triggerAlert, ALERT_SEVERITY }           from './alertService.js';

export { AUDIT_CATEGORY, AUDIT_ACTION };

// ── Core write function ───────────────────────────────────────────────────────

/**
 * Creates a single audit log entry.
 * Called by all event-specific helpers below.
 *
 * @param {object} params
 * @param {string} params.category     - AUDIT_CATEGORY value
 * @param {string} params.action       - AUDIT_ACTION value
 * @param {string} params.outcome      - 'SUCCESS' | 'FAILURE' | 'BLOCKED'
 * @param {object} [params.actor]      - { userId, role, email }
 * @param {object} [params.target]     - { resourceType, resourceId, schoolId, previousValue, newValue }
 * @param {object} [params.request]    - { ip, userAgent, method, path }
 * @param {object} [params.metadata]   - Additional context (will be sanitised)
 * @param {boolean} [params.alert]     - If true, trigger an alert for this event
 * @param {string}  [params.alertSeverity] - ALERT_SEVERITY value
 */
export async function writeAuditLog({
  category,
  action,
  outcome,
  actor     = {},
  target    = {},
  request   = {},
  metadata  = {},
  alert     = false,
  alertSeverity = ALERT_SEVERITY.MEDIUM,
}) {
  // Sanitise metadata — strips PII, passwords, tokens before DB write
  const safeMetadata = sanitiseLogMeta(metadata);

  // Mask actor email — store only first 3 chars (DPDP rule)
  const emailMasked = actor.email
    ? actor.email.slice(0, 3) + '***'
    : null;

  const entry = {
    eventId:  uuidv4(),
    category,
    action,
    outcome,
    actor: {
      userId:       actor.userId   || null,
      role:         actor.role     || null,
      emailMasked,
    },
    target: {
      resourceType:  target.resourceType  || null,
      resourceId:    target.resourceId    || null,
      schoolId:      target.schoolId      || null,
      previousValue: target.previousValue || null,
      newValue:      target.newValue      || null,
    },
    request: {
      ip:        request.ip        || null,
      userAgent: request.userAgent ? request.userAgent.slice(0, 300) : null,
      method:    request.method    || null,
      path:      request.path      || null,
    },
    metadata: safeMetadata,
    timestamp: new Date(),
  };

  // Write to MongoDB audit collection
  try {
    await AuditLog.create(entry);
  } catch (err) {
    // Log to app logger but never crash — audit failure must not block the main request
    logger.error('Audit log write failed', { error: err.message, action, category });
  }

  // Mirror to application logger (for CloudWatch / ELK ingestion)
  const logLevel = outcome === 'FAILURE' || outcome === 'BLOCKED' ? 'warn' : 'info';
  logger[logLevel](`AUDIT: ${action}`, {
    category,
    outcome,
    userId:     entry.actor.userId,
    role:       entry.actor.role,
    resourceId: entry.target.resourceId,
    ip:         entry.request.ip,
    path:       entry.request.path,
  });

  // Trigger alert if flagged
  if (alert) {
    triggerAlert({ category, action, outcome, entry, severity: alertSeverity }).catch(() => {});
  }
}

// ── Event-specific helpers ────────────────────────────────────────────────────
// Use these in routes instead of calling writeAuditLog directly.
// Each helper pre-fills category and action, and applies the right alert rules.

/**
 * AUTH: Login success
 */
export function logLoginSuccess({ userId, role, email, ip, userAgent }) {
  return writeAuditLog({
    category: AUDIT_CATEGORY.AUTH,
    action:   AUDIT_ACTION.LOGIN_SUCCESS,
    outcome:  'SUCCESS',
    actor:    { userId, role, email },
    request:  { ip, userAgent },
  });
}

/**
 * AUTH: Login failure
 * Triggers alert after threshold exceeded (see alertService.js).
 */
export function logLoginFailure({ email, ip, userAgent, reason }) {
  return writeAuditLog({
    category:      AUDIT_CATEGORY.AUTH,
    action:        AUDIT_ACTION.LOGIN_FAILURE,
    outcome:       'FAILURE',
    actor:         { email },
    request:       { ip, userAgent },
    metadata:      { reason },   // e.g. 'invalid_password', 'account_locked'
    alert:         true,
    alertSeverity: ALERT_SEVERITY.HIGH,
  });
}

/**
 * AUTH: Password reset requested
 */
export function logPasswordResetRequest({ userId, email, ip }) {
  return writeAuditLog({
    category: AUDIT_CATEGORY.AUTH,
    action:   AUDIT_ACTION.PASSWORD_RESET_REQUEST,
    outcome:  'SUCCESS',
    actor:    { userId, email },
    request:  { ip },
    // Never log the reset token itself — just the event
  });
}

/**
 * DATA_ACCESS: Student report viewed
 * (Sensitive data audit — triggers on every view)
 */
export function logStudentReportViewed({ userId, role, referenceId, schoolId, ip, path }) {
  return writeAuditLog({
    category: AUDIT_CATEGORY.DATA_ACCESS,
    action:   AUDIT_ACTION.STUDENT_REPORT_VIEWED,
    outcome:  'SUCCESS',
    actor:    { userId, role },
    target:   { resourceType: 'student_report', resourceId: referenceId, schoolId },
    request:  { ip, path },
  });
}

/**
 * DATA_ACCESS: Document downloaded (signed URL generated)
 * (Data access trail — every download is recorded)
 */
export function logDocumentDownloaded({ userId, role, referenceId, fieldName, schoolId, ip }) {
  return writeAuditLog({
    category: AUDIT_CATEGORY.DATA_ACCESS,
    action:   AUDIT_ACTION.DOCUMENT_DOWNLOADED,
    outcome:  'SUCCESS',
    actor:    { userId, role },
    target:   { resourceType: 'document', resourceId: referenceId, schoolId },
    request:  { ip },
    metadata: { fieldName },   // e.g. 'std10FilePath' — not the S3 key
  });
}

/**
 * PRIVILEGE: Admin changed user role
 * (Privilege monitoring — always alerted)
 */
export function logRoleChanged({ adminUserId, targetUserId, previousRole, newRole, ip }) {
  return writeAuditLog({
    category:      AUDIT_CATEGORY.PRIVILEGE,
    action:        AUDIT_ACTION.ROLE_CHANGED,
    outcome:       'SUCCESS',
    actor:         { userId: adminUserId, role: 'admin' },
    target:        {
      resourceType:  'user',
      resourceId:    targetUserId,
      previousValue: previousRole,
      newValue:      newRole,
    },
    request:       { ip },
    alert:         true,
    alertSeverity: ALERT_SEVERITY.HIGH,
  });
}

/**
 * DATA_EXPORT: Bulk export initiated
 * (Data leakage risk — always alerted)
 */
export function logBulkExport({ userId, role, exportType, rowCount, filters, ip }) {
  const isLargeExport = rowCount > parseInt(process.env.BULK_EXPORT_ALERT_ROWS || '100', 10);
  return writeAuditLog({
    category:      AUDIT_CATEGORY.DATA_EXPORT,
    action:        AUDIT_ACTION.BULK_EXPORT,
    outcome:       'SUCCESS',
    actor:         { userId, role },
    request:       { ip },
    metadata:      { exportType, rowCount, filters },  // filters are non-PII config
    alert:         isLargeExport,
    alertSeverity: ALERT_SEVERITY.HIGH,
  });
}

/**
 * SECURITY: Failed access / IDOR attempt
 * (Attack detection — always alerted)
 */
export function logFailedAccessAttempt({ userId, ip, path, method, reason, userAgent }) {
  return writeAuditLog({
    category:      AUDIT_CATEGORY.SECURITY,
    action:        AUDIT_ACTION.FAILED_ACCESS_ATTEMPT,
    outcome:       'BLOCKED',
    actor:         { userId },
    request:       { ip, path, method, userAgent },
    metadata:      { reason },  // e.g. 'idor_check_failed', 'role_insufficient'
    alert:         true,
    alertSeverity: ALERT_SEVERITY.HIGH,
  });
}

/**
 * SECURITY: IDOR attempt specifically
 */
export function logIdorAttempt({ userId, role, referenceId, ip, path }) {
  return writeAuditLog({
    category:      AUDIT_CATEGORY.SECURITY,
    action:        AUDIT_ACTION.IDOR_ATTEMPT,
    outcome:       'BLOCKED',
    actor:         { userId, role },
    target:        { resourceId: referenceId },
    request:       { ip, path },
    alert:         true,
    alertSeverity: ALERT_SEVERITY.CRITICAL,
  });
}

/**
 * CONSENT: Consent submitted (DPDP compliance)
 */
export function logConsentSubmitted({ userId, referenceId, consentType, ip, userAgent }) {
  return writeAuditLog({
    category: AUDIT_CATEGORY.CONSENT,
    action:   AUDIT_ACTION.CONSENT_SUBMITTED,
    outcome:  'SUCCESS',
    actor:    { userId },
    target:   { resourceId: referenceId },
    request:  { ip, userAgent },
    metadata: { consentType },  // e.g. 'counselling', 'document', 'parent'
  });
}

/**
 * CONSENT: Consent withdrawn (DPDP compliance)
 */
export function logConsentWithdrawn({ userId, referenceId, consentType, ip }) {
  return writeAuditLog({
    category:      AUDIT_CATEGORY.CONSENT,
    action:        AUDIT_ACTION.CONSENT_WITHDRAWN,
    outcome:       'SUCCESS',
    actor:         { userId },
    target:        { resourceId: referenceId },
    request:       { ip },
    metadata:      { consentType },
    alert:         true,
    alertSeverity: ALERT_SEVERITY.MEDIUM,
  });
}

/**
 * ERASURE: DPDP right-to-erasure completed
 */
export function logErasureCompleted({ adminUserId, referenceId, filesDeleted, ip }) {
  return writeAuditLog({
    category:      AUDIT_CATEGORY.ERASURE,
    action:        AUDIT_ACTION.ERASURE_COMPLETED,
    outcome:       'SUCCESS',
    actor:         { userId: adminUserId, role: 'admin' },
    target:        { resourceId: referenceId },
    request:       { ip },
    metadata:      { filesDeleted },
    alert:         true,
    alertSeverity: ALERT_SEVERITY.MEDIUM,
  });
}
