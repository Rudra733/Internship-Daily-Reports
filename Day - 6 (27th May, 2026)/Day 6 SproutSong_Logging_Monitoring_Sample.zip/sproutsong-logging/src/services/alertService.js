/**
 * services/alertService.js — Security alert notifications
 *
 * Sends real-time alerts for high-severity audit events to:
 *   - Slack webhook (team notification)
 *   - PagerDuty (on-call escalation for critical events)
 *
 * Events that always trigger alerts (from Part H):
 *   - CRITICAL: IDOR attempt detected
 *   - CRITICAL: Virus detected in upload
 *   - HIGH:     Login failure threshold exceeded (brute force)
 *   - HIGH:     Admin role changed
 *   - HIGH:     Bulk export of sensitive data (>100 rows)
 *   - MEDIUM:   Consent withdrawn
 *   - MEDIUM:   DPDP erasure completed
 *
 * Brute-force detection:
 *   Tracks failed login counts per IP in an in-memory window.
 *   In production, replace with Redis for multi-instance support.
 */

import axios from 'axios';
import { logger } from '../utils/logger.js';

export const ALERT_SEVERITY = {
  LOW:      'LOW',
  MEDIUM:   'MEDIUM',
  HIGH:     'HIGH',
  CRITICAL: 'CRITICAL',
};

// Emoji and color per severity (for Slack formatting)
const SEVERITY_META = {
  LOW:      { emoji: '🔵', color: '#36a64f' },
  MEDIUM:   { emoji: '🟡', color: '#e6a817' },
  HIGH:     { emoji: '🟠', color: '#e67e22' },
  CRITICAL: { emoji: '🔴', color: '#a32d2d' },
};

// ── Brute-force tracking (in-memory — use Redis in production) ────────────────
const failedLoginMap = new Map(); // key: IP → { count, firstSeen }

const FAILED_LOGIN_THRESHOLD    = parseInt(process.env.FAILED_LOGIN_THRESHOLD    || '5',  10);
const FAILED_LOGIN_WINDOW_MS    = parseInt(process.env.FAILED_LOGIN_WINDOW_MINUTES || '15', 10) * 60 * 1000;

/**
 * Tracks a failed login attempt and returns true if the threshold is exceeded.
 * @param {string} ip
 * @returns {boolean} true if alert should be sent
 */
export function trackFailedLogin(ip) {
  const now = Date.now();
  const existing = failedLoginMap.get(ip);

  if (!existing || (now - existing.firstSeen) > FAILED_LOGIN_WINDOW_MS) {
    // New window
    failedLoginMap.set(ip, { count: 1, firstSeen: now });
    return false;
  }

  existing.count += 1;

  // Clean old entries periodically (simple GC)
  if (failedLoginMap.size > 10000) {
    for (const [key, val] of failedLoginMap.entries()) {
      if (now - val.firstSeen > FAILED_LOGIN_WINDOW_MS) failedLoginMap.delete(key);
    }
  }

  return existing.count >= FAILED_LOGIN_THRESHOLD;
}

/**
 * Resets the failed login counter for an IP (on successful login).
 * @param {string} ip
 */
export function resetFailedLoginCount(ip) {
  failedLoginMap.delete(ip);
}

// ── Main alert dispatcher ─────────────────────────────────────────────────────

/**
 * Dispatches a security alert to configured channels.
 * Called by auditLogger.js — never call directly from routes.
 *
 * @param {object} params
 * @param {string} params.category
 * @param {string} params.action
 * @param {string} params.outcome
 * @param {object} params.entry    - The full audit log entry (already sanitised)
 * @param {string} params.severity - ALERT_SEVERITY value
 */
export async function triggerAlert({ category, action, outcome, entry, severity }) {
  const { emoji, color } = SEVERITY_META[severity] || SEVERITY_META.MEDIUM;

  const alertPayload = {
    title:     `${emoji} [${severity}] SproutSong Security Alert`,
    action,
    category,
    outcome,
    severity,
    userId:    entry.actor?.userId    || 'unauthenticated',
    role:      entry.actor?.role      || 'unknown',
    ip:        entry.request?.ip      || 'unknown',
    path:      entry.request?.path    || 'unknown',
    resourceId:entry.target?.resourceId || null,
    timestamp: entry.timestamp,
    // Never include email, phone, or any PII in the alert
  };

  await Promise.allSettled([
    sendSlackAlert(alertPayload, color),
    severity === ALERT_SEVERITY.CRITICAL ? sendPagerDutyAlert(alertPayload) : Promise.resolve(),
  ]);
}

// ── Slack ─────────────────────────────────────────────────────────────────────

async function sendSlackAlert(payload, color) {
  const webhookUrl = process.env.SLACK_WEBHOOK_URL;
  if (!webhookUrl) {
    logger.debug('Slack alert skipped — SLACK_WEBHOOK_URL not configured');
    return;
  }

  const body = {
    attachments: [{
      color,
      fallback: `${payload.title}: ${payload.action}`,
      blocks: [
        {
          type: 'header',
          text: { type: 'plain_text', text: payload.title },
        },
        {
          type: 'section',
          fields: [
            { type: 'mrkdwn', text: `*Action:*\n${payload.action}` },
            { type: 'mrkdwn', text: `*Category:*\n${payload.category}` },
            { type: 'mrkdwn', text: `*Outcome:*\n${payload.outcome}` },
            { type: 'mrkdwn', text: `*Severity:*\n${payload.severity}` },
            { type: 'mrkdwn', text: `*User ID:*\n${payload.userId}` },
            { type: 'mrkdwn', text: `*Role:*\n${payload.role}` },
            { type: 'mrkdwn', text: `*IP Address:*\n${payload.ip}` },
            { type: 'mrkdwn', text: `*Path:*\n${payload.path}` },
            payload.resourceId
              ? { type: 'mrkdwn', text: `*Resource ID:*\n${payload.resourceId}` }
              : { type: 'mrkdwn', text: `*Timestamp:*\n${payload.timestamp}` },
          ],
        },
        {
          type: 'context',
          elements: [{ type: 'mrkdwn', text: `SproutSong Security • ${new Date(payload.timestamp).toISOString()}` }],
        },
      ],
    }],
  };

  try {
    await axios.post(webhookUrl, body, { timeout: 5000 });
    logger.debug('Slack alert sent', { action: payload.action, severity: payload.severity });
  } catch (err) {
    logger.error('Slack alert failed', { error: err.message });
  }
}

// ── PagerDuty ─────────────────────────────────────────────────────────────────

async function sendPagerDutyAlert(payload) {
  const routingKey = process.env.PAGERDUTY_ROUTING_KEY;
  if (!routingKey) {
    logger.debug('PagerDuty alert skipped — PAGERDUTY_ROUTING_KEY not configured');
    return;
  }

  const body = {
    routing_key:  routingKey,
    event_action: 'trigger',
    dedup_key:    `sproutsong-${payload.action}-${payload.ip}-${Date.now()}`,
    payload: {
      summary:   `[CRITICAL] ${payload.action} — SproutSong`,
      severity:  'critical',
      source:    'sproutsong-security',
      timestamp: new Date(payload.timestamp).toISOString(),
      custom_details: {
        action:     payload.action,
        category:   payload.category,
        userId:     payload.userId,
        ip:         payload.ip,
        resourceId: payload.resourceId || 'N/A',
        // Never include PII in PagerDuty payload
      },
    },
  };

  try {
    await axios.post('https://events.pagerduty.com/v2/enqueue', body, { timeout: 5000 });
    logger.info('PagerDuty alert triggered', { action: payload.action });
  } catch (err) {
    logger.error('PagerDuty alert failed', { error: err.message });
  }
}
