/**
 * middleware/auth.js — JWT authentication + role guard
 * (Same as file-upload sample — included here for standalone use)
 */

import jwt from 'jsonwebtoken';
import { logger } from '../utils/logger.js';

export function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authentication required.' });
  }
  const token = authHeader.split(' ')[1];
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch (err) {
    logger.warn('JWT verification failed', { ip: req.ip, error: err.message });
    return res.status(401).json({ message: 'Invalid or expired token.' });
  }
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ message: 'Authentication required.' });
    if (!roles.includes(req.user.role)) {
      logger.warn('Unauthorised role access', {
        userId: req.user.userId, role: req.user.role, needed: roles, path: req.path,
      });
      return res.status(403).json({ message: 'Access denied.' });
    }
    next();
  };
}
