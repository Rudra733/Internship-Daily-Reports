/**
 * middleware/auditMiddleware.js — Automatic request audit logging
 *
 * Three middleware functions:
 *
 *   1. requestAuditMiddleware    — Attaches request context to res.locals for downstream use
 *   2. authAuditMiddleware       — Logs failed authentication attempts automatically
 *   3. sensitiveRouteAudit(type) — Factory: wraps specific routes to log data-access events
 *
 * Usage in routes:
 *   // Auto log every request context:
 *   app.use(requestAuditMiddleware);
 *
 *   // Log student report access:
 *   router.get('/report/:id', authMiddleware, sensitiveRouteAudit('student_report'), handler);
 *
 *   // Log document download:
 *   router.get('/files/:id/:field', authMiddleware, sensitiveRouteAudit('document'), handler);
 */

import {
  writeAuditLog,
  logFailedAccessAttempt,
  AUDIT_CATEGORY,
  AUDIT_ACTION,
} from '../services/auditLogger.js';
import { logger } from '../utils/logger.js';

// ── 1. Request context middleware ─────────────────────────────────────────────
/**
 * Attaches a standardised request context to res.locals.
 * Downstream audit calls use res.locals.auditContext instead of re-reading req.
 * Must be added AFTER authMiddleware so req.user is already populated.
 */
export function requestAuditMiddleware(req, res, next) {
  res.locals.auditContext = {
    ip:        req.ip,
    userAgent: req.headers['user-agent'] || '',
    method:    req.method,
    path:      req.originalUrl || req.path,
    userId:    req.user?.userId   || null,
    role:      req.user?.role     || null,
    email:     req.user?.email    || null,  // Will be masked by auditLogger before DB write
  };
  next();
}

// ── 2. Auth audit middleware ──────────────────────────────────────────────────
/**
 * Wraps a response to log auth-related audit events automatically.
 * Intercepts 401/403 responses and logs them as FAILED_ACCESS_ATTEMPT.
 *
 * Attach AFTER authMiddleware:
 *   router.post('/login', authAuditMiddleware, loginHandler);
 */
export function authAuditMiddleware(req, res, next) {
  const originalJson = res.json.bind(res);

  res.json = function (body) {
    const ctx = res.locals.auditContext || {};

    if (res.statusCode === 401 || res.statusCode === 403) {
      // Log failed access without blocking the response
      logFailedAccessAttempt({
        userId:    ctx.userId,
        ip:        ctx.ip,
        path:      ctx.path,
        method:    ctx.method,
        reason:    body?.message || `HTTP ${res.statusCode}`,
        userAgent: ctx.userAgent,
      }).catch(() => {});
    }

    return originalJson(body);
  };

  next();
}

// ── 3. Sensitive route audit factory ─────────────────────────────────────────
/**
 * Returns middleware that logs a DATA_ACCESS event when a specific route is hit.
 *
 * @param {'student_report'|'document'|'record'} resourceType
 * @param {Function} [getResourceId] - Optional: extract resource ID from req (default: req.params.referenceId)
 *
 * Usage:
 *   router.get('/report/:referenceId', authMiddleware, sensitiveRouteAudit('student_report'), handler);
 */
export function sensitiveRouteAudit(resourceType, getResourceId) {
  return async (req, res, next) => {
    const ctx         = res.locals.auditContext || {};
    const resourceId  = getResourceId ? getResourceId(req) : req.params.referenceId || req.params.id;
    const fieldName   = req.params.fieldName || req.params.field || null;

    const actionMap = {
      student_report: AUDIT_ACTION.STUDENT_REPORT_VIEWED,
      document:       AUDIT_ACTION.DOCUMENT_DOWNLOADED,
      record:         AUDIT_ACTION.RECORD_VIEWED,
    };
    const action = actionMap[resourceType] || AUDIT_ACTION.RECORD_VIEWED;

    try {
      await writeAuditLog({
        category: AUDIT_CATEGORY.DATA_ACCESS,
        action,
        outcome:  'SUCCESS',
        actor:    { userId: ctx.userId, role: ctx.role },
        target:   {
          resourceType,
          resourceId,
          schoolId: req.user?.schoolId || null,
        },
        request:  { ip: ctx.ip, path: ctx.path, method: ctx.method },
        metadata: fieldName ? { fieldName } : {},
      });
    } catch (err) {
      // Never block the request due to audit log failure
      logger.error('sensitiveRouteAudit failed', { error: err.message });
    }

    next();
  };
}

// ── 4. Admin action audit middleware ──────────────────────────────────────────
/**
 * Logs admin actions (role changes, bulk operations, settings changes).
 * Attach to admin-only routes.
 */
export function adminActionAudit(action) {
  return async (req, res, next) => {
    const ctx        = res.locals.auditContext || {};
    const originalJson = res.json.bind(res);

    res.json = function (body) {
      if (res.statusCode >= 200 && res.statusCode < 300) {
        writeAuditLog({
          category: AUDIT_CATEGORY.ADMIN,
          action,
          outcome:  'SUCCESS',
          actor:    { userId: ctx.userId, role: ctx.role },
          request:  { ip: ctx.ip, path: ctx.path, method: ctx.method },
          metadata: { targetId: req.params.id || req.params.referenceId },
        }).catch(() => {});
      }
      return originalJson(body);
    };

    next();
  };
}
