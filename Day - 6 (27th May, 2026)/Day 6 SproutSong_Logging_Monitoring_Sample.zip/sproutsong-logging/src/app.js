/**
 * SproutSong — Part H: Logging & Monitoring Sample
 * app.js — Express application entry point
 */

import 'dotenv/config';
import express         from 'express';
import helmet          from 'helmet';
import mongoSanitize   from 'express-mongo-sanitize';
import mongoose        from 'mongoose';

import { logger }              from './utils/logger.js';
import { startSecurityMonitor } from './services/securityMonitor.js';
import { requestAuditMiddleware } from './middleware/auditMiddleware.js';

import authRoutes    from './routes/auth.routes.js';
import auditRoutes   from './routes/audit.routes.js';

const app = express();

app.use(helmet());
app.use(express.json({ limit: '1mb' }));
app.use(mongoSanitize());

// Attach audit context to every request
app.use(requestAuditMiddleware);

app.use('/api/auth',  authRoutes);
app.use('/api/audit', auditRoutes);

app.get('/health', (req, res) => res.json({ status: 'ok', service: 'sproutsong-logging' }));

app.use((err, req, res, next) => {
  logger.error('Unhandled error', { message: err.message, path: req.path });
  res.status(500).json({ message: 'An error occurred.' });
});

const PORT = process.env.PORT || 3001;

mongoose.connect(process.env.MONGO_URI).then(() => {
  logger.info('MongoDB connected');
  startSecurityMonitor();
  app.listen(PORT, () => logger.info(`Logging service running on port ${PORT}`));
}).catch(err => {
  logger.error('Startup failed', { error: err.message });
  process.exit(1);
});

export default app;
