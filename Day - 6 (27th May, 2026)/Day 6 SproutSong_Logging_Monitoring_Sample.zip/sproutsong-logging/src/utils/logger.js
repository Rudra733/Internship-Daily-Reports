/**
 * utils/logger.js — Core application logger (Winston)
 *
 * This logger handles APPLICATION logs (errors, info, debug).
 * For AUDIT logs (who accessed what), see services/auditLogger.js.
 *
 * DPDP / Security rules enforced here:
 *   1. PII fields are automatically masked before any log is written
 *   2. Passwords, OTPs, full tokens are stripped entirely
 *   3. Full Aadhaar / Govt IDs are masked (show last 4 only)
 *   4. Full student counselling notes never appear in error logs
 *   5. Payment card details stripped
 *   6. Private document URLs / S3 keys never logged
 *
 * From the guide (Part H — What Should NOT Be Logged):
 *   ✗ Passwords
 *   ✗ OTPs
 *   ✗ Full tokens
 *   ✗ Full Aadhaar / Govt ID
 *   ✗ Full student counselling notes in error logs
 *   ✗ Payment card details
 *   ✗ Private document URLs if public
 *
 * Transports:
 *   - Console (all envs)
 *   - Daily rotating file: logs/app-YYYY-MM-DD.log (production)
 *   - Daily rotating file: logs/error-YYYY-MM-DD.log (errors only, production)
 */

import { createLogger, format, transports } from 'winston';
import DailyRotateFile from 'winston-daily-rotate-file';
import path from 'path';

// ── PII field masking ─────────────────────────────────────────────────────────

/**
 * Fields whose values are masked to first 3 chars + "***"
 * e.g.  "john.doe@example.com" → "joh***"
 */
const MASK_FIELDS = new Set([
  'email', 'schoolEmail', 'contactEmail', 'fatherEmail', 'motherEmail',
  'phone', 'mobile', 'schoolPhone', 'primaryContact', 'altMobile',
  'fatherContact', 'motherContact',
  'name', 'fullName', 'contactPerson', 'fatherName', 'motherName',
  'username',
]);

/**
 * Fields that are STRIPPED entirely from logs (replaced with "[REDACTED]")
 * These must never appear in any log output.
 */
const STRIP_FIELDS = new Set([
  // From "What Should Not Be Logged" in the guide:
  'password', 'passwordHash', 'hashedPassword', 'newPassword', 'oldPassword',
  'otp', 'otpCode', 'otpHash',
  'token', 'accessToken', 'refreshToken', 'resetToken', 'jwtToken',
  'aadhaar', 'aadhaarNumber', 'govtId', 'panNumber', 'passport',
  'counsellingNotes', 'studentNotes', 'adminNotes', 'sessionNotes',
  'cardNumber', 'cvv', 'cardExpiry', 'paymentDetails',
  // S3 keys / private file paths
  'std8FilePath', 'std9FilePath', 'std10FilePath', 'std11FilePath', 'std12FilePath',
  'photoPath', 's3Key', 'fileKey', 'signedUrl',
  // Financial data
  'fatherIncome', 'motherIncome', 'budget',
]);

/**
 * Recursively sanitise a log metadata object.
 * Masks PII, strips sensitive fields, handles nested objects and arrays.
 */
export function sanitiseLogMeta(obj, depth = 0) {
  if (depth > 6 || obj === null || obj === undefined) return obj;
  if (typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(item => sanitiseLogMeta(item, depth + 1));

  const cleaned = {};
  for (const [key, value] of Object.entries(obj)) {
    const lowerKey = key.toLowerCase();

    if (STRIP_FIELDS.has(key) || STRIP_FIELDS.has(lowerKey)) {
      cleaned[key] = '[REDACTED]';
    } else if (MASK_FIELDS.has(key) || MASK_FIELDS.has(lowerKey)) {
      if (typeof value === 'string' && value.length > 0) {
        cleaned[key] = value.slice(0, 3) + '***';
      } else {
        cleaned[key] = value ? '***' : value;
      }
    } else if (typeof value === 'object') {
      cleaned[key] = sanitiseLogMeta(value, depth + 1);
    } else if (typeof value === 'string') {
      // Mask anything that looks like a JWT (three base64 segments separated by dots)
      if (/^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(value)) {
        cleaned[key] = value.slice(0, 10) + '...[TOKEN]';
      }
      // Mask Aadhaar-like numbers (12 digits)
      else if (/^\d{12}$/.test(value)) {
        cleaned[key] = 'XXXX-XXXX-' + value.slice(-4);
      }
      else {
        cleaned[key] = value;
      }
    } else {
      cleaned[key] = value;
    }
  }
  return cleaned;
}

// ── Winston format ────────────────────────────────────────────────────────────
const piiSafeFormat = format((info) => {
  // Sanitise the splat (additional metadata args)
  if (info[Symbol.for('splat')]) {
    info[Symbol.for('splat')] = info[Symbol.for('splat')].map(s =>
      typeof s === 'object' ? sanitiseLogMeta(s) : s
    );
  }
  // Sanitise direct metadata properties on the log object
  const { level, message, timestamp, stack, ...meta } = info;
  const cleanMeta = sanitiseLogMeta(meta);
  return { level, message, timestamp, stack, ...cleanMeta };
});

const LOG_DIR = process.env.LOG_DIR || './logs';
const isProduction = process.env.NODE_ENV === 'production';

const logTransports = [
  // Always log to console
  new transports.Console({
    format: format.combine(
      format.colorize(),
      format.printf(({ level, message, timestamp, ...meta }) => {
        const metaStr = Object.keys(meta).length
          ? ' ' + JSON.stringify(meta, null, 0)
          : '';
        return `${timestamp} [${level}] ${message}${metaStr}`;
      })
    ),
  }),
];

if (isProduction) {
  // Rotating file: all logs — retain 90 days
  logTransports.push(
    new DailyRotateFile({
      filename:      path.join(LOG_DIR, 'app-%DATE%.log'),
      datePattern:   'YYYY-MM-DD',
      zippedArchive: true,
      maxFiles:      `${process.env.LOG_RETENTION_DAYS || 90}d`,
      level:         'info',
      format:        format.json(),
    })
  );

  // Rotating file: errors only — retain 90 days
  logTransports.push(
    new DailyRotateFile({
      filename:      path.join(LOG_DIR, 'error-%DATE%.log'),
      datePattern:   'YYYY-MM-DD',
      zippedArchive: true,
      maxFiles:      `${process.env.LOG_RETENTION_DAYS || 90}d`,
      level:         'error',
      format:        format.json(),
    })
  );
}

export const logger = createLogger({
  level: isProduction ? 'info' : 'debug',
  format: format.combine(
    piiSafeFormat(),
    format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    format.errors({ stack: true }),
    format.json()
  ),
  transports: logTransports,
  // Prevent Winston from exiting on uncaught exceptions
  exitOnError: false,
});
