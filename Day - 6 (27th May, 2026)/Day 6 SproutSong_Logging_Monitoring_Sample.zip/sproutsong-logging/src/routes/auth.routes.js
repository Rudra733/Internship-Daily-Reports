/**
 * routes/auth.routes.js — Auth routes with integrated audit logging
 *
 * Shows exactly where and how each audit event is fired in a real auth flow.
 *
 * Events logged here:
 *   ✓ LOGIN_SUCCESS        — after successful credential check
 *   ✓ LOGIN_FAILURE        — on bad credentials or locked account
 *   ✓ LOGOUT               — on explicit logout
 *   ✓ PASSWORD_RESET_REQUEST — when reset is requested (NOT the token)
 *   ✓ PASSWORD_RESET_DONE   — after successful password change
 *
 * Note: This is a demonstration skeleton. Replace the credential check
 * with your actual user model lookup and bcrypt comparison.
 */

import { Router }    from 'express';
import { body, validationResult } from 'express-validator';
import jwt           from 'jsonwebtoken';
import {
  logLoginSuccess,
  logLoginFailure,
  logPasswordResetRequest,
  writeAuditLog,
  AUDIT_CATEGORY,
  AUDIT_ACTION,
}                    from '../services/auditLogger.js';
import {
  trackFailedLogin,
  resetFailedLoginCount,
}                    from '../services/alertService.js';
import { authMiddleware } from '../middleware/auth.js';
import { logger }    from '../utils/logger.js';

const router = Router();

// ── POST /api/auth/login ──────────────────────────────────────────────────────
router.post(
  '/login',
  [
    body('email').isEmail().normalizeEmail().trim(),
    body('password').isLength({ min: 8 }),
    // NEVER log the password field — it's validated here and discarded
  ],
  async (req, res, next) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        // Log failure — don't reveal which field failed
        await logLoginFailure({
          email:     req.body.email,
          ip:        req.ip,
          userAgent: req.headers['user-agent'],
          reason:    'validation_failed',
        });
        return res.status(422).json({ message: 'Invalid credentials.' });
      }

      const { email, password } = req.body;

      // ── Replace this block with your actual user lookup ───────────────────
      // const user = await User.findOne({ email });
      // const passwordMatch = user && await bcrypt.compare(password, user.passwordHash);
      const user          = email === 'demo@sproutsong.com' ? { userId: 'u-001', role: 'admin', email } : null;
      const passwordMatch = password === 'DemoPassword123!';
      // ─────────────────────────────────────────────────────────────────────

      if (!user || !passwordMatch) {
        // Track failed attempt for brute-force detection
        const thresholdExceeded = trackFailedLogin(req.ip);

        // Always log the failure — NEVER log the attempted password
        await logLoginFailure({
          email,     // Masked automatically by auditLogger (joh***)
          ip:        req.ip,
          userAgent: req.headers['user-agent'],
          reason:    'invalid_credentials',
        });

        if (thresholdExceeded) {
          logger.warn('Brute-force threshold exceeded', { ip: req.ip });
          // In production: temporarily block this IP or trigger CAPTCHA
        }

        // Generic response — never reveal whether email exists
        return res.status(401).json({ message: 'Invalid credentials.' });
      }

      // Success — reset failed login counter, issue JWT
      resetFailedLoginCount(req.ip);

      const token = jwt.sign(
        { userId: user.userId, role: user.role, email: user.email },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
      );

      await logLoginSuccess({
        userId:    user.userId,
        role:      user.role,
        email:     user.email,  // Masked before DB write
        ip:        req.ip,
        userAgent: req.headers['user-agent'],
      });

      // NEVER log the JWT token itself
      res.json({
        message: 'Login successful.',
        token,   // Returned to client — not logged
        role:    user.role,
      });
    } catch (err) {
      next(err);
    }
  }
);

// ── POST /api/auth/logout ─────────────────────────────────────────────────────
router.post('/logout', authMiddleware, async (req, res, next) => {
  try {
    await writeAuditLog({
      category: AUDIT_CATEGORY.AUTH,
      action:   AUDIT_ACTION.LOGOUT,
      outcome:  'SUCCESS',
      actor:    { userId: req.user.userId, role: req.user.role },
      request:  { ip: req.ip },
    });

    // In a stateful session setup, invalidate the session here.
    // For JWT: client discards the token. Consider a token blocklist for sensitive apps.
    res.json({ message: 'Logged out successfully.' });
  } catch (err) {
    next(err);
  }
});

// ── POST /api/auth/password-reset/request ────────────────────────────────────
router.post(
  '/password-reset/request',
  [body('email').isEmail().normalizeEmail().trim()],
  async (req, res, next) => {
    try {
      const { email } = req.body;

      await logPasswordResetRequest({
        userId: null,   // Not authenticated yet
        email,          // Masked by auditLogger before DB write
        ip:     req.ip,
        // NEVER log the reset token — it's generated and emailed separately
      });

      // Always return the same message regardless of whether email exists
      // This prevents email enumeration attacks
      res.json({ message: 'If that email is registered, a reset link has been sent.' });
    } catch (err) {
      next(err);
    }
  }
);

// ── POST /api/auth/password-reset/complete ───────────────────────────────────
router.post(
  '/password-reset/complete',
  [
    body('token').isString().isLength({ min: 32 }),
    body('newPassword').isLength({ min: 8 }),
  ],
  async (req, res, next) => {
    try {
      // Verify the reset token (replace with your actual token verification)
      const { token, newPassword } = req.body;

      // ── Replace with actual token verification ────────────────────────────
      // const resetRecord = await PasswordReset.findOne({ token, expiresAt: { $gte: new Date() } });
      // if (!resetRecord) return res.status(400).json({ message: 'Invalid or expired reset link.' });
      // await bcrypt.hash(newPassword) → update user.passwordHash
      // await PasswordReset.deleteOne({ token });
      const userId = 'u-001'; // Replace with actual user lookup
      // ─────────────────────────────────────────────────────────────────────

      await writeAuditLog({
        category: AUDIT_CATEGORY.AUTH,
        action:   AUDIT_ACTION.PASSWORD_RESET_DONE,
        outcome:  'SUCCESS',
        actor:    { userId },
        request:  { ip: req.ip },
        // NEVER log the token or the new password
      });

      res.json({ message: 'Password reset successfully. Please log in with your new password.' });
    } catch (err) {
      next(err);
    }
  }
);

export default router;
