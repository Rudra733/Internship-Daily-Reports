/**
 * routes/audit.routes.js — Admin audit log query API
 *
 * These routes allow the SproutSong security/admin team to:
 *   - Query the audit log by user, IP, category, action, date range
 *   - View the security monitoring summary
 *   - Export audit reports (with their own audit trail)
 *
 * All routes:
 *   - Require authentication (JWT)
 *   - Require 'admin' role
 *   - Are themselves audit-logged (meta-audit)
 *   - Never return PII fields that were stripped at log-write time
 *
 * Endpoints:
 *   GET  /api/audit/events          — Query audit events with filters
 *   GET  /api/audit/summary         — Counts by category/action/outcome
 *   GET  /api/audit/user/:userId    — Events for a specific user
 *   GET  /api/audit/ip/:ip          — Failed attempts for an IP
 *   GET  /api/audit/security-alerts — High/critical events in last 24h
 */

import { Router }  from 'express';
import { query, param, validationResult } from 'express-validator';
import AuditLog    from '../models/AuditLog.js';
import {
  getAuditSummary,
  getRecentEventsForUser,
  getFailedAttemptsForIp,
}                  from '../services/securityMonitor.js';
import {
  writeAuditLog,
  AUDIT_CATEGORY,
  AUDIT_ACTION,
}                  from '../services/auditLogger.js';
import { authMiddleware, requireRole } from '../middleware/auth.js';
import { logger }  from '../utils/logger.js';

const router = Router();

// All audit routes require admin role
router.use(authMiddleware, requireRole('admin'));

// ── GET /api/audit/events ─────────────────────────────────────────────────────
router.get(
  '/events',
  [
    query('category').optional().isString(),
    query('action').optional().isString(),
    query('outcome').optional().isIn(['SUCCESS', 'FAILURE', 'BLOCKED']),
    query('userId').optional().isString(),
    query('ip').optional().isIP(),
    query('from').optional().isISO8601(),
    query('to').optional().isISO8601(),
    query('limit').optional().isInt({ min: 1, max: 500 }).toInt(),
    query('skip').optional().isInt({ min: 0 }).toInt(),
  ],
  async (req, res, next) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) return res.status(422).json({ message: 'Invalid query parameters.' });

      const { category, action, outcome, userId, ip, from, to, limit = 100, skip = 0 } = req.query;

      const filter = {};
      if (category)  filter.category          = category;
      if (action)    filter.action             = action;
      if (outcome)   filter.outcome            = outcome;
      if (userId)    filter['actor.userId']    = userId;
      if (ip)        filter['request.ip']      = ip;
      if (from || to) {
        filter.timestamp = {};
        if (from) filter.timestamp.$gte = new Date(from);
        if (to)   filter.timestamp.$lte = new Date(to);
      }

      const [events, total] = await Promise.all([
        AuditLog.find(filter).sort({ timestamp: -1 }).skip(skip).limit(limit).lean(),
        AuditLog.countDocuments(filter),
      ]);

      // Meta-audit: log that an admin queried audit logs
      writeAuditLog({
        category: AUDIT_CATEGORY.ADMIN,
        action:   AUDIT_ACTION.RECORD_VIEWED,
        outcome:  'SUCCESS',
        actor:    { userId: req.user.userId, role: req.user.role },
        request:  { ip: req.ip, path: req.path },
        metadata: { queryFilters: { category, action, outcome, userId: userId ? 'provided' : null, ip: ip ? 'provided' : null }, resultCount: events.length },
      }).catch(() => {});

      res.json({ total, skip, limit, events });
    } catch (err) {
      next(err);
    }
  }
);

// ── GET /api/audit/summary ────────────────────────────────────────────────────
router.get('/summary', async (req, res, next) => {
  try {
    const windowHours = parseInt(req.query.hours || '24', 10);
    const summary = await getAuditSummary(windowHours);
    res.json({ windowHours, summary });
  } catch (err) {
    next(err);
  }
});

// ── GET /api/audit/user/:userId ───────────────────────────────────────────────
router.get(
  '/user/:userId',
  [param('userId').isString().isLength({ min: 1, max: 100 })],
  async (req, res, next) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) return res.status(422).json({ message: 'Invalid user ID.' });

      const limit  = Math.min(parseInt(req.query.limit || '50', 10), 500);
      const events = await getRecentEventsForUser(req.params.userId, limit);
      res.json({ userId: req.params.userId, count: events.length, events });
    } catch (err) {
      next(err);
    }
  }
);

// ── GET /api/audit/ip/:ip ─────────────────────────────────────────────────────
router.get(
  '/ip/:ip',
  [param('ip').isIP()],
  async (req, res, next) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) return res.status(422).json({ message: 'Invalid IP address.' });

      const windowMins = parseInt(req.query.windowMins || '60', 10);
      const events = await getFailedAttemptsForIp(req.params.ip, windowMins);
      res.json({ ip: req.params.ip, windowMins, count: events.length, events });
    } catch (err) {
      next(err);
    }
  }
);

// ── GET /api/audit/security-alerts ───────────────────────────────────────────
router.get('/security-alerts', async (req, res, next) => {
  try {
    const windowHours = parseInt(req.query.hours || '24', 10);
    const since = new Date(Date.now() - windowHours * 60 * 60 * 1000);

    const alerts = await AuditLog.find({
      timestamp: { $gte: since },
      $or: [
        { outcome: 'BLOCKED' },
        { outcome: 'FAILURE' },
        { action: { $in: [
          AUDIT_ACTION.IDOR_ATTEMPT,
          AUDIT_ACTION.VIRUS_DETECTED,
          AUDIT_ACTION.ROLE_CHANGED,
          AUDIT_ACTION.BULK_EXPORT,
          AUDIT_ACTION.SUSPICIOUS_ACTIVITY,
        ]}},
      ],
    })
      .sort({ timestamp: -1 })
      .limit(200)
      .lean();

    res.json({ windowHours, count: alerts.length, alerts });
  } catch (err) {
    next(err);
  }
});

export default router;
