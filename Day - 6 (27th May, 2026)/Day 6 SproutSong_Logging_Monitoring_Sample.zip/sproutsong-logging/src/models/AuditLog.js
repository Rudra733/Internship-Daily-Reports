/**
 * models/AuditLog.js — MongoDB audit log schema
 *
 * Stores structured audit events for every security-relevant action.
 * This collection is APPEND-ONLY — no update or delete operations
 * are ever run on it from application code.
 *
 * From Part H (What Should Be Logged):
 *   ✓ Login success / failure          → category: AUTH
 *   ✓ Password reset request           → category: AUTH
 *   ✓ Student report viewed            → category: DATA_ACCESS
 *   ✓ Document downloaded              → category: DATA_ACCESS
 *   ✓ Admin changed user role          → category: PRIVILEGE
 *   ✓ Bulk export                      → category: DATA_EXPORT
 *   ✓ Failed access attempts           → category: SECURITY
 *   ✓ Consent submitted / withdrawn    → category: CONSENT
 *
 * Security rules:
 *   1. strict: true — no unknown fields accepted
 *   2. No update/delete indexes — application only calls .create() / .insertMany()
 *   3. TTL index auto-deletes records older than AUDIT_LOG_RETENTION_DAYS (default 365)
 *   4. PII fields masked at insert time by auditLogger.js — schema stores masked values
 *   5. Indexed on userId, ip, category, and timestamp for fast security queries
 */

import mongoose from 'mongoose';

const { Schema } = mongoose;

// ── Event category enum ───────────────────────────────────────────────────────
export const AUDIT_CATEGORY = {
  AUTH:         'AUTH',           // Login, logout, password reset
  DATA_ACCESS:  'DATA_ACCESS',    // Report viewed, document downloaded
  PRIVILEGE:    'PRIVILEGE',      // Role changed, permission granted/revoked
  DATA_EXPORT:  'DATA_EXPORT',    // Bulk export, CSV download
  SECURITY:     'SECURITY',       // Failed attempts, blocked requests, IDOR attempts
  CONSENT:      'CONSENT',        // Consent submitted / withdrawn (DPDP)
  ERASURE:      'ERASURE',        // DPDP right-to-erasure requests and completions
  UPLOAD:       'UPLOAD',         // File uploaded, virus scan result
  ADMIN:        'ADMIN',          // Admin panel actions
};

// ── Event action enum ─────────────────────────────────────────────────────────
export const AUDIT_ACTION = {
  // AUTH
  LOGIN_SUCCESS:          'LOGIN_SUCCESS',
  LOGIN_FAILURE:          'LOGIN_FAILURE',
  LOGOUT:                 'LOGOUT',
  PASSWORD_RESET_REQUEST: 'PASSWORD_RESET_REQUEST',
  PASSWORD_RESET_DONE:    'PASSWORD_RESET_DONE',
  TOKEN_REFRESH:          'TOKEN_REFRESH',
  MFA_SUCCESS:            'MFA_SUCCESS',
  MFA_FAILURE:            'MFA_FAILURE',

  // DATA_ACCESS
  STUDENT_REPORT_VIEWED:  'STUDENT_REPORT_VIEWED',
  DOCUMENT_DOWNLOADED:    'DOCUMENT_DOWNLOADED',
  RECORD_VIEWED:          'RECORD_VIEWED',
  RECORD_UPDATED:         'RECORD_UPDATED',

  // PRIVILEGE
  ROLE_CHANGED:           'ROLE_CHANGED',
  PERMISSION_GRANTED:     'PERMISSION_GRANTED',
  PERMISSION_REVOKED:     'PERMISSION_REVOKED',
  USER_CREATED:           'USER_CREATED',
  USER_DEACTIVATED:       'USER_DEACTIVATED',

  // DATA_EXPORT
  BULK_EXPORT:            'BULK_EXPORT',
  CSV_DOWNLOAD:           'CSV_DOWNLOAD',
  REPORT_EXPORT:          'REPORT_EXPORT',

  // SECURITY
  FAILED_ACCESS_ATTEMPT:  'FAILED_ACCESS_ATTEMPT',
  IDOR_ATTEMPT:           'IDOR_ATTEMPT',
  RATE_LIMIT_HIT:         'RATE_LIMIT_HIT',
  BLOCKED_MIME_UPLOAD:    'BLOCKED_MIME_UPLOAD',
  VIRUS_DETECTED:         'VIRUS_DETECTED',
  SUSPICIOUS_ACTIVITY:    'SUSPICIOUS_ACTIVITY',

  // CONSENT
  CONSENT_SUBMITTED:      'CONSENT_SUBMITTED',
  CONSENT_WITHDRAWN:      'CONSENT_WITHDRAWN',
  PARENT_CONSENT_GIVEN:   'PARENT_CONSENT_GIVEN',

  // ERASURE
  ERASURE_REQUESTED:      'ERASURE_REQUESTED',
  ERASURE_COMPLETED:      'ERASURE_COMPLETED',

  // UPLOAD
  FILE_UPLOADED:          'FILE_UPLOADED',
  FILE_DELETED:           'FILE_DELETED',

  // ADMIN
  SETTINGS_CHANGED:       'SETTINGS_CHANGED',
  ADMIN_IMPERSONATION:    'ADMIN_IMPERSONATION',
};

// ── Schema ────────────────────────────────────────────────────────────────────
const auditLogSchema = new Schema(
  {
    // ── Event identity ───────────────────────────────────────────────────────
    eventId:    { type: String, required: true, unique: true }, // UUID v4 — dedup key
    category:   { type: String, required: true, enum: Object.values(AUDIT_CATEGORY) },
    action:     { type: String, required: true, enum: Object.values(AUDIT_ACTION) },
    outcome:    { type: String, required: true, enum: ['SUCCESS', 'FAILURE', 'BLOCKED'] },

    // ── Actor (who did it) ────────────────────────────────────────────────────
    actor: {
      userId:   { type: String, default: null },   // null for unauthenticated events
      role:     { type: String, default: null },
      // Email stored masked (e.g. "joh***") — PII rule
      emailMasked: { type: String, default: null },
    },

    // ── Target (what was acted upon) ─────────────────────────────────────────
    target: {
      resourceType: { type: String, default: null }, // 'student', 'document', 'user', etc.
      resourceId:   { type: String, default: null }, // referenceId — not the MongoDB _id
      schoolId:     { type: String, default: null },
      // For role changes: previous and new role
      previousValue:{ type: String, default: null },
      newValue:     { type: String, default: null },
    },

    // ── Request context ───────────────────────────────────────────────────────
    request: {
      ip:        { type: String, default: null },
      userAgent: { type: String, default: null, maxlength: 300 },
      method:    { type: String, default: null },
      path:      { type: String, default: null, maxlength: 500 },
    },

    // ── Additional metadata (must be pre-sanitised by auditLogger.js) ────────
    // IMPORTANT: PII must never be stored here. auditLogger sanitises before insert.
    metadata: {
      type:    Schema.Types.Mixed,
      default: {},
    },

    // ── Timestamp (immutable — set at insert time) ────────────────────────────
    timestamp: { type: Date, required: true, default: Date.now, immutable: true },
  },
  {
    strict:     true,
    timestamps: false,  // We manage timestamp ourselves (immutable field above)
    // Disable all update operations at the schema level
    // Application code must only call AuditLog.create() — never .save() on existing docs
    versionKey: false,
  }
);

// ── Indexes ───────────────────────────────────────────────────────────────────

// TTL: auto-delete audit logs after 365 days (DPDP retention policy)
auditLogSchema.index(
  { timestamp: 1 },
  { expireAfterSeconds: parseInt(process.env.AUDIT_LOG_RETENTION_DAYS || '365', 10) * 24 * 60 * 60 }
);

// Fast queries for security monitoring
auditLogSchema.index({ 'actor.userId': 1, timestamp: -1 });
auditLogSchema.index({ 'request.ip': 1, timestamp: -1 });
auditLogSchema.index({ category: 1, action: 1, timestamp: -1 });
auditLogSchema.index({ 'target.resourceId': 1 });
auditLogSchema.index({ outcome: 1, timestamp: -1 });

// ── Prevent updates and deletions at the model level ─────────────────────────
auditLogSchema.pre(['updateOne', 'updateMany', 'findOneAndUpdate', 'findOneAndDelete', 'deleteOne', 'deleteMany'], function () {
  throw new Error('AuditLog is append-only. Updates and deletions are not permitted.');
});

export default mongoose.model('AuditLog', auditLogSchema);
