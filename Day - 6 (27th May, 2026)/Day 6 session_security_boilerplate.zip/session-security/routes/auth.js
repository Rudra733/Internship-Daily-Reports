'use strict';

/**
 * ============================================================
 *  routes/auth.js
 *
 *  All auth routes with rate limiters applied.
 *
 *  Register in app.js:
 *    app.use('/api/v1/auth', require('./routes/auth'));
 * ============================================================
 */

const express    = require('express');
const router     = express.Router();
const authenticate = require('../middleware/authenticate');
const { loginLimiter, otpLimiter, passwordResetLimiter, mfaLimiter } = require('../middleware/authRateLimits');
const { login, logout, refreshToken, forgotPassword, resetPassword } = require('../controllers/authController');
const { sendOtp, verifyOtpHandler, resendOtp } = require('../controllers/otpController');
const { setupMfaHandler, enableMfaHandler, disableMfaHandler, getMfaStatus } = require('../controllers/mfaController');

// ── Auth ──────────────────────────────────────────────────────
router.post('/login',          loginLimiter,         login);
router.post('/logout',         authenticate,         logout);
router.post('/refresh',        refreshToken);        // cookie carries refresh token
router.post('/forgot-password',passwordResetLimiter, forgotPassword);
router.post('/reset-password', passwordResetLimiter, resetPassword);

// ── OTP ───────────────────────────────────────────────────────
router.post('/otp/send',   otpLimiter, sendOtp);
router.post('/otp/verify', otpLimiter, verifyOtpHandler);
router.post('/otp/resend', otpLimiter, resendOtp);

// ── MFA (requires authentication) ────────────────────────────
router.get ('/mfa/status',  authenticate,              getMfaStatus);
router.post('/mfa/setup',   authenticate,              setupMfaHandler);
router.post('/mfa/enable',  authenticate, mfaLimiter,  enableMfaHandler);
router.post('/mfa/disable', authenticate, mfaLimiter,  disableMfaHandler);

module.exports = router;
