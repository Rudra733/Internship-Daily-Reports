#!/usr/bin/env node
'use strict';

/**
 * scripts/generateKeys.js
 * Generates all cryptographic keys needed for .env.
 * Usage: node scripts/generateKeys.js
 */

const crypto = require('crypto');

const hex32  = () => crypto.randomBytes(32).toString('hex');
const base64 = () => crypto.randomBytes(48).toString('base64url');

console.log('\n============================================================');
console.log('  SproutSong — Session Security Key Generator');
console.log('  Copy these into your .env file.');
console.log('  NEVER commit these to source control.');
console.log('============================================================\n');

console.log('# JWT secret (32+ random chars)');
console.log(`JWT_SECRET=${base64()}\n`);

console.log('# AES-256-GCM key for MFA secret encryption (64-char hex = 32 bytes)');
console.log(`FIELD_ENCRYPTION_KEY=${hex32()}\n`);

console.log('============================================================');
console.log('  Rotate JWT_SECRET every 6 months.');
console.log('  Rotating JWT_SECRET invalidates ALL active sessions.');
console.log('  Plan a maintenance window and notify users.');
console.log('============================================================\n');
