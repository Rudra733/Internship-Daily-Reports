'use strict';

/**
 * ============================================================
 *  middleware/authRateLimits.js
 *
 *  Rate limiters specifically for auth endpoints.
 *  Import and apply to the relevant routes.
 *
 *  loginLimiter     — max 10 attempts per 15 min per IP
 *  otpLimiter       — max 5 OTP requests per 10 min per IP+userId
 *  passwordResetLimiter — max 3 resets per hour per IP
 * ============================================================
 */

const rateLimit = require('express-rate-limit');

// ── Login rate limiter ────────────────────────────────────────
const loginLimiter = rateLimit({
  windowMs:         15 * 60 * 1000, // 15 minutes
  max:              10,
  standardHeaders:  true,
  legacyHeaders:    false,
  // Key by IP address
  keyGenerator:     (req) => req.ip,
  message: {
    success: false,
    code:    'RATE_LIMITED',
    message: 'Too many login attempts. Please try again in 15 minutes.',
  },
  skip: (req) => process.env.NODE_ENV === 'test',
});

// ── OTP request limiter ───────────────────────────────────────
const otpLimiter = rateLimit({
  windowMs:        10 * 60 * 1000, // 10 minutes
  max:             5,
  standardHeaders: true,
  legacyHeaders:   false,
  // Key by IP + userId (if available) to prevent IP-hopping
  keyGenerator:    (req) => `${req.ip}:${req.user?.id || req.body?.userId || 'anon'}`,
  message: {
    success: false,
    code:    'RATE_LIMITED',
    message: 'Too many OTP requests. Please wait before requesting another.',
  },
  skip: (req) => process.env.NODE_ENV === 'test',
});

// ── Password reset limiter ────────────────────────────────────
const passwordResetLimiter = rateLimit({
  windowMs:        60 * 60 * 1000, // 1 hour
  max:             3,
  standardHeaders: true,
  legacyHeaders:   false,
  keyGenerator:    (req) => req.ip,
  message: {
    success: false,
    code:    'RATE_LIMITED',
    message: 'Too many password reset requests. Please try again in an hour.',
  },
  skip: (req) => process.env.NODE_ENV === 'test',
});

// ── MFA verify limiter ────────────────────────────────────────
const mfaLimiter = rateLimit({
  windowMs:        5 * 60 * 1000, // 5 minutes
  max:             10,
  standardHeaders: true,
  legacyHeaders:   false,
  keyGenerator:    (req) => `${req.ip}:${req.user?.id || 'anon'}`,
  message: {
    success: false,
    code:    'RATE_LIMITED',
    message: 'Too many MFA attempts. Please wait 5 minutes.',
  },
  skip: (req) => process.env.NODE_ENV === 'test',
});

module.exports = { loginLimiter, otpLimiter, passwordResetLimiter, mfaLimiter };
