'use strict';

/**
 * ============================================================
 *  middleware/authenticate.js
 *
 *  JWT authentication middleware — runs on every protected route.
 *
 *  Chain of checks:
 *   1. Extract token from HttpOnly cookie or Authorization header
 *   2. Verify JWT signature + expiry
 *   3. Check jti blacklist (Redis or MongoDB)
 *   4. Load user from DB (confirms user still exists + active)
 *   5. Compare tokenVersion (catches logout / role change)
 *   6. Attach req.user for downstream middleware
 * ============================================================
 */

const { verifyAccessToken, isBlacklisted } = require('../utils/tokenService');
const User = require('../models/User');

const deny = (res, status, code, message) =>
  res.status(status).json({ success: false, code, message });

const authenticate = async (req, res, next) => {
  try {
    // ── 1. Extract token ───────────────────────────────────
    // Prefer HttpOnly cookie; fall back to Authorization header for mobile/API clients
    const token =
      req.cookies?.access_token ||
      (req.headers.authorization?.startsWith('Bearer ')
        ? req.headers.authorization.split(' ')[1]
        : null);

    if (!token) return deny(res, 401, 'NO_TOKEN', 'Authentication required.');

    // ── 2. Verify signature + expiry ───────────────────────
    let payload;
    try {
      payload = verifyAccessToken(token);
    } catch (err) {
      const msg = err.name === 'TokenExpiredError' ? 'Token expired.' : 'Invalid token.';
      return deny(res, 401, 'INVALID_TOKEN', msg);
    }

    // ── 3. Blacklist check ─────────────────────────────────
    if (payload.jti && await isBlacklisted(payload.jti)) {
      return deny(res, 401, 'TOKEN_REVOKED', 'Session has been revoked. Please log in again.');
    }

    // ── 4. Load user from DB ───────────────────────────────
    const user = await User.findById(payload.userId).select('+tokenVersion');
    if (!user || !user.isActive) {
      return deny(res, 401, 'USER_NOT_FOUND', 'Account not found or deactivated.');
    }

    // ── 5. tokenVersion check ──────────────────────────────
    if (payload.tokenVersion !== user.tokenVersion) {
      return deny(res, 401, 'TOKEN_INVALIDATED', 'Session expired. Please log in again.');
    }

    // ── 6. Attach to request ───────────────────────────────
    req.user = {
      id:       user._id.toString(),
      role:     user.role,
      schoolId: user.schoolId?.toString(),
      jti:      payload.jti,
      exp:      payload.exp,
      // Role-specific scoping
      childIds:              user.childIds,
      assignedClassIds:      user.assignedClassIds,
      assignedHostelBlockIds: user.assignedHostelBlockIds,
      assignedExamIds:       user.assignedExamIds,
    };

    next();
  } catch (err) {
    console.error('[authenticate]', err.message);
    deny(res, 500, 'AUTH_ERROR', 'Authentication failed.');
  }
};

module.exports = authenticate;
