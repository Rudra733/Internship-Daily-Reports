'use strict';

/**
 * ============================================================
 *  tests/sessionSecurity.test.js
 *  Run: node --test tests/sessionSecurity.test.js
 * ============================================================
 */

const { describe, it, before } = require('node:test');
const assert = require('node:assert/strict');

// Set up env before requiring modules
process.env.JWT_SECRET           = 'test-secret-that-is-long-enough-for-jwt-signing-purposes';
process.env.JWT_ACCESS_EXPIRY    = '15m';
process.env.JWT_ISSUER           = 'sproutsong.edu';
process.env.FIELD_ENCRYPTION_KEY = 'a'.repeat(64);

const { passwordSchema, validateNewPassword, hashPassword, comparePassword } = require('../utils/passwordPolicy');
const { generateOtp, hashOtp, buildOtpPayload, canResendOtp, verifyOtp }     = require('../utils/otpService');
const { signAccessToken, verifyAccessToken, generateRefreshToken, setAuthCookies, clearAuthCookies } = require('../utils/tokenService');

// ============================================================
//  Password Policy
// ============================================================
describe('passwordSchema', () => {
  const valid = (p) => !passwordSchema.validate(p).error;
  const invalid = (p) => !!passwordSchema.validate(p).error;

  it('accepts a strong password', () => assert.ok(valid('Secure@Pass1')));
  it('rejects < 10 chars',        () => assert.ok(invalid('Sh@rt1')));
  it('rejects no uppercase',      () => assert.ok(invalid('secure@pass1')));
  it('rejects no lowercase',      () => assert.ok(invalid('SECURE@PASS1')));
  it('rejects no number',         () => assert.ok(invalid('Secure@Pass!')));
  it('rejects no symbol',         () => assert.ok(invalid('SecurePass12')));
  it('rejects > 128 chars',       () => assert.ok(invalid('Aa1!' + 'x'.repeat(126))));
  it('accepts exactly 10 chars',  () => assert.ok(valid('Secure@Pa1')));
});

describe('hashPassword / comparePassword', () => {
  it('hash starts with $2 (bcrypt)', async () => {
    const h = await hashPassword('Secure@Pass1');
    assert.ok(h.startsWith('$2'));
  });
  it('compare correct password → true', async () => {
    const h = await hashPassword('Secure@Pass1');
    assert.equal(await comparePassword('Secure@Pass1', h), true);
  });
  it('compare wrong password → false', async () => {
    const h = await hashPassword('Secure@Pass1');
    assert.equal(await comparePassword('WrongPass1!', h), false);
  });
  it('different salts — same password produces different hashes', async () => {
    const [a, b] = await Promise.all([hashPassword('Same@Pass1'), hashPassword('Same@Pass1')]);
    assert.notEqual(a, b);
  });
});

// ============================================================
//  OTP Service
// ============================================================
describe('generateOtp', () => {
  it('returns 6-digit numeric string', () => {
    const otp = generateOtp(6);
    assert.equal(otp.length, 6);
    assert.match(otp, /^\d{6}$/);
  });
  it('produces different OTPs each call', () => {
    assert.notEqual(generateOtp(), generateOtp());
  });
});

describe('hashOtp', () => {
  it('returns 64-char hex string (SHA-256)', () => {
    assert.match(hashOtp('123456'), /^[a-f0-9]{64}$/);
  });
  it('is deterministic', () => {
    assert.equal(hashOtp('123456'), hashOtp('123456'));
  });
  it('does not contain original OTP', () => {
    assert.ok(!hashOtp('123456').includes('123456'));
  });
});

describe('buildOtpPayload', () => {
  it('never includes raw OTP in payload', () => {
    const otp     = '987654';
    const payload = buildOtpPayload(otp);
    assert.ok(!JSON.stringify(payload).includes(otp));
  });
  it('sets otpUsed to false', () => {
    assert.equal(buildOtpPayload('123456').otpUsed, false);
  });
  it('sets expiry in the future', () => {
    assert.ok(buildOtpPayload('123456').otpExpiry > new Date());
  });
  it('sets otpAttempts to 0', () => {
    assert.equal(buildOtpPayload('123456').otpAttempts, 0);
  });
});

describe('canResendOtp', () => {
  it('allows resend if lastSent is null', () => {
    assert.equal(canResendOtp(null).allowed, true);
  });
  it('blocks resend within cooldown period', () => {
    const recent = new Date(Date.now() - 10_000); // 10 seconds ago
    const result = canResendOtp(recent);
    assert.equal(result.allowed, false);
    assert.ok(result.waitSeconds > 0);
  });
  it('allows resend after cooldown', () => {
    const old = new Date(Date.now() - 120_000); // 2 minutes ago
    assert.equal(canResendOtp(old).allowed, true);
  });
});

describe('verifyOtp', () => {
  function makeUser(overrides = {}) {
    const otp = '123456';
    return {
      otpHash:     hashOtp(otp),
      otpExpiry:   new Date(Date.now() + 600_000),
      otpUsed:     false,
      otpAttempts: 0,
      updateOne:   async () => {},
      ...overrides,
    };
  }

  it('valid OTP → { valid: true }', async () => {
    const result = await verifyOtp(makeUser(), '123456');
    assert.equal(result.valid, true);
  });
  it('wrong OTP → { valid: false }', async () => {
    let incremented = false;
    const user = makeUser({ updateOne: async () => { incremented = true; } });
    const result = await verifyOtp(user, '999999');
    assert.equal(result.valid, false);
    assert.ok(incremented, 'Should increment attempt counter');
  });
  it('used OTP → { valid: false, reason includes "used" }', async () => {
    const result = await verifyOtp(makeUser({ otpUsed: true }), '123456');
    assert.equal(result.valid, false);
    assert.ok(result.reason.toLowerCase().includes('used'));
  });
  it('expired OTP → { valid: false, reason includes "expired" }', async () => {
    const result = await verifyOtp(makeUser({ otpExpiry: new Date(Date.now() - 1000) }), '123456');
    assert.equal(result.valid, false);
    assert.ok(result.reason.toLowerCase().includes('expired'));
  });
  it('null user → { valid: false }', async () => {
    const result = await verifyOtp(null, '123456');
    assert.equal(result.valid, false);
  });
  it('too many attempts → OTP invalidated', async () => {
    let invalidated = false;
    const user = makeUser({ otpAttempts: 3, updateOne: async () => { invalidated = true; } });
    const result = await verifyOtp(user, '123456');
    assert.equal(result.valid, false);
    assert.ok(invalidated);
  });
});

// ============================================================
//  Token Service
// ============================================================
describe('signAccessToken / verifyAccessToken', () => {
  const fakeUser = {
    _id:          { toString: () => '6641a3f000000000000000aa' },
    role:         'teacher',
    schoolId:     { toString: () => '6641a3f000000000000000bb' },
    tokenVersion: 2,
  };

  it('produces a valid JWT string', () => {
    const { token } = signAccessToken(fakeUser);
    assert.equal(typeof token, 'string');
    assert.equal(token.split('.').length, 3);
  });

  it('payload contains userId, role, schoolId, tokenVersion', () => {
    const { token } = signAccessToken(fakeUser);
    const payload   = verifyAccessToken(token);
    assert.equal(payload.userId,       fakeUser._id.toString());
    assert.equal(payload.role,         fakeUser.role);
    assert.equal(payload.schoolId,     fakeUser.schoolId.toString());
    assert.equal(payload.tokenVersion, fakeUser.tokenVersion);
  });

  it('payload contains a jti (UUID)', () => {
    const { token } = signAccessToken(fakeUser);
    const payload   = verifyAccessToken(token);
    assert.ok(payload.jti && payload.jti.length > 0);
  });

  it('payload does NOT contain email or password', () => {
    const { token } = signAccessToken({ ...fakeUser, email: 'secret@test.com', password: 'hashed' });
    const payload   = verifyAccessToken(token);
    assert.ok(!('email'    in payload), 'email must not be in JWT payload');
    assert.ok(!('password' in payload), 'password must not be in JWT payload');
  });

  it('different tokens have different jti values', () => {
    const a = signAccessToken(fakeUser);
    const b = signAccessToken(fakeUser);
    const pa = verifyAccessToken(a.token);
    const pb = verifyAccessToken(b.token);
    assert.notEqual(pa.jti, pb.jti);
  });

  it('throws on tampered token', () => {
    const { token } = signAccessToken(fakeUser);
    const tampered  = token.slice(0, -5) + 'ZZZZZ';
    assert.throws(() => verifyAccessToken(tampered));
  });
});

describe('generateRefreshToken', () => {
  it('raw token is 80-char hex string', () => {
    const { raw } = generateRefreshToken();
    assert.equal(raw.length, 80);
    assert.match(raw, /^[a-f0-9]{80}$/);
  });
  it('hash is 64-char hex string', () => {
    const { hash } = generateRefreshToken();
    assert.equal(hash.length, 64);
  });
  it('raw and hash are different', () => {
    const { raw, hash } = generateRefreshToken();
    assert.notEqual(raw, hash);
  });
  it('different tokens each call', () => {
    const a = generateRefreshToken();
    const b = generateRefreshToken();
    assert.notEqual(a.raw, b.raw);
  });
});

// ============================================================
//  Cookie security invariants
// ============================================================
describe('setAuthCookies security invariants', () => {
  it('sets httpOnly=true on all cookies', () => {
    const cookies = [];
    const fakeRes = {
      cookie: (name, value, opts) => cookies.push({ name, opts }),
    };
    const { token } = signAccessToken({
      _id: { toString: () => 'abc' }, role: 'student',
      schoolId: { toString: () => 'xyz' }, tokenVersion: 0,
    });
    setAuthCookies(fakeRes, token, 'raw-refresh-token');
    cookies.forEach(c => {
      assert.ok(c.opts.httpOnly === true, `${c.name} must have httpOnly: true`);
    });
  });

  it('refresh token cookie path is restricted to /api/v1/auth/refresh', () => {
    const cookies = [];
    const fakeRes = { cookie: (name, value, opts) => cookies.push({ name, opts }) };
    setAuthCookies(fakeRes, 'access', 'refresh');
    const refreshCookie = cookies.find(c => c.name === 'refresh_token');
    assert.ok(refreshCookie, 'refresh_token cookie should be set');
    assert.equal(refreshCookie.opts.path, '/api/v1/auth/refresh');
  });
});
