'use strict';

/**
 * ============================================================
 *  controllers/authController.js
 *
 *  Handles:
 *   - login()         — with lockout, MFA check
 *   - logout()        — clears cookies, invalidates tokens
 *   - refreshToken()  — rotate refresh token
 *   - forgotPassword() — issue reset token
 *   - resetPassword() — validate token, set new password
 * ============================================================
 */

const crypto          = require('crypto');
const Joi             = require('joi');
const User            = require('../models/User');
const RefreshToken    = require('../models/RefreshToken');
const { passwordSchema, validateNewPassword } = require('../utils/passwordPolicy');
const { signAccessToken, setAuthCookies, clearAuthCookies, blacklistToken } = require('../utils/tokenService');
const { checkMfa, isMfaRequiredRole } = require('../utils/mfaService');

const MAX_ATTEMPTS    = parseInt(process.env.MAX_LOGIN_ATTEMPTS || '5',  10);
const LOCKOUT_MINUTES = parseInt(process.env.LOCKOUT_MINUTES    || '15', 10);

// ── Login ─────────────────────────────────────────────────────
const loginSchema = Joi.object({
  email:    Joi.string().email().required(),
  password: Joi.string().required(),
  mfaCode:  Joi.string().optional(), // 6-digit TOTP or backup code
}).options({ stripUnknown: true });

async function login(req, res) {
  const { error, value } = loginSchema.validate(req.body);
  if (error) return res.status(422).json({ success: false, message: error.details[0].message });

  const { email, password, mfaCode } = value;

  const user = await User.findOne({ email })
    .select('+password +tokenVersion +loginAttempts +lockUntil +mfaEnabled');

  // ── Lockout check ─────────────────────────────────────────
  if (user?.isLocked()) {
    const wait = Math.ceil((user.lockUntil - Date.now()) / 60_000);
    return res.status(429).json({
      success: false,
      code:    'ACCOUNT_LOCKED',
      message: `Account locked. Try again in ${wait} minute(s).`,
    });
  }

  // ── Credential check ──────────────────────────────────────
  // Same error for wrong email AND wrong password — prevents user enumeration
  const validPassword = user && await user.comparePassword(password);
  if (!user || !validPassword) {
    if (user) {
      const attempts = (user.loginAttempts || 0) + 1;
      const update   = attempts >= MAX_ATTEMPTS
        ? { loginAttempts: attempts, lockUntil: new Date(Date.now() + LOCKOUT_MINUTES * 60_000) }
        : { loginAttempts: attempts };
      await user.updateOne(update);
    }
    return res.status(401).json({
      success: false,
      code:    'INVALID_CREDENTIALS',
      message: 'Invalid email or password.', // same message always — no enumeration
    });
  }

  // ── MFA check (required for high-privilege roles) ─────────
  if (user.mfaEnabled || isMfaRequiredRole(user.role)) {
    if (!mfaCode) {
      return res.status(200).json({
        success:    false,
        code:       'MFA_REQUIRED',
        message:    'MFA code required.',
        mfaEnabled: user.mfaEnabled,
      });
    }
    const mfaResult = await checkMfa(user._id, mfaCode, User);
    if (!mfaResult.valid) {
      return res.status(401).json({ success: false, code: 'INVALID_MFA', message: 'Invalid MFA code.' });
    }
  }

  // ── Issue tokens ──────────────────────────────────────────
  const { token: accessToken } = signAccessToken(user);
  const refreshTokenRaw = await RefreshToken.createToken({
    userId:    user._id,
    schoolId:  user.schoolId,
    userAgent: req.headers['user-agent'],
    ip:        req.ip,
  });

  // Reset lockout counter on successful login
  await user.updateOne({ loginAttempts: 0, lockUntil: null, lastLogin: new Date() });

  setAuthCookies(res, accessToken, refreshTokenRaw);

  return res.json({
    success: true,
    user:    { id: user._id, role: user.role, schoolId: user.schoolId },
  });
}

// ── Logout ────────────────────────────────────────────────────
async function logout(req, res) {
  const { jti, exp, id: userId } = req.user;

  // Blacklist current access token jti
  if (jti && exp) {
    await blacklistToken(jti, new Date(exp * 1000));
  }

  // Revoke refresh token(s) for this user (all devices) or just current
  const logoutAll = req.query.all === 'true';
  if (logoutAll) {
    await RefreshToken.revokeAllForUser(userId);
  } else {
    const rawRefresh = req.cookies?.refresh_token;
    if (rawRefresh) {
      const hash = crypto.createHash('sha256').update(rawRefresh).digest('hex');
      await RefreshToken.findOneAndUpdate({ tokenHash: hash }, { revokedAt: new Date() });
    }
  }

  // Increment tokenVersion — invalidates ALL existing JWTs for this user
  await User.findByIdAndUpdate(userId, { $inc: { tokenVersion: 1 } });

  clearAuthCookies(res);
  return res.json({ success: true, message: 'Logged out successfully.' });
}

// ── Refresh token ─────────────────────────────────────────────
async function refreshToken(req, res) {
  const rawToken = req.cookies?.refresh_token;
  if (!rawToken) return res.status(401).json({ success: false, code: 'NO_REFRESH_TOKEN' });

  try {
    const newRawToken = await RefreshToken.rotate(rawToken, req);
    const user        = await User.findById(req.user?.id || (await RefreshToken.findOne({}))?.userId);
    if (!user) return res.status(401).json({ success: false, code: 'USER_NOT_FOUND' });

    const { token: newAccessToken } = signAccessToken(user);
    setAuthCookies(res, newAccessToken, newRawToken);
    return res.json({ success: true });
  } catch (err) {
    clearAuthCookies(res);
    return res.status(401).json({ success: false, code: err.message });
  }
}

// ── Forgot password ───────────────────────────────────────────
async function forgotPassword(req, res) {
  const { email } = req.body;
  // Always return success — never reveal if email is registered
  const successMsg = 'If that email is registered, a reset link has been sent.';

  const user = await User.findOne({ email: email?.toLowerCase().trim() });
  if (!user) return res.json({ success: true, message: successMsg });

  const rawToken  = crypto.randomBytes(32).toString('hex');
  const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
  const expiresAt = new Date(Date.now() + 15 * 60_000); // 15 minutes

  await user.updateOne({ resetTokenHash: tokenHash, resetTokenExpiry: expiresAt, resetTokenUsed: false });

  // TODO: send email with link: https://app.sproutsong.edu/reset-password?token=<rawToken>
  // The raw token is sent ONCE via email — never stored in DB
  console.info(`[forgotPassword] Reset token for ${user._id}: ${rawToken}`); // replace with email send

  return res.json({ success: true, message: successMsg });
}

// ── Reset password ────────────────────────────────────────────
const resetSchema = Joi.object({
  token:       Joi.string().required(),
  newPassword: passwordSchema.required(),
}).options({ stripUnknown: true });

async function resetPassword(req, res) {
  const { error, value } = resetSchema.validate(req.body);
  if (error) return res.status(422).json({ success: false, message: error.details[0].message });

  const { token, newPassword } = value;
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');

  const user = await User.findOne({ resetTokenHash: tokenHash })
    .select('+resetTokenHash +resetTokenExpiry +resetTokenUsed +tokenVersion');

  if (!user || user.resetTokenUsed || new Date() > user.resetTokenExpiry) {
    return res.status(400).json({ success: false, message: 'Reset link is invalid or has expired.' });
  }

  // Check breach database
  const { valid, errors } = await validateNewPassword(newPassword, true);
  if (!valid) return res.status(422).json({ success: false, errors });

  // Update password and invalidate all tokens
  await user.updateOne({
    password:         newPassword, // pre-save hook hashes it
    resetTokenUsed:   true,
    $inc:             { tokenVersion: 1 }, // invalidate all existing sessions
  });

  return res.json({ success: true, message: 'Password reset successfully. Please log in again.' });
}

module.exports = { login, logout, refreshToken, forgotPassword, resetPassword };
