'use strict';

/**
 * ============================================================
 *  controllers/otpController.js
 *
 *  OTP endpoints:
 *   - sendOtp()   — generate, hash, store, send via SMS/email
 *   - verifyOtp() — validate with attempt counter
 *   - resendOtp() — with cooldown enforcement
 * ============================================================
 */

const User = require('../models/User');
const { generateOtp, buildOtpPayload, canResendOtp, verifyOtp } = require('../utils/otpService');

// ── Send OTP ──────────────────────────────────────────────────
async function sendOtp(req, res) {
  const { userId } = req.body;
  if (!userId) return res.status(400).json({ success: false, message: 'userId is required.' });

  const user = await User.findById(userId).select('+otpLastSent');
  if (!user) return res.status(404).json({ success: false, message: 'User not found.' });

  // Enforce resend cooldown
  const { allowed, waitSeconds } = canResendOtp(user.otpLastSent);
  if (!allowed) {
    return res.status(429).json({
      success: false,
      code:    'OTP_COOLDOWN',
      message: `Please wait ${waitSeconds} seconds before requesting another OTP.`,
      waitSeconds,
    });
  }

  const rawOtp = generateOtp(6);
  await user.updateOne(buildOtpPayload(rawOtp));

  // TODO: replace with actual SMS/email provider (Twilio, AWS SNS, SendGrid etc.)
  console.info(`[OTP] Generated for user ${userId}: ${rawOtp}`); // remove in production

  return res.json({
    success: true,
    message: 'OTP sent. It will expire in 10 minutes.',
    // Never return rawOtp in response — only send via SMS/email
  });
}

// ── Verify OTP ────────────────────────────────────────────────
async function verifyOtpHandler(req, res) {
  const { userId, otp } = req.body;
  if (!userId || !otp) {
    return res.status(400).json({ success: false, message: 'userId and otp are required.' });
  }

  const user   = await User.findById(userId)
    .select('+otpHash +otpExpiry +otpUsed +otpAttempts');
  const result = await verifyOtp(user, otp);

  if (!result.valid) {
    return res.status(400).json({ success: false, code: 'INVALID_OTP', message: result.reason });
  }

  return res.json({ success: true, message: 'OTP verified successfully.' });
}

// ── Resend OTP ────────────────────────────────────────────────
async function resendOtp(req, res) {
  // Delegate to sendOtp — cooldown check is inside
  return sendOtp(req, res);
}

module.exports = { sendOtp, verifyOtpHandler, resendOtp };
