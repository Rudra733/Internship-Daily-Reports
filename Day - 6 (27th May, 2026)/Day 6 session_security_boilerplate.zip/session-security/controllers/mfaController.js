'use strict';

/**
 * ============================================================
 *  controllers/mfaController.js
 *
 *  MFA endpoints:
 *   - setupMfa()    — generate secret + QR code
 *   - enableMfa()   — verify first code, activate
 *   - checkMfaCode()— verify on login (called from authController)
 *   - disableMfa()  — deactivate with code confirmation
 *   - getMfaStatus()— check if MFA is active for the user
 * ============================================================
 */

const User = require('../models/User');
const { setupMfa, verifyAndEnableMfa, disableMfa } = require('../utils/mfaService');

async function setupMfaHandler(req, res) {
  try {
    const result = await setupMfa(req.user.id, req.user.email, User);
    return res.json({
      success:   true,
      qrCodeUrl: result.qrCodeUrl,
      manualKey: result.manualKey,
      message:   'Scan the QR code with your authenticator app, then call /mfa/enable with a valid code.',
    });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
}

async function enableMfaHandler(req, res) {
  const { code } = req.body;
  if (!code) return res.status(400).json({ success: false, message: 'MFA code is required.' });

  const result = await verifyAndEnableMfa(req.user.id, code, User);
  if (!result.success) return res.status(400).json({ success: false, message: result.message });

  return res.json({
    success:     true,
    message:     'MFA enabled. Save these backup codes — they will not be shown again.',
    backupCodes: result.backupCodes, // shown ONCE — user must save them
  });
}

async function disableMfaHandler(req, res) {
  const { code } = req.body;
  if (!code) return res.status(400).json({ success: false, message: 'MFA code is required to disable MFA.' });

  const result = await disableMfa(req.user.id, code, User);
  if (!result.success) return res.status(400).json({ success: false, message: result.message });

  return res.json({ success: true, message: 'MFA disabled.' });
}

async function getMfaStatus(req, res) {
  const user = await User.findById(req.user.id).select('mfaEnabled role');
  return res.json({
    success:    true,
    mfaEnabled: user.mfaEnabled,
    role:       user.role,
  });
}

module.exports = { setupMfaHandler, enableMfaHandler, disableMfaHandler, getMfaStatus };
