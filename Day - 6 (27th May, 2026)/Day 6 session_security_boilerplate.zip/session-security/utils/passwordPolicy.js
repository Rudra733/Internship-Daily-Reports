'use strict';

/**
 * ============================================================
 *  utils/passwordPolicy.js
 *
 *  Password rules for SproutSong:
 *   - Min 10 chars, max 128 (bcrypt DoS prevention)
 *   - Uppercase + lowercase + number + symbol
 *   - HaveIBeenPwned k-anonymity check (optional, recommended)
 *   - bcrypt hashing (rounds 12)
 * ============================================================
 */

const Joi    = require('joi');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

const BCRYPT_ROUNDS = 12;

// ── Joi password schema ───────────────────────────────────────
// Used in registration and password-change Joi schemas.
// Import and use as: passwordSchema.required()
const passwordSchema = Joi.string()
  .min(10)
  .max(128)   // bcrypt silently truncates at 72 bytes — cap at 128 chars to prevent confusion
  .pattern(/[A-Z]/,      'uppercase letter')
  .pattern(/[a-z]/,      'lowercase letter')
  .pattern(/[0-9]/,      'number')
  .pattern(/[^A-Za-z0-9]/, 'symbol')
  .messages({
    'string.min':          'Password must be at least 10 characters.',
    'string.max':          'Password must not exceed 128 characters.',
    'string.pattern.name': 'Password must contain at least one {#name}.',
    'any.required':        'Password is required.',
  });

// ── bcrypt helpers ────────────────────────────────────────────
async function hashPassword(plainText) {
  return bcrypt.hash(plainText, BCRYPT_ROUNDS);
}

async function comparePassword(plainText, hash) {
  return bcrypt.compare(plainText, hash);
}

// ── HaveIBeenPwned k-anonymity check ─────────────────────────
// Sends only the first 5 chars of the SHA-1 hash — password never leaves your server.
// Returns true if the password appears in known breach databases.
async function isBreachedPassword(password) {
  try {
    const hash   = crypto.createHash('sha1').update(password).digest('hex').toUpperCase();
    const prefix = hash.slice(0, 5);
    const suffix = hash.slice(5);

    const res  = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`, {
      headers: { 'Add-Padding': 'true' }, // padding mode — hides result count
      signal:  AbortSignal.timeout(3000), // don't block login if HIBP is slow
    });

    if (!res.ok) return false; // if HIBP is unreachable, allow the password

    const text = await res.text();
    return text.split('\n').some(line => line.split(':')[0] === suffix);
  } catch {
    // Network error / timeout — fail open (don't block registration)
    return false;
  }
}

// ── Validate a new password (combine schema + breach check) ──
// Returns { valid: boolean, errors: string[] }
async function validateNewPassword(password, checkBreach = true) {
  const errors = [];

  // Joi validation
  const { error } = passwordSchema.validate(password);
  if (error) {
    error.details.forEach(d => errors.push(d.message));
  }

  // Breach check (only if schema passes — no point checking a weak password)
  if (errors.length === 0 && checkBreach) {
    const breached = await isBreachedPassword(password);
    if (breached) {
      errors.push(
        'This password has appeared in a known data breach. Please choose a different one.'
      );
    }
  }

  return { valid: errors.length === 0, errors };
}

module.exports = {
  passwordSchema,
  hashPassword,
  comparePassword,
  isBreachedPassword,
  validateNewPassword,
  BCRYPT_ROUNDS,
};
