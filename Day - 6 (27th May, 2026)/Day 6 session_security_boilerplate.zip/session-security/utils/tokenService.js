'use strict';

/**
 * ============================================================
 *  utils/tokenService.js
 *
 *  JWT access + refresh token lifecycle:
 *   - signAccessToken()   — 15-minute JWT, safe payload only
 *   - signRefreshToken()  — random bytes, SHA-256 stored in DB
 *   - setAuthCookies()    — HttpOnly, Secure, SameSite
 *   - clearAuthCookies()  — on logout
 *   - blacklistToken()    — Redis or MongoDB fallback
 *   - isBlacklisted()     — checked in authenticate middleware
 * ============================================================
 */

const jwt    = require('jsonwebtoken');
const crypto = require('crypto');

const ACCESS_EXPIRY  = process.env.JWT_ACCESS_EXPIRY  || '15m';
const REFRESH_EXPIRY = process.env.JWT_REFRESH_EXPIRY || '7d';
const JWT_SECRET     = () => {
  if (!process.env.JWT_SECRET) throw new Error('[tokenService] JWT_SECRET not set in .env');
  return process.env.JWT_SECRET;
};

// ── Access token ──────────────────────────────────────────────
// Payload: only safe, non-sensitive fields
function signAccessToken(user) {
  const jti = crypto.randomUUID(); // unique token ID — used for blacklisting
  return {
    token: jwt.sign(
      {
        userId:       user._id.toString(),
        role:         user.role,
        schoolId:     user.schoolId?.toString() || null,
        tokenVersion: user.tokenVersion,
        jti,
        // ❌ Never include: email, name, password, phone, aadhaar
      },
      JWT_SECRET(),
      {
        expiresIn: ACCESS_EXPIRY,
        issuer:    process.env.JWT_ISSUER || 'sproutsong.edu',
      }
    ),
    jti,
  };
}

// ── Verify access token ───────────────────────────────────────
function verifyAccessToken(token) {
  return jwt.verify(token, JWT_SECRET(), {
    issuer: process.env.JWT_ISSUER || 'sproutsong.edu',
  });
}

// ── Refresh token ─────────────────────────────────────────────
// Raw token sent to client; hash stored in DB
function generateRefreshToken() {
  const raw  = crypto.randomBytes(40).toString('hex'); // 80-char URL-safe string
  const hash = crypto.createHash('sha256').update(raw).digest('hex');
  return { raw, hash };
}

// ── Parse refresh token expiry to ms ─────────────────────────
function refreshExpiryMs() {
  const val = REFRESH_EXPIRY;
  if (val.endsWith('d'))  return parseInt(val) * 24 * 60 * 60 * 1000;
  if (val.endsWith('h'))  return parseInt(val) * 60 * 60 * 1000;
  if (val.endsWith('m'))  return parseInt(val) * 60 * 1000;
  return 7 * 24 * 60 * 60 * 1000; // default 7 days
}

// ── Set auth cookies ──────────────────────────────────────────
function setAuthCookies(res, accessToken, refreshTokenRaw) {
  const isProd = process.env.NODE_ENV === 'production';

  const base = {
    httpOnly: true,                          // JS cannot read — prevents XSS token theft
    secure:   isProd,                        // HTTPS only in production
    sameSite: isProd ? 'Strict' : 'Lax',    // CSRF protection
    domain:   isProd ? process.env.COOKIE_DOMAIN : undefined,
  };

  // Access token: 15 minutes
  res.cookie('access_token', accessToken, {
    ...base,
    maxAge: 15 * 60 * 1000,
    path:   '/',
  });

  // Refresh token: 7 days — restricted to refresh endpoint only
  if (refreshTokenRaw) {
    res.cookie('refresh_token', refreshTokenRaw, {
      ...base,
      maxAge: refreshExpiryMs(),
      path:   '/api/v1/auth/refresh', // browser only sends this cookie to this path
    });
  }
}

// ── Clear auth cookies on logout ─────────────────────────────
function clearAuthCookies(res) {
  const base = { httpOnly: true, secure: process.env.NODE_ENV === 'production' };
  res.clearCookie('access_token',  { ...base, path: '/' });
  res.clearCookie('refresh_token', { ...base, path: '/api/v1/auth/refresh' });
}

// ── JWT blacklist (Redis primary, MongoDB fallback) ───────────
let _redis = null;

async function getRedis() {
  if (_redis) return _redis;
  if (!process.env.REDIS_URL) return null;
  try {
    const { createClient } = require('redis');
    _redis = createClient({ url: process.env.REDIS_URL });
    _redis.on('error', () => { _redis = null; }); // reset on error — triggers fallback
    await _redis.connect();
    return _redis;
  } catch {
    return null;
  }
}

// Blacklist a token jti until its natural expiry
async function blacklistToken(jti, expiresAt) {
  const ttl = Math.ceil((new Date(expiresAt).getTime() - Date.now()) / 1000);
  if (ttl <= 0) return; // already expired — no need to blacklist

  const redis = await getRedis();
  if (redis) {
    // Redis: O(1) lookup, auto-expires
    await redis.setEx(`bl:${jti}`, ttl, '1');
  } else {
    // MongoDB fallback
    const BlacklistedToken = require('../models/BlacklistedToken');
    await BlacklistedToken.create({ jti, expiresAt: new Date(expiresAt) });
  }
}

// Check if a token jti is blacklisted
async function isBlacklisted(jti) {
  const redis = await getRedis();
  if (redis) {
    const val = await redis.get(`bl:${jti}`);
    return val === '1';
  }
  // MongoDB fallback
  const BlacklistedToken = require('../models/BlacklistedToken');
  const record = await BlacklistedToken.findOne({ jti });
  return !!record;
}

module.exports = {
  signAccessToken,
  verifyAccessToken,
  generateRefreshToken,
  setAuthCookies,
  clearAuthCookies,
  blacklistToken,
  isBlacklisted,
  refreshExpiryMs,
};
