'use strict';

/**
 * ============================================================
 *  utils/otpService.js
 *
 *  Full OTP lifecycle for SproutSong:
 *   - Cryptographically secure generation (crypto.randomInt)
 *   - SHA-256 hashing before storage (never plain text)
 *   - Expiry, used flag, attempt counter, resend cooldown
 *   - Verification with replay and brute-force prevention
 * ============================================================
 */

const crypto = require('crypto');

const OTP_EXPIRY_MINUTES       = parseInt(process.env.OTP_EXPIRY_MINUTES       || '10',  10);
const OTP_MAX_ATTEMPTS         = parseInt(process.env.OTP_MAX_ATTEMPTS          || '3',   10);
const OTP_RESEND_COOLDOWN_SECS = parseInt(process.env.OTP_RESEND_COOLDOWN_SECONDS || '60', 10);

// ── Generate ──────────────────────────────────────────────────
// crypto.randomInt gives uniform distribution — never use Math.random()
function generateOtp(digits = 6) {
  return Array.from({ length: digits }, () => crypto.randomInt(0, 10)).join('');
}

// ── Hash ──────────────────────────────────────────────────────
// SHA-256 is sufficient for OTPs: short-lived + attempt-limited
function hashOtp(otp) {
  return crypto.createHash('sha256').update(String(otp)).digest('hex');
}

// ── Build DB payload ─────────────────────────────────────────
// Spread this into User.updateOne() — never store raw OTP
function buildOtpPayload(rawOtp) {
  return {
    otpHash:     hashOtp(rawOtp),
    otpExpiry:   new Date(Date.now() + OTP_EXPIRY_MINUTES * 60_000),
    otpUsed:     false,
    otpAttempts: 0,
    otpLastSent: new Date(),
  };
}

// ── Resend cooldown check ─────────────────────────────────────
// Returns { allowed: boolean, waitSeconds: number }
function canResendOtp(otpLastSent) {
  if (!otpLastSent) return { allowed: true, waitSeconds: 0 };
  const elapsed = (Date.now() - new Date(otpLastSent).getTime()) / 1000;
  if (elapsed < OTP_RESEND_COOLDOWN_SECS) {
    return { allowed: false, waitSeconds: Math.ceil(OTP_RESEND_COOLDOWN_SECS - elapsed) };
  }
  return { allowed: true, waitSeconds: 0 };
}

// ── Verify ───────────────────────────────────────────────────
// Accepts a user object with otp fields (selected with +otpHash etc.)
// Returns { valid: boolean, reason: string }
async function verifyOtp(user, inputOtp) {
  if (!user) return { valid: false, reason: 'User not found' };

  // Already used
  if (user.otpUsed) return { valid: false, reason: 'OTP already used' };

  // Expired
  if (!user.otpExpiry || new Date() > new Date(user.otpExpiry)) {
    return { valid: false, reason: 'OTP has expired' };
  }

  // Too many failed attempts — invalidate OTP
  if ((user.otpAttempts || 0) >= OTP_MAX_ATTEMPTS) {
    await user.updateOne({ otpUsed: true });
    return { valid: false, reason: 'Too many failed attempts — OTP invalidated' };
  }

  // Wrong OTP — increment attempt counter
  if (hashOtp(inputOtp) !== user.otpHash) {
    await user.updateOne({ $inc: { otpAttempts: 1 } });
    const remaining = OTP_MAX_ATTEMPTS - (user.otpAttempts + 1);
    return {
      valid:  false,
      reason: `Invalid OTP. ${remaining > 0 ? `${remaining} attempt(s) remaining.` : 'OTP will be invalidated.'}`,
    };
  }

  // Valid — mark as used immediately (prevents replay)
  await user.updateOne({ otpUsed: true, otpAttempts: 0 });
  return { valid: true };
}

module.exports = {
  generateOtp,
  hashOtp,
  buildOtpPayload,
  canResendOtp,
  verifyOtp,
  OTP_EXPIRY_MINUTES,
  OTP_MAX_ATTEMPTS,
};
