'use strict';

/**
 * ============================================================
 *  utils/mfaService.js
 *
 *  TOTP-based MFA for high-privilege roles:
 *   super_admin, school_admin, principal, accountant
 *
 *  Uses otplib for TOTP generation/verification.
 *  MFA secret stored AES-256-GCM encrypted in MongoDB.
 *
 *  Flow:
 *   1. setupMfa()        → generate secret, return QR code
 *   2. verifyAndEnable() → verify first code, activate MFA
 *   3. checkMfa()        → verify on every login
 *   4. disableMfa()      → remove secret, disable MFA
 * ============================================================
 */

const { authenticator } = require('otplib');
const qrcode            = require('qrcode');
const crypto            = require('crypto');

// ── Field encryption (AES-256-GCM) ───────────────────────────
// Reuses the same encrypt/decrypt from mongodb-security package.
// Copy utils/fieldEncryption.js or install as shared package.
const FIELD_KEY = () => {
  const k = process.env.FIELD_ENCRYPTION_KEY;
  if (!k || k.length !== 64) throw new Error('[mfaService] FIELD_ENCRYPTION_KEY missing or invalid');
  return Buffer.from(k, 'hex');
};

const ALGO = 'aes-256-gcm';

function encryptSecret(plainText) {
  const key      = FIELD_KEY();
  const iv       = crypto.randomBytes(12);
  const cipher   = crypto.createCipheriv(ALGO, key, iv);
  const enc      = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()]);
  const authTag  = cipher.getAuthTag();
  return `v1:${iv.toString('hex')}:${authTag.toString('hex')}:${enc.toString('hex')}`;
}

function decryptSecret(envelope) {
  if (!envelope) throw new Error('[mfaService] No MFA secret found');
  const [ver, ivHex, tagHex, dataHex] = envelope.split(':');
  if (ver !== 'v1') throw new Error('[mfaService] Unknown key version');
  const key      = FIELD_KEY();
  const decipher = crypto.createDecipheriv(ALGO, key, Buffer.from(ivHex, 'hex'));
  decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
  return Buffer.concat([decipher.update(Buffer.from(dataHex, 'hex')), decipher.final()]).toString('utf8');
}

// ── Roles that require MFA ────────────────────────────────────
const MFA_REQUIRED_ROLES = ['super_admin', 'school_admin', 'principal', 'accountant'];

function isMfaRequiredRole(role) {
  return MFA_REQUIRED_ROLES.includes(role);
}

// ── Step 1: Generate secret + QR code ────────────────────────
async function setupMfa(userId, userEmail, UserModel) {
  const secret    = authenticator.generateSecret(); // 20-byte base32 secret
  const otpauth   = authenticator.keyuri(userEmail, 'SproutSong', secret);
  const qrCodeUrl = await qrcode.toDataURL(otpauth);

  // Store encrypted secret — NOT enabled until first verification
  await UserModel.findByIdAndUpdate(userId, {
    mfaSecret:  encryptSecret(secret),
    mfaEnabled: false,
  });

  return {
    qrCodeUrl,   // base64 data URL — display as <img> in frontend
    manualKey: secret, // show as fallback for users who can't scan QR
  };
}

// ── Step 2: Verify first code and activate MFA ───────────────
async function verifyAndEnableMfa(userId, code, UserModel) {
  const user = await UserModel.findById(userId).select('+mfaSecret');
  if (!user?.mfaSecret) throw new Error('MFA setup not started');

  const secret = decryptSecret(user.mfaSecret);
  const valid  = authenticator.verify({ token: String(code).trim(), secret });

  if (!valid) {
    return { success: false, message: 'Invalid authenticator code. Please try again.' };
  }

  await UserModel.findByIdAndUpdate(userId, { mfaEnabled: true });

  // Generate backup codes on activation
  const backupCodes = generateBackupCodes();
  await UserModel.findByIdAndUpdate(userId, {
    mfaBackupCodes: backupCodes.hashes,
  });

  return { success: true, backupCodes: backupCodes.plain }; // show plain codes ONCE to user
}

// ── Step 3: Verify TOTP on login ─────────────────────────────
// Returns { valid: boolean, usedBackupCode: boolean }
async function checkMfa(userId, code, UserModel) {
  const user = await UserModel.findById(userId)
    .select('+mfaSecret +mfaEnabled +mfaBackupCodes');

  if (!user) return { valid: false };
  if (!user.mfaEnabled) return { valid: true }; // MFA not set up — skip

  const secret = decryptSecret(user.mfaSecret);
  const codeStr = String(code).trim();

  // Check TOTP first
  if (authenticator.verify({ token: codeStr, secret })) {
    return { valid: true, usedBackupCode: false };
  }

  // Check backup codes (hashed)
  const inputHash = crypto.createHash('sha256').update(codeStr).digest('hex');
  const matchIdx  = (user.mfaBackupCodes || []).findIndex(h => h === inputHash);
  if (matchIdx !== -1) {
    // Remove used backup code
    user.mfaBackupCodes.splice(matchIdx, 1);
    await UserModel.findByIdAndUpdate(userId, { mfaBackupCodes: user.mfaBackupCodes });
    return { valid: true, usedBackupCode: true };
  }

  return { valid: false };
}

// ── Step 4: Disable MFA ───────────────────────────────────────
async function disableMfa(userId, code, UserModel) {
  const check = await checkMfa(userId, code, UserModel);
  if (!check.valid) return { success: false, message: 'Invalid MFA code' };

  await UserModel.findByIdAndUpdate(userId, {
    mfaSecret:      undefined,
    mfaEnabled:     false,
    mfaBackupCodes: [],
  });
  return { success: true };
}

// ── Backup codes ──────────────────────────────────────────────
function generateBackupCodes(count = 8) {
  const plain  = Array.from({ length: count }, () =>
    crypto.randomBytes(4).toString('hex').toUpperCase() // e.g. "A3F8-B2C1"
      .match(/.{1,4}/g).join('-')
  );
  const hashes = plain.map(c =>
    crypto.createHash('sha256').update(c.replace(/-/g, '')).digest('hex')
  );
  return { plain, hashes };
}

module.exports = {
  setupMfa,
  verifyAndEnableMfa,
  checkMfa,
  disableMfa,
  isMfaRequiredRole,
  MFA_REQUIRED_ROLES,
};
