'use strict';

/**
 * ============================================================
 *  models/User.js
 *
 *  User model including all auth security fields:
 *   - password: bcrypt hashed, select:false
 *   - tokenVersion: for JWT invalidation
 *   - loginAttempts + lockUntil: brute-force protection
 *   - otp fields: hashed, expiry, used flag, attempt counter
 *   - reset token: hashed, expiry, used flag
 *   - MFA: encrypted TOTP secret, backup codes
 * ============================================================
 */

const mongoose = require('mongoose');
const { hashPassword, comparePassword } = require('../utils/passwordPolicy');

const UserSchema = new mongoose.Schema(
  {
    name:  { type: String, required: true, trim: true, maxlength: 200 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },

    // ── Password — never returned in queries ──────────────
    password: { type: String, required: true, select: false, minlength: 8 },

    // ── RBAC ─────────────────────────────────────────────
    role: {
      type: String,
      enum: [
        'super_admin','school_admin','principal','teacher','coordinator',
        'counsellor','accountant','librarian','sports','extra_curricular',
        'analytics','hostel_warden','sales_admission','marketing','exam_admin',
        'parent','student',
      ],
      required: true,
      index: true,
    },
    schoolId: {
      type:     mongoose.Schema.Types.ObjectId,
      ref:      'School',
      index:    true,
      required: function () { return this.role !== 'super_admin'; },
    },

    // ── JWT invalidation ──────────────────────────────────
    // Increment on: logout, password change, role change
    tokenVersion: { type: Number, default: 0, select: false },

    isActive:  { type: Boolean, default: true, index: true },
    lastLogin: { type: Date },

    // ── Brute-force / lockout ─────────────────────────────
    loginAttempts: { type: Number, default: 0, select: false },
    lockUntil:     { type: Date, select: false },

    // ── OTP (hashed — never plain text) ───────────────────
    otpHash:     { type: String, select: false },
    otpExpiry:   { type: Date,   select: false },
    otpUsed:     { type: Boolean, default: false, select: false },
    otpAttempts: { type: Number,  default: 0,     select: false },
    otpLastSent: { type: Date,    select: false },

    // ── Password reset token (hashed) ─────────────────────
    resetTokenHash:   { type: String, select: false },
    resetTokenExpiry: { type: Date,   select: false },
    resetTokenUsed:   { type: Boolean, default: false, select: false },

    // ── MFA (TOTP secret encrypted at rest) ───────────────
    mfaEnabled:     { type: Boolean, default: false },
    mfaSecret:      { type: String, select: false },   // AES-256-GCM envelope
    mfaBackupCodes: { type: [String], select: false }, // SHA-256 hashed codes
  },
  {
    timestamps: true,
    strict:     true,
    toJSON: {
      transform(_doc, ret) {
        delete ret.password;
        delete ret.tokenVersion;
        delete ret.loginAttempts;
        delete ret.lockUntil;
        delete ret.otpHash;
        delete ret.otpExpiry;
        delete ret.otpUsed;
        delete ret.otpAttempts;
        delete ret.otpLastSent;
        delete ret.resetTokenHash;
        delete ret.resetTokenExpiry;
        delete ret.resetTokenUsed;
        delete ret.mfaSecret;
        delete ret.mfaBackupCodes;
        delete ret.__v;
        return ret;
      },
    },
  }
);

// ── Indexes ───────────────────────────────────────────────────
UserSchema.index({ schoolId: 1, role: 1 });
UserSchema.index({ email: 1 }, { unique: true });

// ── Hash password before save ─────────────────────────────────
UserSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await hashPassword(this.password);
  next();
});

// ── Instance methods ──────────────────────────────────────────
UserSchema.methods.comparePassword = function (candidate) {
  return comparePassword(candidate, this.password);
};

// Invalidate all JWTs for this user immediately
UserSchema.methods.invalidateTokens = function () {
  this.tokenVersion += 1;
  return this.save();
};

// Check if account is currently locked
UserSchema.methods.isLocked = function () {
  return !!(this.lockUntil && this.lockUntil > new Date());
};

module.exports = mongoose.model('User', UserSchema);
