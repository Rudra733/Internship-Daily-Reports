'use strict';

/**
 * ============================================================
 *  models/BlacklistedToken.js
 *
 *  MongoDB fallback for JWT blacklisting when Redis
 *  is not available. Stores JTI values with TTL expiry.
 *
 *  Primary: Redis (O(1) lookup, auto-expires)
 *  Fallback: this collection (TTL index handles cleanup)
 * ============================================================
 */

const mongoose = require('mongoose');

const BlacklistedTokenSchema = new mongoose.Schema(
  {
    jti:       { type: String, required: true, unique: true, index: true },
    expiresAt: { type: Date,   required: true },
  },
  {
    timestamps: { createdAt: 'createdAt', updatedAt: false },
    strict: true,
  }
);

// Auto-delete when expiresAt passes (same as Redis TTL behaviour)
BlacklistedTokenSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.model('BlacklistedToken', BlacklistedTokenSchema);
