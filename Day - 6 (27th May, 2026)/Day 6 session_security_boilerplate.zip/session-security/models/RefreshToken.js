'use strict';

/**
 * ============================================================
 *  models/RefreshToken.js
 *
 *  Stores refresh token metadata in MongoDB.
 *  Raw token is sent to client; SHA-256 hash stored here.
 *
 *  Security features:
 *   - tokenHash: never the raw token
 *   - used flag: detect token replay
 *   - family: detect and revoke entire token chains on replay
 *   - TTL index: auto-delete expired tokens
 *   - revokedAt: explicit revocation on logout/password change
 * ============================================================
 */

const mongoose = require('mongoose');
const crypto   = require('crypto');
const { refreshExpiryMs } = require('../utils/tokenService');

const RefreshTokenSchema = new mongoose.Schema(
  {
    userId:   { type: mongoose.Schema.Types.ObjectId, ref: 'User',   required: true, index: true },
    schoolId: { type: mongoose.Schema.Types.ObjectId, ref: 'School', index: true },

    // SHA-256 hash of the raw token — raw token never stored
    tokenHash: { type: String, required: true, index: true, select: false },

    expiresAt: { type: Date, required: true, index: true },
    used:      { type: Boolean, default: false },    // mark true after rotation
    revokedAt: { type: Date },                       // explicit revocation

    // Token family: all tokens in a rotation chain share the same family ID.
    // If an already-used token is presented, the entire family is revoked
    // (detects token theft + replay attacks).
    family: { type: String, required: true, index: true },

    // Metadata for session management UI
    userAgent: { type: String, maxlength: 500 },
    ip:        { type: String, maxlength: 50 },  // last octet masked
  },
  {
    timestamps: { createdAt: 'createdAt', updatedAt: false },
    strict: true,
  }
);

// TTL: auto-delete after token expires
RefreshTokenSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });
RefreshTokenSchema.index({ userId: 1, used: 1 });

// ── Static: create a new refresh token ───────────────────────
RefreshTokenSchema.statics.createToken = async function ({ userId, schoolId, userAgent, ip, family }) {
  const { generateRefreshToken } = require('../utils/tokenService');
  const { raw, hash } = generateRefreshToken();

  await this.create({
    userId,
    schoolId,
    tokenHash: hash,
    expiresAt: new Date(Date.now() + refreshExpiryMs()),
    family:    family || crypto.randomUUID(), // new family for fresh logins
    userAgent: userAgent?.slice(0, 500),
    ip,
  });

  return raw; // send to client; hash is stored
};

// ── Static: rotate a refresh token ───────────────────────────
// Returns new raw token, or throws on invalid/reused token
RefreshTokenSchema.statics.rotate = async function (rawToken, req) {
  const hash  = crypto.createHash('sha256').update(rawToken).digest('hex');
  const old   = await this.findOne({ tokenHash: hash }).select('+tokenHash');

  if (!old)                      throw Object.assign(new Error('TOKEN_NOT_FOUND'),  { status: 401 });
  if (old.revokedAt)             throw Object.assign(new Error('TOKEN_REVOKED'),    { status: 401 });
  if (new Date() > old.expiresAt) throw Object.assign(new Error('TOKEN_EXPIRED'),   { status: 401 });

  // Replay attack: token already used → revoke entire family
  if (old.used) {
    await this.updateMany({ family: old.family }, { revokedAt: new Date() });
    throw Object.assign(new Error('TOKEN_REUSE_DETECTED'), { status: 401 });
  }

  // Mark old token as used
  await old.updateOne({ used: true });

  // Issue new token in the same family
  return this.createToken({
    userId:    old.userId,
    schoolId:  old.schoolId,
    family:    old.family,  // same family chain
    userAgent: req?.headers?.['user-agent'],
    ip:        req?.ip,
  });
};

// ── Static: revoke all tokens for a user (logout all devices) ─
RefreshTokenSchema.statics.revokeAllForUser = function (userId) {
  return this.updateMany(
    { userId, revokedAt: { $exists: false }, used: false },
    { revokedAt: new Date() }
  );
};

module.exports = mongoose.model('RefreshToken', RefreshTokenSchema);
