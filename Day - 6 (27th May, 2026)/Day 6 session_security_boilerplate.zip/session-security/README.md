# SproutSong — Password, OTP & Session Security
## Complete Implementation Package

---

## File Structure

```
session-security/
│
├── .env.example                        ← Copy to .env, fill in values
├── package.json
│
├── config/                             ← (add db.js from mongodb-security)
│
├── middleware/
│   ├── authenticate.js                 ← JWT verify + tokenVersion + blacklist check
│   └── authRateLimits.js               ← login, OTP, password reset, MFA rate limiters
│
├── models/
│   ├── User.js                         ← User model with all auth security fields
│   ├── RefreshToken.js                 ← Refresh token with rotation + family tracking
│   └── BlacklistedToken.js             ← MongoDB fallback JWT blacklist (TTL)
│
├── utils/
│   ├── passwordPolicy.js               ← Joi schema, bcrypt, HaveIBeenPwned check
│   ├── otpService.js                   ← Generate, hash, verify OTP with attempt counter
│   ├── tokenService.js                 ← Sign JWT, set/clear cookies, blacklist
│   └── mfaService.js                   ← TOTP setup, verify, enable/disable, backup codes
│
├── controllers/
│   ├── authController.js               ← login, logout, refresh, forgot/reset password
│   ├── otpController.js                ← send, verify, resend OTP
│   └── mfaController.js                ← setup, enable, disable, status MFA
│
├── routes/
│   └── auth.js                         ← All auth routes with rate limiters applied
│
├── scripts/
│   └── generateKeys.js                 ← Generate JWT_SECRET + FIELD_ENCRYPTION_KEY
│
└── tests/
    └── sessionSecurity.test.js         ← 40+ tests for all auth security controls
```

---

## Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Generate secrets
```bash
node scripts/generateKeys.js
# Copy output into your .env
```

### 3. Configure environment
```bash
cp .env.example .env
# Fill in: JWT_SECRET, FIELD_ENCRYPTION_KEY, MONGODB_URI, REDIS_URL
```

### 4. Register routes in app.js
```js
const cookieParser = require('cookie-parser');
app.use(cookieParser());
app.use('/api/v1/auth', require('./routes/auth'));
```

### 5. Run tests
```bash
node --test tests/
```

---

## Key Files Explained

### `utils/passwordPolicy.js`
- Joi schema enforcing min 10 chars, uppercase, lowercase, number, symbol, max 128
- `hashPassword()` — bcrypt with 12 rounds
- `comparePassword()` — bcrypt compare
- `isBreachedPassword()` — k-anonymity check against HaveIBeenPwned API (sends only first 5 chars of SHA-1 hash — password never leaves your server)
- `validateNewPassword()` — combines schema + breach check

### `utils/otpService.js`
- `generateOtp()` — `crypto.randomInt()` (never `Math.random()`)
- `hashOtp()` — SHA-256 hash for DB storage
- `buildOtpPayload()` — `{ otpHash, otpExpiry, otpUsed: false, otpAttempts: 0, otpLastSent }`
- `canResendOtp()` — 60-second cooldown check
- `verifyOtp()` — checks used flag → expiry → attempt counter → hash comparison

### `utils/tokenService.js`
- `signAccessToken()` — 15-minute JWT with safe payload (userId, role, schoolId, tokenVersion, jti). Never includes email, name, phone, password
- `setAuthCookies()` — `httpOnly: true`, `secure: true` in prod, `sameSite: Strict`, refresh token path restricted to `/api/v1/auth/refresh`
- `clearAuthCookies()` — on logout
- `blacklistToken()` — Redis primary (O(1), auto-expiry), MongoDB fallback
- `isBlacklisted()` — checked in `authenticate` middleware on every request

### `utils/mfaService.js`
- TOTP via `otplib` — compatible with Google Authenticator, Authy, etc.
- MFA secret stored **AES-256-GCM encrypted** (never plain text in DB)
- `setupMfa()` → returns QR code URL + manual key
- `verifyAndEnableMfa()` → activates MFA + generates 8 hashed backup codes
- `checkMfa()` → verifies TOTP or backup code (backup code is single-use)
- `disableMfa()` → requires valid code before removing

### `models/RefreshToken.js`
- `tokenHash` — SHA-256 of raw token (raw token never stored)
- `used` flag — detect replay attacks
- `family` — all tokens in a rotation chain share a family ID; if an old token is reused, the **entire family is revoked** (detects token theft)
- TTL index — auto-delete expired tokens
- `revokeAllForUser()` — logout all devices

### `controllers/authController.js`
- **Lockout**: 5 failed attempts → 15-minute lock
- **Anti-enumeration**: same error message for wrong email AND wrong password
- **Reset password**: uses SHA-256 hashed token with 15-min expiry; increments tokenVersion on success (invalidates all sessions)
- **MFA gate**: login returns `MFA_REQUIRED` if enabled, without issuing tokens

### `middleware/authenticate.js`
Full 5-step chain on every request:
1. Extract token from HttpOnly cookie or Authorization header
2. Verify JWT signature + expiry
3. Check jti blacklist (Redis or MongoDB)
4. Load user from DB (confirms still active)
5. Compare tokenVersion (catches logout / role changes)

---

## Environment Variables

| Variable | Description | How to generate |
|----------|-------------|-----------------|
| `JWT_SECRET` | 32+ random chars for JWT signing | `node scripts/generateKeys.js` |
| `JWT_ACCESS_EXPIRY` | Access token lifetime | `15m` (recommended) |
| `JWT_REFRESH_EXPIRY` | Refresh token lifetime | `7d` (recommended) |
| `FIELD_ENCRYPTION_KEY` | 64-char hex for MFA secret encryption | `node scripts/generateKeys.js` |
| `REDIS_URL` | Redis for JWT blacklist | `redis://127.0.0.1:6379` |
| `MONGODB_URI` | MongoDB connection string | From `setupMongoUsers.js` |
| `MAX_LOGIN_ATTEMPTS` | Attempts before lockout | `5` |
| `LOCKOUT_MINUTES` | Lockout duration | `15` |
| `OTP_EXPIRY_MINUTES` | OTP lifetime | `10` |
| `OTP_MAX_ATTEMPTS` | Wrong attempts before invalidation | `3` |

---

## API Reference

| Method | Route | Auth | Rate limit | Description |
|--------|-------|------|------------|-------------|
| POST | `/api/v1/auth/login` | — | 10/15min | Login with email + password (+ MFA code) |
| POST | `/api/v1/auth/logout` | ✓ | — | Logout, clear cookies, invalidate tokens |
| POST | `/api/v1/auth/refresh` | cookie | — | Rotate refresh token, issue new access token |
| POST | `/api/v1/auth/forgot-password` | — | 3/hour | Request password reset link |
| POST | `/api/v1/auth/reset-password` | — | 3/hour | Set new password with reset token |
| POST | `/api/v1/auth/otp/send` | — | 5/10min | Generate and send OTP |
| POST | `/api/v1/auth/otp/verify` | — | 5/10min | Verify OTP |
| POST | `/api/v1/auth/otp/resend` | — | 5/10min | Resend OTP (with cooldown) |
| GET | `/api/v1/auth/mfa/status` | ✓ | — | Check if MFA is enabled |
| POST | `/api/v1/auth/mfa/setup` | ✓ | — | Generate TOTP secret + QR code |
| POST | `/api/v1/auth/mfa/enable` | ✓ | 10/5min | Activate MFA with first code |
| POST | `/api/v1/auth/mfa/disable` | ✓ | 10/5min | Disable MFA with code confirmation |

---

## Security Checklist

- [ ] `JWT_SECRET` is 32+ random chars, in `.env` only
- [ ] `FIELD_ENCRYPTION_KEY` is 64-char hex, in `.env` only
- [ ] Access token expiry is `15m`
- [ ] JWT stored in `HttpOnly` cookie (not localStorage)
- [ ] Refresh token cookie path restricted to `/api/v1/auth/refresh`
- [ ] `Secure` + `SameSite=Strict` flags set in production
- [ ] JWT payload contains no email, name, phone, or password
- [ ] `tokenVersion` incremented on logout, password change, role change
- [ ] jti blacklisted on logout
- [ ] Refresh token rotation active (used flag + family revocation)
- [ ] 5 failed login attempts → 15-minute lockout
- [ ] Same error message for wrong email + wrong password
- [ ] OTP stored as SHA-256 hash (never plain text)
- [ ] OTP expires in 10 minutes
- [ ] OTP invalidated after 3 wrong attempts
- [ ] MFA secret stored AES-256-GCM encrypted
- [ ] All tests passing: `node --test tests/`
